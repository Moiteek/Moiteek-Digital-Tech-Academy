<?php
require_once '../bootstrap.php';

if(!Auth::isAdminLoggedIn()) {
    Response::redirect('../admin/login.php', 'Please login', 'error');
}

$resource = null;
$course = null;
$mode = 'add';

// Get course
$course_id = (int)($_GET['course_id'] ?? $_POST['course_id'] ?? 0);
if($course_id) {
    $stmt = $pdo->prepare("SELECT * FROM courses WHERE id = ?");
    $stmt->execute([$course_id]);
    $course = $stmt->fetch();
    if(!$course) {
        Response::redirect('courses.php', 'Course not found', 'error');
    }
}

// Get resource if editing
if(isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $stmt = $pdo->prepare("SELECT * FROM course_resources WHERE id = ?");
    $stmt->execute([$id]);
    $resource = $stmt->fetch();
    if(!$resource) {
        Response::redirect('courses.php', 'Resource not found', 'error');
    }
    $course_id = $resource['course_id'];
    $mode = 'edit';
}

if(!$course && !$resource) {
    Response::redirect('courses.php', 'Invalid request', 'error');
}

$resource_types = ['pdf' => 'PDF Document', 'book' => 'Book/E-Book', 'code' => 'Code/Repository', 'template' => 'Template', 'document' => 'Document', 'other' => 'Other'];

// Handle form submission
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = Validator::sanitizeInput($_POST['title'] ?? '');
    $description = Validator::sanitizeInput($_POST['description'] ?? '');
    $resource_type = $_POST['resource_type'] ?? 'pdf';
    $file_url = Validator::sanitizeInput($_POST['file_url'] ?? '');
    $is_external = (int)($_POST['is_external'] ?? 0);
    
    if(empty($title)) {
        Response::redirect('resource-form.php?course_id=' . $course_id, 'Resource title is required', 'error');
    }
    
    if(empty($file_url)) {
        Response::redirect('resource-form.php?course_id=' . $course_id, 'Resource URL is required', 'error');
    }
    
    if($mode === 'add') {
        $stmt = $pdo->prepare("
            INSERT INTO course_resources (course_id, title, description, resource_type, file_url, is_external)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$course_id, $title, $description, $resource_type, $file_url, $is_external]);
        Response::redirect('course-form.php?id=' . $course_id, 'Resource added successfully!', 'success');
    } else {
        $stmt = $pdo->prepare("
            UPDATE course_resources 
            SET title = ?, description = ?, resource_type = ?, file_url = ?, is_external = ?
            WHERE id = ?
        ");
        $stmt->execute([$title, $description, $resource_type, $file_url, $is_external, $resource['id']]);
        Response::redirect('course-form.php?id=' . $course_id, 'Resource updated successfully!', 'success');
    }
}

$flash = Response::getFlashMessage();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= ucfirst($mode) ?> Resource - <?= APP_NAME ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <i class="fas fa-graduation-cap text-2xl text-blue-600"></i>
                <span class="font-bold text-lg text-gray-800"><?= APP_NAME ?></span>
            </div>
            <a href="course-form.php?id=<?= $course_id ?>" class="text-gray-600 hover:text-blue-600">
                <i class="fas fa-arrow-left mr-1"></i>Back to Course
            </a>
        </div>
    </nav>

    <div class="max-w-4xl mx-auto p-8">
        <!-- Flash Message -->
        <?php if($flash): ?>
            <div class="mb-6 p-4 rounded-lg bg-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-50 border border-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-200 flex items-center gap-3">
                <i class="fas fa-<?= $flash['type'] === 'error' ? 'exclamation-circle' : 'check-circle' ?> text-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-600"></i>
                <p class="text-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-700"><?= htmlspecialchars($flash['message']) ?></p>
            </div>
        <?php endif; ?>

        <!-- Form -->
        <div class="bg-white rounded-lg shadow overflow-hidden">
            <div class="bg-gradient-to-r from-indigo-500 to-purple-600 p-6 text-white">
                <h1 class="text-3xl font-bold flex items-center gap-2">
                    <i class="fas fa-file"></i>
                    <?= ucfirst($mode) ?> Resource
                </h1>
                <p class="text-indigo-100 mt-2">Course: <?= htmlspecialchars($course['title'] ?? '') ?></p>
            </div>

            <div class="p-8 space-y-6">
                <form method="POST">
                    <input type="hidden" name="course_id" value="<?= $course_id ?>">

                    <!-- Resource Title -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Resource Title *</label>
                        <input type="text" name="title" value="<?= $resource ? htmlspecialchars($resource['title']) : '' ?>" required 
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" 
                            placeholder="e.g., HTML Cheat Sheet">
                    </div>

                    <!-- Description -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Description</label>
                        <textarea name="description" rows="4" 
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="Describe what this resource contains"><?= $resource ? htmlspecialchars($resource['description']) : '' ?></textarea>
                    </div>

                    <!-- Resource Type -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Resource Type *</label>
                        <select name="resource_type" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                            <?php foreach($resource_types as $key => $label): ?>
                                <option value="<?= $key ?>" <?= ($resource && $resource['resource_type'] === $key) ? 'selected' : '' ?>>
                                    <?= $label ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- Resource URL -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Resource URL / Link *</label>
                        <input type="url" name="file_url" value="<?= $resource ? htmlspecialchars($resource['file_url']) : '' ?>" required 
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" 
                            placeholder="https://example.com/resource.pdf">
                        <p class="text-xs text-gray-600 mt-1">ⓘ Can be a download link, GitHub repo, or external resource URL</p>
                    </div>

                    <!-- External URL Toggle -->
                    <div class="flex items-center gap-3 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                        <input type="checkbox" name="is_external" value="1" id="is_external" 
                            <?= ($resource && $resource['is_external']) ? 'checked' : '' ?>
                            class="w-5 h-5 text-blue-600 rounded">
                        <label for="is_external" class="text-sm text-gray-700">
                            <span class="font-semibold">External Resource</span>
                            <p class="text-xs text-gray-600 mt-1">Check if this is an external link (e.g., GitHub, Google Drive, CodePen)</p>
                        </label>
                    </div>

                    <!-- Preview Info -->
                    <div class="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                        <p class="text-sm text-amber-800 flex items-start gap-2">
                            <i class="fas fa-info-circle text-amber-600 mt-0.5 flex-shrink-0"></i>
                            <span>
                                <strong>Preview Tip:</strong> Before saving, ensure the URL is accessible and returns the expected resource. 
                                The link will be displayed to students as a download/open button.
                            </span>
                        </p>
                    </div>

                    <!-- Actions -->
                    <div class="flex gap-4 pt-6 border-t">
                        <button type="submit" class="flex-1 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 font-semibold transition">
                            <i class="fas fa-save mr-2"></i><?= $mode === 'edit' ? 'Update' : 'Add' ?> Resource
                        </button>
                        <a href="course-form.php?id=<?= $course_id ?>" class="flex-1 bg-gray-300 text-gray-800 px-6 py-3 rounded-lg hover:bg-gray-400 font-semibold transition text-center">
                            <i class="fas fa-times mr-2"></i>Cancel
                        </a>
                    </div>
                </form>
            </div>
        </div>

        <!-- Resource Preview -->
        <div class="mt-8 bg-white rounded-lg shadow overflow-hidden">
            <div class="bg-gray-50 p-6 border-b">
                <h2 class="text-lg font-bold text-gray-800 flex items-center gap-2">
                    <i class="fas fa-link text-blue-600"></i>Resource Preview
                </h2>
            </div>
            <div class="p-6">
                <?php if($resource && $resource['file_url']): ?>
                    <div class="space-y-4">
                        <!-- Resource Card Preview -->
                        <div class="border border-gray-200 rounded-lg p-4 bg-gray-50">
                            <div class="flex items-start gap-4">
                                <div class="flex-shrink-0">
                                    <?php
                                    $type = $resource['resource_type'];
                                    $icon_map = [
                                        'pdf' => ['icon' => 'fa-file-pdf', 'color' => 'text-red-600'],
                                        'book' => ['icon' => 'fa-book', 'color' => 'text-blue-600'],
                                        'code' => ['icon' => 'fa-code', 'color' => 'text-gray-600'],
                                        'template' => ['icon' => 'fa-file-alt', 'color' => 'text-purple-600'],
                                        'document' => ['icon' => 'fa-file-word', 'color' => 'text-blue-600'],
                                        'other' => ['icon' => 'fa-file', 'color' => 'text-gray-500']
                                    ];
                                    $icon_data = $icon_map[$type] ?? $icon_map['other'];
                                    ?>
                                    <i class="fas <?= $icon_data['icon'] ?> text-3xl <?= $icon_data['color'] ?>"></i>
                                </div>
                                <div class="flex-grow">
                                    <h3 class="font-semibold text-gray-800"><?= htmlspecialchars($resource['title']) ?></h3>
                                    <p class="text-sm text-gray-600 mt-1"><?= htmlspecialchars($resource['description']) ?></p>
                                    <p class="text-xs text-gray-500 mt-2">
                                        Type: <span class="font-mono bg-gray-200 px-2 py-1 rounded"><?= $resource_types[$type] ?? 'Unknown' ?></span>
                                    </p>
                                </div>
                                <a href="<?= htmlspecialchars($resource['file_url']) ?>" target="_blank" 
                                    class="flex-shrink-0 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 text-sm font-semibold">
                                    <i class="fas fa-external-link-alt mr-1"></i>Open
                                </a>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="text-center py-8">
                        <i class="fas fa-file text-6xl text-gray-400 mb-3"></i>
                        <p class="text-gray-600">Add a resource URL above to see the preview</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Resource Guidelines -->
        <div class="mt-8 bg-white rounded-lg shadow overflow-hidden">
            <div class="bg-gray-50 p-6 border-b">
                <h2 class="text-lg font-bold text-gray-800 flex items-center gap-2">
                    <i class="fas fa-lightbulb text-yellow-500"></i>Resource Guidelines
                </h2>
            </div>
            <div class="p-6 space-y-4 text-sm text-gray-700">
                <div>
                    <strong class="text-gray-900">📄 PDF Documents:</strong> Upload course notes, tutorials, or reference materials
                </div>
                <div>
                    <strong class="text-gray-900">📚 Books/E-Books:</strong> Link to online books or reading materials (e.g., Google Books, Amazon, Open Library)
                </div>
                <div>
                    <strong class="text-gray-900">💻 Code/Repository:</strong> GitHub repositories, CodePen projects, or coding samples
                </div>
                <div>
                    <strong class="text-gray-900">🎨 Templates:</strong> HTML templates, design resources, or starter code
                </div>
                <div>
                    <strong class="text-gray-900">📋 Documents:</strong> Word docs, spreadsheets, presentations, or other office formats
                </div>
                <div>
                    <strong class="text-gray-900">🔗 Supported Services:</strong> Direct downloads, Google Drive, Dropbox, GitHub, AWS S3, Firebase, OneDrive
                </div>
            </div>
        </div>
    </div>
</body>
</html>
