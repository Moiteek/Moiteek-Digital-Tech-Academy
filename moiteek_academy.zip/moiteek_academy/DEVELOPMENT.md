# Development Guide - Moiteek Academy

This document provides guidelines for developers working on the Moiteek Academy platform.

---

## 📋 **Table of Contents**

1. [Project Structure](#project-structure)
2. [Code Standards](#code-standards)
3. [Git Workflow](#git-workflow)
4. [Helper Classes Guide](#helper-classes-guide)
5. [File Naming Conventions](#file-naming-conventions)
6. [Testing Guidelines](#testing-guidelines)
7. [Common Tasks](#common-tasks)
8. [Troubleshooting](#troubleshooting)

---

## 🏗️ **Project Structure**

```
moiteek_academy/
├── config/              # Configuration files
│   └── db.php          # Database & session setup
├── includes/           # Helper/utility classes
│   ├── Auth.php        # Authentication
│   ├── Validator.php   # Input validation
│   ├── Response.php    # Response handling
│   ├── Database.php    # DB queries
│   └── FileManager.php # File uploads
├── auth/               # Authentication pages
│   ├── login.php       # Login form
│   ├── register.php    # Registration form
│   └── logout.php      # Logout handler
├── admin/              # Admin panel pages
│   ├── dashboard.php
│   ├── students.php
│   ├── payments.php
│   └── ... (other admin pages)
├── student/            # Student pages
│   ├── dashboard.php
│   ├── course.php
│   └── ... (other student pages)
├── assets/             # Static files
│   ├── css/custom.css  # Custom styles
│   └── js/app.js       # JavaScript utilities
├── sql/                # Database
│   └── database.sql    # Schema & seed data
├── uploads/            # User-uploaded files
│   └── payments/       # Payment proofs
├── bootstrap.php       # App initialization
├── index.php           # Homepage
└── README.md           # Documentation
```

---

## 📝 **Code Standards**

### **PHP Standards**

1. **Format**
   - Use 4 spaces for indentation
   - Follow PSR-12 coding style
   - Max line length: 120 characters
   - Use UTF-8 encoding

2. **Naming Conventions**
   - Classes: PascalCase (`Auth`, `Validator`)
   - Functions: camelCase (`loginStudent()`, `validateEmail()`)
   - Constants: UPPER_CASE (`DB_HOST`, `MAX_FILE_SIZE`)
   - Variables: camelCase (`userName`, `courseId`)

3. **Comments**
   ```php
   // Single line comment for brief notes
   
   /**
    * Method description
    * 
    * @param string $email User email
    * @return bool Success status
    */
   public function validateEmail($email) {
       // Implementation
   }
   ```

4. **Error Handling**
   ```php
   try {
       // Risky operation
       $result = someFunction();
   } catch (Exception $e) {
       Response::error($e->getMessage());
       exit();
   }
   ```

5. **Security**
   - ALWAYS use prepared statements
   - Never concatenate user input into SQL
   - Escape output with `htmlspecialchars()`
   - Validate ALL user input
   - Never store plain text passwords

### **HTML Standards**

1. Semantic markup (`<header>`, `<nav>`, `<main>`, `<footer>`)
2. Proper form labels and inputs
3. ARIA attributes for accessibility
4. Responsive design (mobile-first)

### **JavaScript Standards**

1. Use `const` by default, `let` if reassignment needed
2. Arrow functions for callbacks
3. Template literals instead of string concatenation
4. Meaningful variable and function names
5. Avoid `var` keyword

### **CSS/Tailwind**

1. Use Tailwind utility classes primarily
2. Avoid custom inline styles when Tailwind class exists
3. Use CSS variables for custom colors
4. Mobile-first responsive approach

---

## 🔄 **Git Workflow**

### **Branch Naming**
- `feature/description` - New features
- `bugfix/description` - Bug fixes
- `hotfix/description` - Production fixes
- `docs/description` - Documentation

### **Commit Messages**
```
[TYPE] Brief description

Detailed explanation if needed.

- Bullet point 1
- Bullet point 2

Resolves: #issue_number
```

Types: `FEAT`, `FIX`, `DOCS`, `STYLE`, `REFACTOR`, `TEST`, `CHORE`

Example:
```
[FEAT] Add email notification system

Implements email notifications for:
- Student registration approval
- Payment confirmation
- Course enrollment

Uses PHPMailer library for SMTP support
Resolves: #42
```

---

## 🔧 **Helper Classes Guide**

### **Auth Class** (`includes/Auth.php`)

**Password Management**
```php
// Hash password
$hash = Auth::hashPassword('myPassword123');

// Verify password
if (Auth::verifyPassword($plainPassword, $hash)) {
    // Correct password
}
```

**Student Authentication**
```php
// Login student
if (Auth::loginStudent($email, $password)) {
    // Success - redirects and sets session
} else {
    // Failed - show error
}

// Check if student logged in
if (Auth::isStudentLoggedIn()) {
    echo "Welcome!";
}

// Get current student ID
$studentId = Auth::getCurrentUserId();
```

**Admin Authentication**
```php
// Login admin
if (Auth::loginAdmin($email, $password)) {
    // Success
}

// Check if admin logged in
if (Auth::isAdminLoggedIn()) {
    echo "Admin Panel";
}
```

**Logout**
```php
Auth::logout();
// Destroys session
```

---

### **Validator Class** (`includes/Validator.php`)

**Single Field Validation**
```php
$validator = new Validator();

// Email validation
$validator->validateEmail('user@example.com');

// Password validation
$validator->validatePassword('SecurePass123!');

// Full name
$validator->validateFullName('John Doe');

// Phone number
$validator->validatePhone('1234567890');

// Username
$validator->validateUsername('john_doe123');

// Amount
$validator->validateAmount('99.99');

// File upload
$validator->validateFileUpload($_FILES['upload']);
```

**Getting Errors**
```php
$validator = new Validator();

$validator->validateEmail($email);
$validator->validatePassword($password);

if ($validator->getErrors()) {
    $errors = $validator->getErrors();
    foreach ($errors as $error) {
        echo $error . "<br>";
    }
}

// Clear errors for next form
$validator->clearErrors();
```

---

### **Database Class** (`includes/Database.php`)

**Query Examples**
```php
$db = new Database();
$db->setPDO($pdo);

// Check if email exists
if ($db->emailExists('user@example.com')) {
    echo "Email already registered";
}

// Get user by ID
$user = $db->getUserById($userId);
echo $user['fullname'];

// Get all courses
$courses = $db->getCourses();
foreach ($courses as $course) {
    echo $course['title'];
}

// Get student enrollments
$enrollments = $db->getStudentEnrollments($studentId);

// Get statistics
$stats = $db->getTotalStudents();
```

---

### **Response Class** (`includes/Response.php`)

**Success Response**
```php
Response::success('Student approved successfully');
// Outputs: Success message in session
// Use after database update, before redirect
```

**Error Response**
```php
Response::error('Payment confirmation failed');
// Displays error and exits
```

**JSON Response** (for APIs)
```php
Response::json([
    'status' => 'success',
    'data' => $courseData
], 200);
```

**Redirect**
```php
Response::redirect('admin/dashboard.php');
// Redirects to URL

Response::redirect('admin/students.php?tab=pending');
// Redirect with query parameters
```

**Flash Messages**
```php
// Set flash message
Response::success('Payment confirmed!');
Response::redirect('admin/payments.php');

// Display on next page
if ($message = Response::getFlashMessage()) {
    echo $message;
}
```

---

### **FileManager Class** (`includes/FileManager.php`)

**Upload File**
```php
$fileManager = new FileManager();

try {
    $filename = $fileManager->uploadFile($_FILES['proof']);
    // File uploaded successfully
    // $filename contains the stored filename
} catch (Exception $e) {
    echo "Upload failed: " . $e->getMessage();
}
```

**Delete File**
```php
$fileManager->deleteFile('payment_proof_123.pdf');
// File deleted from storage
```

---

## 📁 **File Naming Conventions**

| Type | Convention | Example |
|------|-----------|---------|
| Classes | PascalCase.php | `Auth.php`, `Validator.php` |
| Pages | lowercase.php | `dashboard.php`, `courses.php` |
| Views/Partials | lowercase.php | `course_card.php`, `navbar.php` |
| Templates | underscore prefix | `_header.php`, `_footer.php` |
| CSS | lowercase with dash | `custom-styles.css` |
| JavaScript | lowercase.js | `app.js`, `utils.js` |
| SQL Scripts | noun_action.sql | `database.sql`, `seed_courses.sql` |

---

## 🧪 **Testing Guidelines**

### **Manual Testing Checklist**

#### **Registration & Authentication**
- [ ] Student registration with valid data
- [ ] Student registration with invalid email
- [ ] Student registration with weak password
- [ ] Student registration with duplicate username
- [ ] Admin login with correct credentials
- [ ] Admin login with wrong password
- [ ] Student login after admin approval
- [ ] Session timeout after 30 minutes
- [ ] Logout clears session

#### **Course Management**
- [ ] View all courses list
- [ ] Search courses by title
- [ ] Filter courses by level
- [ ] Filter courses by category
- [ ] Course details display correctly
- [ ] Enrollment button visible for approved students
- [ ] Enrollment creates database record

#### **Payment Workflow**
- [ ] Upload payment proof (valid file)
- [ ] Upload payment proof (exceeds 5MB) - rejected
- [ ] Upload payment proof (invalid type) - rejected
- [ ] Admin can view pending payments
- [ ] Admin confirms payment payment status updates
- [ ] Admin rejects payment status updates

#### **Admin Dashboard**
- [ ] Statistics display correct numbers
- [ ] Student approval list shows pending
- [ ] Approve student updates status
- [ ] Reject student updates status
- [ ] Payment summary shows totals
- [ ] Links to detail pages work

#### **Browser Compatibility**
- [ ] Chrome/Chromium
- [ ] Firefox
- [ ] Safari
- [ ] Mobile browsers (iOS Safari, Chrome Android)

---

## 📚 **Common Tasks**

### **Add a New Database Field**

1. **Update Schema** (`sql/database.sql`)
   ```sql
   ALTER TABLE courses ADD COLUMN instructor_id INT NOT NULL;
   ALTER TABLE courses ADD FOREIGN KEY (instructor_id) REFERENCES users(id);
   ```

2. **Update Database Helper** (`includes/Database.php`)
   ```php
   public function getCourseWithInstructor($courseId) {
       $stmt = $this->pdo->prepare('
           SELECT c.*, u.fullname as instructor_name 
           FROM courses c 
           LEFT JOIN users u ON c.instructor_id = u.id 
           WHERE c.id = ?
       ');
       $stmt->execute([$courseId]);
       return $stmt->fetch();
   }
   ```

3. **Update Form** (admin/courses.php)
   ```html
   <input type="hidden" name="instructor_id" value="<?php echo $courseId; ?>">
   ```

### **Add Form Validation**

1. **Create Validator Method** (`includes/Validator.php`)
   ```php
   public function validateCoursePrice($price) {
       if (!is_numeric($price) || $price < 0) {
           $this->errors[] = "Course price must be a positive number";
       }
   }
   ```

2. **Use in Form** 
   ```php
   $validator->validateCoursePrice($_POST['price']);
   if ($validator->getErrors()) {
       Response::error(implode(", ", $validator->getErrors()));
   }
   ```

### **Create New Status Types**

1. **Update Database**
   ```sql
   ALTER TABLE enrollments 
   MODIFY payment_status ENUM('pending', 'confirmed', 'failed', 'refunded');
   ```

2. **Update PHP** (includes/Database.php)
   ```php
   const PAYMENT_STATUSES = ['pending', 'confirmed', 'failed', 'refunded'];
   ```

3. **Update UI** (admin/payments.php)
   ```php
   <?php foreach (Database::PAYMENT_STATUSES as $status): ?>
       <option value="<?php echo $status; ?>"><?php echo ucfirst($status); ?></option>
   <?php endforeach; ?>
   ```

---

## 🐛 **Troubleshooting**

### **"Class not found" Error**

**Problem**: 
```
Fatal error: Class 'Auth' not found in login.php
```

**Solution**: 
- Ensure `bootstrap.php` is included at top of file
- Check that `includes/Auth.php` exists
- Verify file paths in bootstrap.php

### **"Database connection failed"**

**Problem**:
```
SQLSTATE[HY000]: General error: 1194 Table 'moiteek_academy.admins' is marked as crashed
```

**Solution**:
1. Check MySQL is running
2. Run: `REPAIR TABLE table_name;`
3. Re-import database.sql if critical
4. Check database credentials in config/db.php

### **Session Not Persisting**

**Problem**: 
User logs in but session clears immediately

**Solution**:
1. Check session_save_path permissions
2. Verify php.ini session settings
3. Check browser cookie settings (must accept cookies)
4. Ensure session starts before headers: `session_start()` at very top

### **File Upload Fails**

**Problem**:
```
"The file upload failed"
```

**Solution**:
1. Check `uploads/payments/` folder exists and has write permissions
2. Verify file size < 5MB
3. Check allowed file types (jpg, jpeg, png, pdf)
4. Check PHP upload_max_filesize in php.ini (should be >= 5MB)

### **Password Not Working**

**Problem**:
Correct password rejected during login

**Solution**:
1. Verify password was hashed with bcrypt when created
2. Check PASSWORD_BCRYPT cost = 10 (consistent)
3. Test with known working password from database.sql
4. Ensure no extra spaces/whitespace in password

---

## 📞 **Getting Help**

- Check existing code for similar implementations
- Review this guide for common tasks
- Check error logs in browser console (F12)
- Check PHP error logs in XAMPP/server logs
- Ask team members or senior developers

---

## ✅ **Pre-Commit Checklist**

Before committing code:

- [ ] Code follows standards (indentation, naming, comments)
- [ ] All variables initialized before use
- [ ] No console.log or debug code left
- [ ] Security: No exposed passwords or API keys
- [ ] Forms validated both client and server-side
- [ ] Database queries parameterized
- [ ] Error handling implemented
- [ ] UI tested on mobile and desktop
- [ ] No SQL errors in logs
- [ ] Performance acceptable (pages load < 3 seconds)

---

**Happy Coding! 💻✨**
