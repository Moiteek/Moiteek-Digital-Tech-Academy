<?php
// app/views/admin/assignment_grading.php
?>
<div class="container mx-auto p-4">
  <h2 class="text-xl font-bold mb-2">Grade Assignment</h2>
  <table class="min-w-full bg-white border">
    <thead>
      <tr><th>Student</th><th>File</th><th>Grade</th><th>Feedback</th><th>Action</th></tr>
    </thead>
    <tbody>
      <?php foreach ($assignments as $a): ?>
      <tr>
        <td><?= htmlspecialchars($a['student_name']) ?></td>
        <td><a href="/uploads/assignments/<?= htmlspecialchars($a['file_path']) ?>" target="_blank" class="text-blue-600">Download</a></td>
        <td><?= $a['grade'] ?></td>
        <td><?= $a['feedback'] ?></td>
        <td>
          <form method="POST" action="/admin/assignment_grade.php">
            <input type="hidden" name="assignment_id" value="<?= $a['id'] ?>">
            <input type="text" name="grade" placeholder="Grade" class="border px-2">
            <input type="text" name="feedback" placeholder="Feedback" class="border px-2">
            <button type="submit" class="bg-green-600 text-white px-2 py-1 rounded">Submit</button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
