<?php
// app/models/Lesson.php
class Lesson extends Model {
    public static function create($data) {
        $sql = "INSERT INTO lessons (course_id, module_id, title, description, video_type, video_url, video_file, resource_links, lesson_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        return self::insert($sql, [
            $data['course_id'], $data['module_id'], $data['title'], $data['description'], $data['video_type'], $data['video_url'], $data['video_file'], $data['resource_links'], $data['lesson_order']
        ]);
    }
    public static function updateOrder($lessonId, $newOrder) {
        $sql = "UPDATE lessons SET lesson_order = ? WHERE id = ?";
        return self::update($sql, [$newOrder, $lessonId]);
    }
}

// app/models/LessonProgress.php
class LessonProgress extends Model {
    public static function markCompleted($enrollmentId, $lessonId) {
        $sql = "INSERT INTO module_progress (enrollment_id, module_id, lesson_id, is_completed, completed_at) VALUES (?, ?, ?, 1, NOW())";
        // ...get module_id from lesson...
        // self::insert($sql, [...]);
    }
    public static function allCompleted($enrollmentId) {
        // Check if all lessons for enrollment are completed
        // ...return boolean...
    }
}

// app/models/Enrollment.php (add updateCompletedAt)
class Enrollment extends Model {
    public static function updateCompletedAt($enrollmentId) {
        $sql = "UPDATE enrollments SET completed_at = NOW(), status = 'completed' WHERE id = ?";
        return self::update($sql, [$enrollmentId]);
    }
}
