# Core Files to Modify for MVC Upgrade

## 1. public/index.php
- Acts as the front controller. All requests go through here.
- Parses URL, loads appropriate controller/action.

## 2. /app/controllers/*Controller.php
- Each controller handles a resource (Auth, Course, Student, Admin, etc).
- Receives input, calls models, renders views.

## 3. /app/models/*.php
- Each model represents a DB table/entity.
- All DB access via prepared statements.

## 4. /app/views/
- Views for each page/feature. No business logic, only display.

## 5. /core/
- App.php: Router/dispatcher.
- Controller.php: Base controller.
- Model.php: Base model (PDO, prepared statements).
- View.php: Base view renderer.
- Auth.php: Auth/session/role logic.
- CSRF.php: CSRF protection.
- Validator.php: Input validation.
- Response.php: Redirects, JSON, etc.
- Email.php: Email notifications.
- FileManager.php: Secure file uploads.

## 6. /config/
- db.php: PDO connection.
- app.php: App-wide config.
- routes.php: Route definitions.
- .env: Environment variables.

---

**Major changes:**
- All logic moves to controllers/models.
- Views are pure HTML/Tailwind/JS.
- Auth, session, and CSRF are handled in /core.
- All DB queries use prepared statements.
- Role-based access in Auth.php and controllers.

> Only these core files/folders need to be created or refactored for the MVC upgrade.
