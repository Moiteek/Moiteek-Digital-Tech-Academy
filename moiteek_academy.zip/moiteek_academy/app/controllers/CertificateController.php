<?php
// app/controllers/CertificateController.php
class CertificateController extends Controller {
    public function generate($studentId, $courseId, $grade = null) {
        $student = Student::get($studentId);
        $course = Course::get($courseId);
        $code = $this->generateCode($studentId, $courseId);
        Certificate::create([
            'student_id' => $studentId,
            'course_id' => $courseId,
            'certificate_code' => $code,
            'grade' => $grade,
        ]);
        $pdf = $this->generatePDF($student['fullname'], $course['title'], date('Y-m-d'), $code);
        // ...save/send PDF as needed...
    }
    public function verify($code) {
        $cert = Certificate::findByCode($code);
        // ...return certificate info or error...
    }
    public function reissue($certId) {
        Certificate::reissue($certId);
        // ...regenerate PDF...
    }
    public function revoke($certId, $reason) {
        Certificate::revoke($certId, $reason);
    }
    private function generateCode($studentId, $courseId) {
        return substr(md5($studentId . $courseId . time()), 0, 16);
    }
    private function generatePDF($studentName, $courseTitle, $date, $code) {
        // Use TCPDF or FPDF
        require_once __DIR__ . '/../../core/tcpdf/tcpdf.php';
        $pdf = new TCPDF();
        $pdf->AddPage();
        $pdf->SetFont('helvetica', '', 16);
        $pdf->Cell(0, 10, 'Certificate of Completion', 0, 1, 'C');
        $pdf->SetFont('helvetica', '', 12);
        $pdf->Cell(0, 10, "Awarded to: $studentName", 0, 1, 'C');
        $pdf->Cell(0, 10, "Course: $courseTitle", 0, 1, 'C');
        $pdf->Cell(0, 10, "Date: $date", 0, 1, 'C');
        $pdf->Cell(0, 10, "Verification Code: $code", 0, 1, 'C');
        $pdf->Output('certificate.pdf', 'I');
        return $pdf;
    }
}
