# DEPLOYMENT.md - Production Deployment Guide

Complete guide for deploying Moiteek Academy to production servers.

---

## 📋 **Pre-Deployment Checklist**

### **Code Readiness**
- [ ] All features tested locally
- [ ] No debug code or console.log statements
- [ ] Error logging configured but error display disabled
- [ ] .env sample documented and secure credentials ready
- [ ] Database migrations/backups prepared
- [ ] All dependencies installed and locked
- [ ] Code committed and tagged with version number
- [ ] README and documentation up-to-date

### **Security**
- [ ] All default passwords changed
- [ ] HTTPS certificate obtained and installed
- [ ] Firewall rules configured
- [ ] SSH keys generated for server access
- [ ] Database backups automated
- [ ] File upload restrictions set

### **Infrastructure**
- [ ] Hosting/VPS provider selected
- [ ] PHP 7.4+ installed and configured
- [ ] MySQL 5.7+ installed
- [ ] Web server (Apache/Nginx) configured
- [ ] Domain name pointed to server
- [ ] SSL certificate installed
- [ ] Backup and disaster recovery plan

---

## 🚀 **Deployment Steps**

### **Step 1: Prepare Server**

#### **Install PHP & MySQL** (Ubuntu/Debian)
```bash
sudo apt update
sudo apt install -y php7.4 php7.4-mysql php7.4-curl php7.4-gd php7.4-json php7.4-mbstring
sudo apt install -y mysql-server

# Verify installations
php -v
mysql --version
```

#### **Configure PHP** (`/etc/php/7.4/apache2/php.ini`)
```ini
memory_limit = 256M
upload_max_filesize = 10M
post_max_size = 10M
max_execution_time = 300
display_errors = Off
error_log = /var/log/php_errors.log
session.save_path = "/var/lib/php/sessions"
```

#### **Configure MySQL** (`/etc/mysql/mysql.conf.d/mysqld.cnf`)
```ini
bind-address = 127.0.0.1
default_storage_engine = InnoDB
character_set_server = utf8mb4
collation_server = utf8mb4_unicode_ci
```

### **Step 2: Deploy Application**

#### **Clone Repository**
```bash
# Using git
cd /var/www
sudo git clone https://github.com/yourrepo/moiteek_academy.git
cd moiteek_academy

# Or upload via SFTP
# Use FileZilla or similar: Upload all files to /var/www/moiteek_academy/
```

#### **Set Permissions**
```bash
# Set owner
sudo chown -R www-data:www-data /var/www/moiteek_academy

# Set permissions
sudo chmod -R 755 /var/www/moiteek_academy
sudo chmod -R 775 /var/www/moiteek_academy/uploads
sudo chmod -R 775 /var/www/moiteek_academy/uploads/payments

# Create session directory
sudo mkdir -p /var/lib/php/sessions
sudo chown www-data:www-data /var/lib/php/sessions
sudo chmod 1733 /var/lib/php/sessions
```

#### **Configure Environment**
```bash
# Copy environment file
cp .env.example .env

# Edit with production values
sudo nano .env
```

Edit `.env` with:
```
APP_ENV = "production"
APP_DEBUG = "false"
APP_URL = "https://yourdomain.com"

DB_HOST = "localhost"
DB_NAME = "moiteek_prod"
DB_USER = "moiteek_user"
DB_PASS = "strong_secure_password_here"

SESSION_COOKIE_SECURE = "true"
MAIL_HOST = "your_smtp_server"
MAIL_USERNAME = "your_email@example.com"
MAIL_PASSWORD = "your_smtp_password"
```

### **Step 3: Setup Database**

#### **Create Database & User**
```bash
mysql -u root -p
```

```sql
-- Create database
CREATE DATABASE moiteek_prod CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Create user
CREATE USER 'moiteek_user'@'localhost' IDENTIFIED BY 'strong_secure_password_here';

-- Grant privileges
GRANT ALL PRIVILEGES ON moiteek_prod.* TO 'moiteek_user'@'localhost';
FLUSH PRIVILEGES;

-- Exit
EXIT;
```

#### **Import Schema**
```bash
mysql -u moiteek_user -p moiteek_prod < sql/database.sql

# Verify import
mysql -u moiteek_user -p moiteek_prod -e "SHOW TABLES;"
```

### **Step 4: Configure Web Server**

#### **Apache Configuration** (`/etc/apache2/sites-available/moiteek.conf`)
```apache
<VirtualHost *:80>
    ServerName yourdomain.com
    ServerAlias www.yourdomain.com
    ServerAdmin admin@yourdomain.com
    
    DocumentRoot /var/www/moiteek_academy
    
    # Redirect HTTP to HTTPS
    RewriteEngine On
    RewriteCond %{HTTPS} off
    RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
    
    <Directory /var/www/moiteek_academy>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        
        <IfModule mod_rewrite.c>
            RewriteEngine On
            RewriteCond %{REQUEST_FILENAME} !-f
            RewriteCond %{REQUEST_FILENAME} !-d
        </IfModule>
        
        Require all granted
    </Directory>
    
    <FilesMatch "\.php$">
        SetHandler "proxy:unix:/run/php/php7.4-fpm.sock|fcgi://localhost/"
    </FilesMatch>
    
    ErrorLog ${APACHE_LOG_DIR}/moiteek_error.log
    CustomLog ${APACHE_LOG_DIR}/moiteek_access.log combined
</VirtualHost>

<VirtualHost *:443>
    ServerName yourdomain.com
    ServerAlias www.yourdomain.com
    ServerAdmin admin@yourdomain.com
    
    DocumentRoot /var/www/moiteek_academy
    
    SSLEngine on
    SSLCertificateFile /etc/ssl/certs/yourdomain.com.crt
    SSLCertificateKeyFile /etc/ssl/private/yourdomain.com.key
    SSLCertificateChainFile /etc/ssl/certs/yourdomain.com.ca-bundle
    
    <Directory /var/www/moiteek_academy>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
    
    <FilesMatch "\.php$">
        SetHandler "proxy:unix:/run/php/php7.4-fpm.sock|fcgi://localhost/"
    </FilesMatch>
    
    ErrorLog ${APACHE_LOG_DIR}/moiteek_error.log
    CustomLog ${APACHE_LOG_DIR}/moiteek_access.log combined
</VirtualHost>
```

#### **Enable Site & Modules**
```bash
sudo a2ensite moiteek
sudo a2enmod rewrite
sudo a2enmod ssl
sudo a2enmod proxy
sudo a2enmod proxy_fcgi
sudo apache2ctl configtest
sudo systemctl restart apache2
```

#### **Nginx Configuration** (Alternative)
```nginx
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;
    
    # Redirect to HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name yourdomain.com www.yourdomain.com;
    
    # SSL Configuration
    ssl_certificate /etc/ssl/certs/yourdomain.com.crt;
    ssl_certificate_key /etc/ssl/private/yourdomain.com.key;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    
    root /var/www/moiteek_academy;
    index index.php index.html;
    
    # Deny access to sensitive files
    location ~ /\. {
        deny all;
    }
    location ~ /config/ {
        deny all;
    }
    location ~ /sql/ {
        deny all;
    }
    
    # PHP execution
    location ~ \.php$ {
        try_files $uri =404;
        fastcgi_pass unix:/run/php/php7.4-fpm.sock;
        fastcgi_split_path_info ^(.+\.php)(/.+)$;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
    }
    
    # Static files caching
    location ~* \.(jpg|jpeg|png|gif|ico|css|js)$ {
        expires 30d;
        add_header Cache-Control "public, immutable";
    }
    
    # Error and access logs
    error_log /var/log/nginx/moiteek_error.log;
    access_log /var/log/nginx/moiteek_access.log;
}
```

### **Step 5: SSL/HTTPS Setup**

#### **Using Let's Encrypt (Free)**
```bash
sudo apt install certbot python3-certbot-apache

# Generate certificate
sudo certbot certonly --apache \
  -d yourdomain.com \
  -d www.yourdomain.com \
  --email admin@yourdomain.com

# Auto-renewal
sudo systemctl enable certbot.timer
sudo systemctl start certbot.timer
```

### **Step 6: Backup & Monitoring**

#### **Automated Database Backup**
```bash
# Create backup script: /usr/local/bin/backup-moiteek.sh
#!/bin/bash
BACKUP_DIR="/var/backups/moiteek"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

mkdir -p $BACKUP_DIR
mysqldump -u moiteek_user -p'password' moiteek_prod | \
  gzip > $BACKUP_DIR/moiteek_$TIMESTAMP.sql.gz

# Keep only last 30 days
find $BACKUP_DIR -name "moiteek_*.sql.gz" -mtime +30 -delete
```

#### **Make executable and schedule**
```bash
chmod +x /usr/local/bin/backup-moiteek.sh

# Edit crontab
sudo crontab -e
```

Add line:
```
0 2 * * * /usr/local/bin/backup-moiteek.sh
# Runs daily at 2 AM
```

#### **Monitor Disk Space**
```bash
# Check uploads folder size
du -sh /var/www/moiteek_academy/uploads/

# Set up monitoring alert
df -h / | tail -1
```

### **Step 7: Performance Optimization**

#### **Enable Gzip Compression** (Apache)
```apache
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/plain text/xml
    AddOutputFilterByType DEFLATE text/css text/javascript
    AddOutputFilterByType DEFLATE application/javascript application/json
</IfModule>
```

#### **Enable Caching** (PHP)
```bash
# Install OPcache
sudo apt install php7.4-opcache

# Update php.ini
opcache.enable = 1
opcache.memory_consumption = 128
opcache.max_accelerated_files = 4000
opcache.validate_timestamps = 0
```

#### **Optimize Database**
```sql
-- Analyze tables
ANALYZE TABLE admins;
ANALYZE TABLE students;
ANALYZE TABLE courses;
-- ... other tables

-- Optimize tables
OPTIMIZE TABLE admins;
-- ... other tables
```

---

## 🔒 **Security Hardening**

### **File Permissions**
```bash
# Config files - readable only by web server
sudo chmod 640 /var/www/moiteek_academy/config/db.php
sudo chown www-data:www-data /var/www/moiteek_academy/config/db.php

# .env file
sudo chmod 640 /var/www/moiteek_academy/.env
sudo chown www-data:www-data /var/www/moiteek_academy/.env

# Disable directory listing
# Already configured via Options -Indexes
```

### **Firewall Configuration**
```bash
sudo ufw enable
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow 22/tcp    # SSH
sudo ufw allow 80/tcp    # HTTP
sudo ufw allow 443/tcp   # HTTPS
sudo ufw allow 3306/tcp from 127.0.0.1  # MySQL local only
```

### **Hide Sensitive Information**
Update `.htaccess`:
```apache
# Hide .env file
<FilesMatch "^\.env">
    Order allow,deny
    Deny from all
</FilesMatch>

# Hide config files
<FilesMatch "^config/">
    Order allow,deny
    Deny from all
</FilesMatch>

# Hide SQL files
<FilesMatch "\.sql$">
    Order allow,deny
    Deny from all
</FilesMatch>
```

### **Disable Directory Listing**
```bash
# Confirm in apache/nginx config - already done above
Options -Indexes
```

---

## 📊 **Monitoring & Logging**

### **Check Application Status**
```bash
# PHP-FPM status
systemctl status php7.4-fpm

# Apache status
systemctl status apache2

# MySQL status
systemctl status mysql

# View error logs
tail -f /var/log/php_errors.log
tail -f /var/log/apache2/moiteek_error.log
```

### **Monitor Performance**
```bash
# Real-time system stats
top

# Disk usage
df -h

# Memory usage
free -h

# Network connections
netstat -an | grep ESTABLISHED | wc -l
```

---

## 🚨 **Troubleshooting Deployment**

### **500 Internal Server Error**
```bash
# Check PHP error log
tail -50 /var/log/php_errors.log

# Check Apache error log
tail -50 /var/log/apache2/moiteek_error.log

# Verify file permissions
ls -la /var/www/moiteek_academy/
```

### **Database Connection Failed**
```bash
# Test connection
mysql -u moiteek_user -p -h localhost moiteek_prod

# Check MySQL is running
sudo systemctl status mysql

# Verify credentials in .env file
cat /var/www/moiteek_academy/.env | grep DB_
```

### **Slow Page Load**
```bash
# Check database size
du -sh /var/lib/mysql/moiteek_prod/

# Run OPTIMIZE
mysql -u moiteek_user -p moiteek_prod < optimize_db.sql

# Check system resources
top
```

### **Cannot Upload Files**
```bash
# Verify permissions
ls -la /var/www/moiteek_academy/uploads/

# Fix if needed
sudo chmod 775 /var/www/moiteek_academy/uploads/payments

# Check disk space
df -h /var/www
```

---

## 📈 **Post-Deployment**

### **Verify Deployment**
- [ ] Visit https://yourdomain.com - homepage loads
- [ ] Admin login works (admin@moiteek.com)
- [ ] Student login works (with approved account)
- [ ] Course browsing and search functions work
- [ ] File uploads work (test with payment proof)
- [ ] Database queries return data
- [ ] No error messages in browser console

### **Create Initial Admin**
```bash
# If needed to create new admin
mysql -u moiteek_user -p moiteek_prod <<EOF
INSERT INTO admins (fullname, email, password, phone, role, status, created_at) 
VALUES (
  'Super Admin',
  'newadmin@yourdomain.com',
  '\$2y\$10\$...',  # bcrypt hash
  '+1234567890',
  'super_admin',
  'active',
  NOW()
);
EOF
```

### **Backup First Admin Password**
Store securely (password manager):
- Username: admin
- Email: admin@moiteek.com
- Temporary Password: Admin@123
- Change this password immediately after login

---

## 🔄 **Continuous Deployment**

### **Auto-Deploy from Git** (using Webhook)
```bash
# Create deploy script: /var/www/deploy.sh
#!/bin/bash
cd /var/www/moiteek_academy
git pull origin main
composer install --no-dev  # if using composer
sudo systemctl reload apache2
```

### **Setup Github Webhook**
1. Go to repository Settings → Webhooks
2. Add webhook: https://yourdomain.com/deploy.php
3. Use POST content type
4. Create deploy.php to trigger script

---

## ✅ **Deployment Checklist**

- [ ] Server provisioned and secured
- [ ] PHP, MySQL, Web server installed
- [ ] Application code deployed
- [ ] Database imported
- [ ] .env configured with production values
- [ ] SSL certificate installed
- [ ] Web server configured
- [ ] File permissions set correctly
- [ ] Backups automated
- [ ] Monitoring configured
- [ ] Testing completed
- [ ] Admin password changed
- [ ] Initial admin account created
- [ ] Error logging configured
- [ ] Performance optimized

---

**Deployment Complete! 🚀**

For secure ongoing operation, monitor logs daily and perform regular backups.
