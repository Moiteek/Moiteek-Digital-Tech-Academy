<?php
// app/views/admin/payments_dashboard.php
// Admin dashboard for payment review, manual override, and logs
?>
<div class="container mx-auto p-4">
  <h1 class="text-2xl font-bold mb-4">Payments Dashboard</h1>
  <table class="min-w-full bg-white border">
    <thead>
      <tr>
        <th>ID</th><th>Student</th><th>Course</th><th>Amount</th><th>Gateway</th><th>Status</th><th>Manual</th><th>Logs</th><th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($payments as $p): ?>
      <tr>
        <td><?= $p['id'] ?></td>
        <td><?= htmlspecialchars($p['student_name']) ?></td>
        <td><?= htmlspecialchars($p['course_title']) ?></td>
        <td><?= $p['amount'] ?></td>
        <td><?= $p['gateway'] ?></td>
        <td><?= $p['payment_status'] ?></td>
        <td><?= $p['manual_override'] ? 'Yes' : 'No' ?></td>
        <td><a href="/admin/payment_logs.php?payment_id=<?= $p['id'] ?>" class="text-blue-600">View</a></td>
        <td>
          <form method="POST" action="/admin/manual_override.php">
            <input type="hidden" name="payment_id" value="<?= $p['id'] ?>">
            <select name="status">
              <option value="approved">Approve</option>
              <option value="rejected">Reject</option>
            </select>
            <input type="text" name="reason" placeholder="Reason" class="border px-2">
            <button type="submit" class="bg-blue-600 text-white px-2 py-1 rounded">Override</button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
