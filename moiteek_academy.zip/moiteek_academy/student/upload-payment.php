<?php
/**
 * Student Payment Upload Page
 * Allows students to upload payment proof for course enrollment
 */

require_once '../bootstrap.php';

// Check if student is logged in
if (!Auth::isStudentLoggedIn()) {
    header('Location: ../auth/login.php');
    exit;
}

$student_id = Auth::getCurrentUserId();
$course_id = $_GET['course_id'] ?? null;
$message = '';
$message_type = 'info';
$upload_dir = '../uploads/payment_proofs/';

// Create upload directory if it doesn't exist
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

// Get course details
$courseName = '';
$coursePrice = 0;
if ($course_id) {
    $stmt = $pdo->prepare('SELECT title, price FROM courses WHERE id = ?');
    $stmt->execute([$course_id]);
    $course = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($course) {
        $courseName = $course['title'];
        $coursePrice = $course['price'];
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!CSRF::validateRequest()) {
        $message = 'Security validation failed. Please try again.';
        $message_type = 'error';
    } else {
        // Validate required fields
        if (empty($course_id) || !$courseName) {
            $message = 'Invalid course selected.';
            $message_type = 'error';
        } elseif (empty($_POST['payment_date']) || empty($_POST['payment_method']) || empty($_POST['amount'])) {
            $message = 'Please fill in all fields.';
            $message_type = 'error';
        } elseif (empty($_FILES['payment_proof']['name'])) {
            $message = 'Please select a file to upload.';
            $message_type = 'error';
        } else {
            // Validate file
            $file = $_FILES['payment_proof'];
            $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'application/pdf'];
            $max_size = 5 * 1024 * 1024; // 5MB
            
            if ($file['size'] > $max_size) {
                $message = 'File size exceeds 5MB limit.';
                $message_type = 'error';
            } elseif (!in_array($file['type'], $allowed_types)) {
                $message = 'Only JPG, PNG, GIF, and PDF files are allowed.';
                $message_type = 'error';
            } elseif ($file['error'] !== UPLOAD_ERR_OK) {
                $message = 'File upload error. Please try again.';
                $message_type = 'error';
            } else {
                try {
                    // Generate unique filename
                    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
                    $filename = 'payment_' . $student_id . '_' . $course_id . '_' . time() . '.' . $ext;
                    $filepath = $upload_dir . $filename;
                    
                    // Move uploaded file
                    if (move_uploaded_file($file['tmp_name'], $filepath)) {
                        // Generate unique reference number
                        $reference = 'PAY-' . date('YmdHis') . '-' . random_int(1000, 9999);
                        
                        // Check if student already has pending payment for this course
                        $existingStmt = $pdo->prepare(
                            'SELECT id FROM payments WHERE student_id = ? AND course_id = ? AND status = ?'
                        );
                        $existingStmt->execute([$student_id, $course_id, 'pending']);
                        
                        if ($existingStmt->fetch()) {
                            $message = 'You already have a pending payment for this course. Please wait for admin review.';
                            $message_type = 'warning';
                            unlink($filepath); // Delete the uploaded file
                        } else {
                            // Insert payment record
                            $stmt = $pdo->prepare(
                                'INSERT INTO payments 
                                (student_id, course_id, amount, currency, payment_method, reference_number, 
                                 proof_file_path, proof_file_type, payment_date_submitted, status, created_at)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)'
                            );
                            
                            $paymentDate = $_POST['payment_date'] . ' 00:00:00';
                            
                            $stmt->execute([
                                $student_id,
                                $course_id,
                                $_POST['amount'],
                                'USD',
                                $_POST['payment_method'],
                                $reference,
                                $filename,
                                $file['type'],
                                $paymentDate,
                                'pending'
                            ]);
                            
                            $message = 'Payment submitted successfully! Admin will review your proof shortly.';
                            $message_type = 'success';
                        }
                    } else {
                        $message = 'Failed to upload file. Please try again.';
                        $message_type = 'error';
                    }
                } catch (Exception $e) {
                    $message = 'Error processing payment: ' . $e->getMessage();
                    $message_type = 'error';
                    error_log('Payment upload error: ' . $e->getMessage());
                }
            }
        }
    }

    // AJAX/JSON payment upload handler
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax'])) {
        $response = ['status' => 'error', 'message' => 'Unknown error'];
        if (!CSRF::validateRequest()) {
            $response = ['status' => 'error', 'message' => 'Security validation failed. Please try again.'];
        } elseif (empty($course_id) || !$courseName) {
            $response = ['status' => 'error', 'message' => 'Invalid course selected.'];
        } elseif (empty($_POST['payment_date']) || empty($_POST['payment_method']) || empty($_POST['amount'])) {
            $response = ['status' => 'error', 'message' => 'Please fill in all fields.'];
        } elseif (empty($_FILES['payment_proof']['name'])) {
            $response = ['status' => 'error', 'message' => 'Please select a file to upload.'];
        } else {
            $file = $_FILES['payment_proof'];
            $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'application/pdf'];
            $max_size = 5 * 1024 * 1024;
            if (!in_array($file['type'], $allowed_types)) {
                $response = ['status' => 'error', 'message' => 'Invalid file type.'];
            } elseif ($file['size'] > $max_size) {
                $response = ['status' => 'error', 'message' => 'File too large. Max 5MB.'];
            } else {
                try {
                    // Generate unique filename
                    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
                    $filename = 'payment_' . $student_id . '_' . $course_id . '_' . time() . '.' . $ext;
                    $filepath = $upload_dir . $filename;
                    
                    // Move uploaded file
                    if (move_uploaded_file($file['tmp_name'], $filepath)) {
                        // Generate unique reference number
                        $reference = 'PAY-' . date('YmdHis') . '-' . random_int(1000, 9999);
                        
                        // Check if student already has pending payment for this course
                        $existingStmt = $pdo->prepare(
                            'SELECT id FROM payments WHERE student_id = ? AND course_id = ? AND status = ?'
                        );
                        $existingStmt->execute([$student_id, $course_id, 'pending']);
                        
                        if ($existingStmt->fetch()) {
                            $response = ['status' => 'warning', 'message' => 'You already have a pending payment for this course. Please wait for admin review.'];
                            unlink($filepath); // Delete the uploaded file
                        } else {
                            // Insert payment record
                            $stmt = $pdo->prepare(
                                'INSERT INTO payments 
                                (student_id, course_id, amount, currency, payment_method, reference_number, 
                                 proof_file_path, proof_file_type, payment_date_submitted, status, created_at)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)'
                            );
                            
                            $paymentDate = $_POST['payment_date'] . ' 00:00:00';
                            
                            $stmt->execute([
                                $student_id,
                                $course_id,
                                $_POST['amount'],
                                'USD',
                                $_POST['payment_method'],
                                $reference,
                                $filename,
                                $file['type'],
                                $paymentDate,
                                'pending'
                            ]);
                            
                            $response = ['status' => 'success', 'message' => 'Payment proof uploaded successfully!'];
                        }
                    } else {
                        $response = ['status' => 'error', 'message' => 'Failed to upload file. Please try again.'];
                    }
                } catch (Exception $e) {
                    $response = ['status' => 'error', 'message' => 'Error processing payment: ' . $e->getMessage()];
                    error_log('Payment upload error: ' . $e->getMessage());
                }
            }
        }
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    }
}

// Get student's pending payments
$stmt = $pdo->prepare(
    'SELECT p.*, c.title as course_title 
     FROM payments p 
     JOIN courses c ON p.course_id = c.id
     WHERE p.student_id = ? 
     ORDER BY p.created_at DESC'
);
$stmt->execute([$student_id]);
$payments = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Payment Proof - Moiteek Academy</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50">
    <div class="min-h-screen">
        <!-- Header -->
        <div class="bg-white border-b">
            <div class="max-w-7xl mx-auto px-4 py-4">
                <div class="flex justify-between items-center">
                    <div class="flex items-center gap-2">
                        <i class="fas fa-graduation-cap text-blue-600 text-2xl"></i>
                        <h1 class="text-2xl font-bold text-gray-800">Moiteek Academy</h1>
                    </div>
                    <div>
                        <a href="dashboard.php" class="text-blue-600 hover:text-blue-800 mr-4">
                            <i class="fas fa-arrow-left"></i> Back
                        </a>
                        <a href="../auth/logout.php" class="text-red-600 hover:text-red-800">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="max-w-7xl mx-auto px-4 py-8">
            <!-- Messages -->
            <?php if ($message): ?>
                <div class="mb-6 p-4 rounded-lg border-l-4 
                    <?php
                    if ($message_type === 'success') echo 'bg-green-50 border-green-400 text-green-800';
                    elseif ($message_type === 'error') echo 'bg-red-50 border-red-400 text-red-800';
                    elseif ($message_type === 'warning') echo 'bg-yellow-50 border-yellow-400 text-yellow-800';
                    else echo 'bg-blue-50 border-blue-400 text-blue-800';
                    ?>">
                    <div class="flex gap-2">
                        <i class="fas fa-<?php
                        if ($message_type === 'success') echo 'check-circle';
                        elseif ($message_type === 'error') echo 'exclamation-circle';
                        elseif ($message_type === 'warning') echo 'info-circle';
                        else echo 'info-circle';
                        ?> mt-1"></i>
                        <div><?php echo htmlspecialchars($message); ?></div>
                    </div>
                </div>
            <?php endif; ?>

            <div class="grid md:grid-cols-3 gap-8">
                <!-- Upload Form -->
                <div class="md:col-span-2">
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h2 class="text-2xl font-bold mb-6 text-gray-800">
                            <i class="fas fa-upload text-blue-600 mr-2"></i>Upload Payment Proof
                        </h2>
                        
                        <?php if ($course_id && $courseName): ?>
                            <form method="POST" enctype="multipart/form-data" class="space-y-6">
                                <!-- CSRF Token -->
                                <?php echo CSRF::generateTokenField(); ?>

                                <!-- Course Information -->
                                <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                                    <p class="text-sm text-gray-600">Course</p>
                                    <p class="text-lg font-semibold text-gray-800"><?php echo htmlspecialchars($courseName); ?></p>
                                    <p class="text-sm text-gray-600 mt-2">Amount to Pay: <span class="font-bold text-blue-600">$<?php echo number_format($coursePrice, 2); ?></span></p>
                                </div>

                                <!-- Payment Date -->
                                <div>
                                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                                        <i class="fas fa-calendar-alt mr-2"></i>Payment Date
                                    </label>
                                    <input type="date" name="payment_date" required 
                                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                           max="<?php echo date('Y-m-d'); ?>">
                                    <p class="text-sm text-gray-500 mt-1">When did you make the payment?</p>
                                </div>

                                <!-- Payment Method -->
                                <div>
                                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                                        <i class="fas fa-credit-card mr-2"></i>Payment Method
                                    </label>
                                    <select name="payment_method" required 
                                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                        <option value="">Select payment method</option>
                                        <option value="bank_transfer">Bank Transfer</option>
                                        <option value="mobile_money">Mobile Money</option>
                                        <option value="crypto">Cryptocurrency</option>
                                        <option value="other">Other</option>
                                    </select>
                                </div>

                                <!-- Amount -->
                                <div>
                                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                                        <i class="fas fa-dollar-sign mr-2"></i>Amount Paid
                                    </label>
                                    <input type="number" name="amount" step="0.01" required 
                                           value="<?php echo $coursePrice; ?>"
                                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                    <p class="text-sm text-gray-500 mt-1">Enter the exact amount you paid</p>
                                </div>

                                <!-- Payment Proof File -->
                                <div>
                                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                                        <i class="fas fa-file-upload mr-2"></i>Payment Proof
                                    </label>
                                    <div class="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center cursor-pointer hover:border-blue-500 transition"
                                         onclick="document.getElementById('fileInput').click();">
                                        <input type="file" id="fileInput" name="payment_proof" accept="image/*,.pdf" required 
                                               class="hidden"
                                               onchange="displayFileName(this);">
                                        <i class="fas fa-cloud-upload-alt text-4xl text-gray-400 mb-2"></i>
                                        <p class="text-gray-600 font-semibold">Click to upload payment proof</p>
                                        <p class="text-sm text-gray-500 mt-1">JPG, PNG, GIF, or PDF (max 5MB)</p>
                                        <p class="text-sm text-gray-500 mt-2" id="fileName"></p>
                                    </div>
                                </div>

                                <!-- Information Box -->
                                <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                                    <p class="text-sm text-gray-700">
                                        <i class="fas fa-lightbulb text-yellow-600 mr-2"></i>
                                        <strong>Tips:</strong> Take a clear screenshot or photo of your payment confirmation. Include: transaction ID, amount, date, and recipient details.
                                    </p>
                                </div>

                                <!-- Submit Button -->
                                <div>
                                    <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition">
                                        <i class="fas fa-send mr-2"></i>Submit Payment Proof
                                    </button>
                                </div>
                            </form>
                        <?php else: ?>
                            <div class="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
                                <i class="fas fa-exclamation-circle text-4xl text-red-400 mb-3"></i>
                                <p class="text-gray-700">No course selected</p>
                                <p class="text-sm text-gray-600 mt-2">Please select a course from your dashboard</p>
                                <a href="dashboard.php" class="inline-block mt-4 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg">
                                    Go to Dashboard
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Payment History Sidebar -->
                <div class="md:col-span-1">
                    <div class="bg-white rounded-lg shadow-md p-6 sticky top-20">
                        <h3 class="text-lg font-bold text-gray-800 mb-4">
                            <i class="fas fa-history text-blue-600 mr-2"></i>Payment History
                        </h3>
                        
                        <?php if ($payments): ?>
                            <div class="space-y-3 max-h-96 overflow-y-auto">
                                <?php foreach ($payments as $payment): ?>
                                    <div class="border rounded-lg p-3 hover:bg-gray-50 transition">
                                        <p class="font-semibold text-sm text-gray-800">
                                            <?php echo htmlspecialchars(substr($payment['course_title'], 0, 30)); ?>
                                        </p>
                                        <p class="text-xs text-gray-600 mt-1">
                                            Amount: $<?php echo number_format($payment['amount'], 2); ?>
                                        </p>
                                        <p class="text-xs text-gray-600">
                                            Ref: <?php echo htmlspecialchars($payment['reference_number']); ?>
                                        </p>
                                        <span class="inline-block mt-2 px-2 py-1 text-xs font-semibold rounded-full
                                            <?php
                                            if ($payment['status'] === 'approved') echo 'bg-green-100 text-green-800';
                                            elseif ($payment['status'] === 'rejected') echo 'bg-red-100 text-red-800';
                                            elseif ($payment['status'] === 'pending') echo 'bg-yellow-100 text-yellow-800';
                                            else echo 'bg-gray-100 text-gray-800';
                                            ?>">
                                            <?php echo ucfirst($payment['status']); ?>
                                        </span>
                                        <?php if ($payment['rejection_reason']): ?>
                                            <p class="text-xs text-red-600 mt-2">
                                                <i class="fas fa-times-circle mr-1"></i>
                                                <?php echo htmlspecialchars(substr($payment['rejection_reason'], 0, 50)); ?>
                                            </p>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <p class="text-gray-500 text-sm">No payments submitted yet</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function displayFileName(input) {
            const fileName = document.getElementById('fileName');
            if (input.files && input.files[0]) {
                const file = input.files[0];
                const sizeMb = (file.size / (1024 * 1024)).toFixed(2);
                fileName.textContent = `Selected: ${file.name} (${sizeMb}MB)`;
            }
        }
    </script>
</body>
</html>
