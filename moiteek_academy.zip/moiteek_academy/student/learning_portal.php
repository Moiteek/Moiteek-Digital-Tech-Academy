<?php
require_once '../includes/bootstrap.php';
require_once '../includes/auth_check.php';
requireStudent();

$studentId = $_SESSION['student_id'];
$courseId = isset($_GET['course_id']) ? (int)$_GET['course_id'] : 0;
if (!$courseId) {
    Response::redirect('dashboard.php', 'No course selected.', 'error');
}

// Fetch lessons for the course
$stmt = $pdo->prepare('SELECT id, title, video_url FROM lessons WHERE course_id = ? ORDER BY lesson_order ASC');
$stmt->execute([$courseId]);
$lessons = $stmt->fetchAll();

// Fetch progress
$progressStmt = $pdo->prepare('SELECT lesson_id, status FROM progress WHERE student_id = ?');
$progressStmt->execute([$studentId]);
$progressArr = $progressStmt->fetchAll(PDO::FETCH_KEY_PAIR);

// Get current lesson
$currentLessonId = isset($_GET['lesson_id']) ? (int)$_GET['lesson_id'] : ($lessons[0]['id'] ?? 0);
$currentLesson = null;
foreach ($lessons as $lesson) {
    if ($lesson['id'] == $currentLessonId) {
        $currentLesson = $lesson;
        break;
    }
}
if (!$currentLesson && $lessons) {
    $currentLesson = $lessons[0];
    $currentLessonId = $currentLesson['id'];
}

// Mark as completed
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mark_completed'])) {
    $stmt = $pdo->prepare('REPLACE INTO progress (student_id, lesson_id, status) VALUES (?, ?, ?)');
    $stmt->execute([$studentId, $currentLessonId, 'completed']);
    header('Location: learning_portal.php?course_id=' . $courseId . '&lesson_id=' . $currentLessonId . '&completed=1');
    exit;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Learning Portal</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100">
<div class="flex min-h-screen">
    <!-- Sidebar -->
    <aside class="w-64 bg-blue-900 text-white flex-shrink-0 p-6">
        <h2 class="text-2xl font-bold mb-8 text-gold-400">Lessons</h2>
        <ul class="space-y-3">
            <?php foreach ($lessons as $lesson): ?>
                <li>
                    <a href="?course_id=<?= $courseId ?>&lesson_id=<?= $lesson['id'] ?>" class="block px-4 py-2 rounded transition <?= $lesson['id'] == $currentLessonId ? 'bg-gold-400 text-blue-900 font-bold' : 'hover:bg-blue-800' ?>">
                        <?= htmlspecialchars($lesson['title']) ?>
                        <?php if (($progressArr[$lesson['id']] ?? '') === 'completed'): ?>
                            <i class="fas fa-check-circle text-green-400 ml-2"></i>
                        <?php endif; ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    </aside>
    <!-- Main Content -->
    <main class="flex-1 p-10">
        <?php if ($currentLesson): ?>
            <h1 class="text-3xl font-bold text-blue-900 mb-6"><?= htmlspecialchars($currentLesson['title']) ?></h1>
            <div class="mb-8 aspect-w-16 aspect-h-9">
                <iframe class="w-full h-96 rounded-lg shadow-lg" src="<?= htmlspecialchars($currentLesson['video_url']) ?>" frameborder="0" allowfullscreen></iframe>
            </div>
            <form method="post">
                <button type="submit" name="mark_completed" class="bg-gold-400 text-blue-900 px-6 py-3 rounded-lg font-bold shadow hover:bg-gold-300 transition">Mark as Completed</button>
            </form>
            <?php if (isset($_GET['completed'])): ?>
                <div class="mt-4 p-4 bg-green-100 border-l-4 border-green-500 text-green-900 rounded">Lesson marked as completed!</div>
            <?php endif; ?>
        <?php else: ?>
            <p>No lessons found for this course.</p>
        <?php endif; ?>
    </main>
</div>
<style>
    .bg-gold-400 { background-color: #FFD700; }
    .text-gold-400 { color: #FFD700; }
    .hover\:bg-gold-300:hover { background-color: #FFEB99; }
</style>
</body>
</html>
