<?php
require_once '../bootstrap.php';

if(!Auth::isAdminLoggedIn()) {
    Response::redirect('../admin/login.php', 'Please login', 'error');
}

// Handle course actions
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    if(isset($_POST['action'])) {
        $action = $_POST['action'];
        
        if($action === 'delete') {
            $course_id = (int)$_POST['course_id'];
            $pdo->prepare("DELETE FROM enrollments WHERE course_id = ?")->execute([$course_id]);
            $pdo->prepare("DELETE FROM course_modules WHERE course_id = ?")->execute([$course_id]);
            $pdo->prepare("DELETE FROM course_resources WHERE course_id = ?")->execute([$course_id]);
            $pdo->prepare("DELETE FROM courses WHERE id = ?")->execute([$course_id]);
            Response::redirect('courses.php', 'Course deleted successfully!', 'success');
        }
        elseif($action === 'publish') {
            $course_id = (int)$_POST['course_id'];
            $pdo->prepare("UPDATE courses SET is_published = 1 WHERE id = ?")->execute([$course_id]);
            Response::redirect('courses.php', 'Course published!', 'success');
        }
        elseif($action === 'unpublish') {
            $course_id = (int)$_POST['course_id'];
            $pdo->prepare("UPDATE courses SET is_published = 0 WHERE id = ?")->execute([$course_id]);
            Response::redirect('courses.php', 'Course unpublished!', 'success');
        }
    }
}

// Get courses with enrollment count
$courses = $pdo->query("
    SELECT c.*, COUNT(e.id) as enrollment_count 
    FROM courses c 
    LEFT JOIN enrollments e ON c.id = e.course_id 
    GROUP BY c.id 
    ORDER BY c.created_at DESC
")->fetchAll();

$flash = Response::getFlashMessage();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Courses Management - <?= APP_NAME ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <i class="fas fa-graduation-cap text-2xl text-blue-600"></i>
                <span class="font-bold text-lg text-gray-800"><?= APP_NAME ?></span>
            </div>
            <div class="flex items-center gap-4">
                <a href="dashboard.php" class="text-gray-600 hover:text-blue-600">
                    <i class="fas fa-home mr-1"></i>Dashboard
                </a>
                <a href="../auth/logout.php" class="p-2 text-gray-600 hover:bg-red-50 hover:text-red-600 rounded-lg transition">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </div>
    </nav>

    <div class="flex">
        <!-- Sidebar -->
        <aside class="w-64 bg-white shadow-lg min-h-screen">
            <div class="p-4 space-y-2">
                <a href="dashboard.php" class="block px-4 py-3 rounded-lg hover:bg-gray-100 transition">
                    <i class="fas fa-chart-line mr-2"></i>Dashboard
                </a>
                <a href="students.php" class="block px-4 py-3 rounded-lg hover:bg-gray-100 transition">
                    <i class="fas fa-users mr-2"></i>Students
                </a>
                <a href="courses.php" class="block px-4 py-3 rounded-lg bg-blue-600 text-white font-semibold">
                    <i class="fas fa-book mr-2"></i>Courses
                </a>
                <a href="payments.php" class="block px-4 py-3 rounded-lg hover:bg-gray-100 transition">
                    <i class="fas fa-credit-card mr-2"></i>Payments
                </a>
                <a href="enrollments.php" class="block px-4 py-3 rounded-lg hover:bg-gray-100 transition">
                    <i class="fas fa-list mr-2"></i>Enrollments
                </a>
                <hr class="my-3">
                <a href="analytics.php" class="block px-4 py-3 rounded-lg hover:bg-gray-100 transition">
                    <i class="fas fa-chart-bar mr-2"></i>Analytics
                </a>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="flex-1 p-8">
            <!-- Flash Message -->
            <?php if($flash): ?>
                <div class="mb-6 p-4 rounded-lg bg-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-50 border border-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-200 flex items-center gap-3">
                    <i class="fas fa-<?= $flash['type'] === 'error' ? 'exclamation-circle' : 'check-circle' ?> text-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-600"></i>
                    <p class="text-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-700"><?= htmlspecialchars($flash['message']) ?></p>
                </div>
            <?php endif; ?>

            <!-- Page Header -->
            <div class="mb-8 flex items-center justify-between">
                <div>
                    <h1 class="text-3xl font-bold text-gray-800 flex items-center gap-2">
                        <i class="fas fa-book text-blue-600"></i>Courses Management
                    </h1>
                    <p class="text-gray-600 mt-1">Create and manage all courses</p>
                </div>
                <a href="course-form.php" class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 font-semibold transition flex items-center gap-2">
                    <i class="fas fa-plus-circle"></i>Add New Course
                </a>
            </div>

            <!-- Courses Grid -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php if(empty($courses)): ?>
                    <div class="col-span-full text-center py-12">
                        <i class="fas fa-book text-6xl text-gray-300 mb-3"></i>
                        <p class="text-gray-500 mb-4">No courses yet</p>
                        <a href="course-form.php" class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 inline-block">
                            <i class="fas fa-plus mr-2"></i>Create First Course
                        </a>
                    </div>
                <?php else: ?>
                    <?php foreach($courses as $course): ?>
                        <div class="bg-white rounded-lg shadow hover:shadow-lg transition overflow-hidden">
                            <!-- Header -->
                            <div class="h-32 bg-gradient-to-r from-blue-500 to-purple-600 flex items-center justify-center relative">
                                <i class="fas fa-book text-5xl text-white opacity-50"></i>
                                <?php if($course['is_published']): ?>
                                    <span class="absolute top-3 right-3 px-3 py-1 bg-green-500 text-white text-xs font-bold rounded-full">Published</span>
                                <?php else: ?>
                                    <span class="absolute top-3 right-3 px-3 py-1 bg-yellow-500 text-white text-xs font-bold rounded-full">Draft</span>
                                <?php endif; ?>
                            </div>

                            <!-- Content -->
                            <div class="p-6">
                                <h3 class="text-lg font-bold text-gray-800 mb-2 line-clamp-2"><?= htmlspecialchars($course['title']) ?></h3>
                                <p class="text-gray-600 text-sm mb-4 line-clamp-2"><?= htmlspecialchars($course['description']) ?></p>

                                <!-- Course Stats -->
                                <div class="flex items-center justify-between mb-4 pb-4 border-b text-sm">
                                    <div class="text-center">
                                        <p class="font-bold text-gray-800"><?= $course['total_modules'] ?? 0 ?></p>
                                        <p class="text-xs text-gray-500">Modules</p>
                                    </div>
                                    <div class="text-center">
                                        <p class="font-bold text-gray-800"><?= $course['enrollment_count'] ?></p>
                                        <p class="text-xs text-gray-500">Enrollments</p>
                                    </div>
                                    <div class="text-center">
                                        <p class="font-bold text-green-600"><?= Helper::formatCurrency($course['price']) ?></p>
                                        <p class="text-xs text-gray-500">Price</p>
                                    </div>
                                </div>

                                <!-- Actions -->
                                <div class="space-y-2">
                                    <a href="course-detail.php?id=<?= $course['id'] ?>" class="block w-full text-center px-4 py-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 font-semibold transition">
                                        <i class="fas fa-eye mr-1"></i>View Details
                                    </a>
                                    <a href="course-form.php?id=<?= $course['id'] ?>" class="block w-full text-center px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 font-semibold transition">
                                        <i class="fas fa-edit mr-1"></i>Edit
                                    </a>
                                    <div class="grid grid-cols-2 gap-2">
                                        <?php if($course['is_published']): ?>
                                            <form method="POST" style="display:inline;">
                                                <input type="hidden" name="course_id" value="<?= $course['id'] ?>">
                                                <input type="hidden" name="action" value="unpublish">
                                                <button type="submit" class="w-full px-3 py-2 bg-yellow-100 text-yellow-600 rounded-lg hover:bg-yellow-200 font-semibold text-sm transition">
                                                    <i class="fas fa-eye-slash"></i>Unpublish
                                                </button>
                                            </form>
                                        <?php else: ?>
                                            <form method="POST" style="display:inline;">
                                                <input type="hidden" name="course_id" value="<?= $course['id'] ?>">
                                                <input type="hidden" name="action" value="publish">
                                                <button type="submit" class="w-full px-3 py-2 bg-green-100 text-green-600 rounded-lg hover:bg-green-200 font-semibold text-sm transition">
                                                    <i class="fas fa-eye"></i>Publish
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                        <form method="POST" style="display:inline;">
                                            <input type="hidden" name="course_id" value="<?= $course['id'] ?>">
                                            <input type="hidden" name="action" value="delete">
                                            <button type="submit" onclick="return confirm('Delete this course and all related data?')" class="w-full px-3 py-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 font-semibold text-sm transition">
                                                <i class="fas fa-trash"></i>Delete
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </main>
    </div>
</body>
</html>
            <?php foreach($courses as $course): ?>
                <div class="bg-white rounded-lg shadow hover:shadow-lg transition overflow-hidden">
                    <div class="h-40 bg-gradient-to-r from-blue-500 to-purple-600 flex items-center justify-center">
                        <i class="fas fa-book text-4xl text-white"></i>
                    </div>
                    <div class="p-4">
                        <h3 class="font-bold text-gray-800 mb-2"><?= htmlspecialchars($course['title']) ?></h3>
                        <p class="text-sm text-gray-600 mb-4"><?= htmlspecialchars(substr($course['description'], 0, 80)) ?>...</p>
                        <div class="flex items-center justify-between text-sm mb-4">
                            <span class="text-blue-600 font-bold"><?= Helper::formatCurrency($course['price']) ?></span>
                            <span class="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs font-semibold">
                                <?= ucfirst($course['level']) ?>
                            </span>
                        </div>
                        <div class="flex gap-2">
                            <a href="course_edit.php?id=<?= $course['id'] ?>" class="flex-1 text-center bg-blue-100 text-blue-600 px-3 py-2 rounded hover:bg-blue-200">
                                <i class="fas fa-edit"></i> Edit
                            </a>
                            <a href="course.php?id=<?= $course['id'] ?>" class="flex-1 text-center bg-gray-100 text-gray-600 px-3 py-2 rounded hover:bg-gray-200">
                                <i class="fas fa-eye"></i> View
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>