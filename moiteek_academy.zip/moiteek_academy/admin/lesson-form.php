<?php
require_once '../bootstrap.php';

if(!Auth::isAdminLoggedIn()) {
    Response::redirect('../admin/login.php', 'Please login', 'error');
}

$lesson = null;
$course = null;
$mode = 'add';

// Get course
$course_id = (int)($_GET['course_id'] ?? $_POST['course_id'] ?? 0);
if($course_id) {
    $stmt = $pdo->prepare("SELECT * FROM courses WHERE id = ?");
    $stmt->execute([$course_id]);
    $course = $stmt->fetch();
    if(!$course) {
        Response::redirect('courses.php', 'Course not found', 'error');
    }
}

// Get lesson if editing
if(isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $stmt = $pdo->prepare("SELECT * FROM course_modules WHERE id = ?");
    $stmt->execute([$id]);
    $lesson = $stmt->fetch();
    if(!$lesson) {
        Response::redirect('courses.php', 'Lesson not found', 'error');
    }
    $course_id = $lesson['course_id'];
    $mode = 'edit';
}

if(!$course && !$lesson) {
    Response::redirect('courses.php', 'Invalid request', 'error');
}

// Handle form submission
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = Validator::sanitizeInput($_POST['title'] ?? '');
    $description = Validator::sanitizeInput($_POST['description'] ?? '');
    $content = Validator::sanitizeInput($_POST['content'] ?? '');
    $video_url = Validator::sanitizeInput($_POST['video_url'] ?? '');
    $duration = (int)($_POST['duration'] ?? 0);
    $sequence_order = (int)($_POST['sequence_order'] ?? 0);
    
    if(empty($title)) {
        Response::redirect('lesson-form.php?course_id=' . $course_id, 'Lesson title is required', 'error');
    }
    
    if($mode === 'add') {
        $stmt = $pdo->prepare("
            INSERT INTO course_modules (course_id, title, description, content, video_url, duration, sequence_order)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$course_id, $title, $description, $content, $video_url, $duration, $sequence_order]);
        
        // Update module count
        $pdo->prepare("UPDATE courses SET total_modules = total_modules + 1 WHERE id = ?")->execute([$course_id]);
        
        Response::redirect('course-form.php?id=' . $course_id, 'Lesson added successfully!', 'success');
    } else {
        $stmt = $pdo->prepare("
            UPDATE course_modules 
            SET title = ?, description = ?, content = ?, video_url = ?, duration = ?, sequence_order = ?
            WHERE id = ?
        ");
        $stmt->execute([$title, $description, $content, $video_url, $duration, $sequence_order, $lesson['id']]);
        Response::redirect('course-form.php?id=' . $course_id, 'Lesson updated successfully!', 'success');
    }
}

$flash = Response::getFlashMessage();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= ucfirst($mode) ?> Lesson - <?= APP_NAME ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <i class="fas fa-graduation-cap text-2xl text-blue-600"></i>
                <span class="font-bold text-lg text-gray-800"><?= APP_NAME ?></span>
            </div>
            <a href="course-form.php?id=<?= $course_id ?>" class="text-gray-600 hover:text-blue-600">
                <i class="fas fa-arrow-left mr-1"></i>Back to Course
            </a>
        </div>
    </nav>

    <div class="max-w-4xl mx-auto p-8">
        <!-- Flash Message -->
        <?php if($flash): ?>
            <div class="mb-6 p-4 rounded-lg bg-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-50 border border-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-200 flex items-center gap-3">
                <i class="fas fa-<?= $flash['type'] === 'error' ? 'exclamation-circle' : 'check-circle' ?> text-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-600"></i>
                <p class="text-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-700"><?= htmlspecialchars($flash['message']) ?></p>
            </div>
        <?php endif; ?>

        <!-- Form -->
        <div class="bg-white rounded-lg shadow overflow-hidden">
            <div class="bg-gradient-to-r from-purple-500 to-pink-600 p-6 text-white">
                <h1 class="text-3xl font-bold flex items-center gap-2">
                    <i class="fas fa-video"></i>
                    <?= ucfirst($mode) ?> Lesson
                </h1>
                <p class="text-purple-100 mt-2">Course: <?= htmlspecialchars($course['title'] ?? '') ?></p>
            </div>

            <div class="p-8 space-y-6">
                <form method="POST">
                    <input type="hidden" name="course_id" value="<?= $course_id ?>">

                    <!-- Lesson Title -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Lesson Title *</label>
                        <input type="text" name="title" value="<?= $lesson ? htmlspecialchars($lesson['title']) : '' ?>" required 
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" 
                            placeholder="e.g., Introduction to HTML">
                    </div>

                    <!-- Description -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Short Description</label>
                        <textarea name="description" rows="3" 
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="Brief lesson description"><?= $lesson ? htmlspecialchars($lesson['description']) : '' ?></textarea>
                    </div>

                    <!-- Video URL -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">
                            <i class="fas fa-youtube text-red-600 mr-1"></i>YouTube Video URL or ID
                        </label>
                        <input type="text" name="video_url" value="<?= $lesson ? htmlspecialchars($lesson['video_url']) : '' ?>" 
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" 
                            placeholder="https://www.youtube.com/watch?v=dQw4w9WgXcQ or just dQw4w9WgXcQ">
                        <p class="text-xs text-gray-600 mt-1">ⓘ Supports full URLs, short URLs, or just the video ID</p>
                    </div>

                    <!-- Lesson Content -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Detailed Content</label>
                        <textarea name="content" rows="6" 
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono text-sm"
                            placeholder="Detailed lesson content (supports markdown)"><?= $lesson ? htmlspecialchars($lesson['content']) : '' ?></textarea>
                        <p class="text-xs text-gray-600 mt-1">ⓘ You can use markdown formatting here</p>
                    </div>

                    <!-- Grid Row -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <!-- Duration -->
                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-2">Duration (minutes)</label>
                            <input type="number" name="duration" value="<?= $lesson ? $lesson['duration'] : '' ?>" min="1"
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                                placeholder="45">
                        </div>

                        <!-- Sequence Order -->
                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-2">Lesson Order (position)</label>
                            <input type="number" name="sequence_order" value="<?= $lesson ? $lesson['sequence_order'] : '' ?>" min="0"
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                                placeholder="1">
                            <p class="text-xs text-gray-600 mt-1">ⓘ Lower numbers appear first</p>
                        </div>
                    </div>

                    <!-- Actions -->
                    <div class="flex gap-4 pt-6 border-t">
                        <button type="submit" class="flex-1 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 font-semibold transition">
                            <i class="fas fa-save mr-2"></i><?= $mode === 'edit' ? 'Update' : 'Create' ?> Lesson
                        </button>
                        <a href="course-form.php?id=<?= $course_id ?>" class="flex-1 bg-gray-300 text-gray-800 px-6 py-3 rounded-lg hover:bg-gray-400 font-semibold transition text-center">
                            <i class="fas fa-times mr-2"></i>Cancel
                        </a>
                    </div>
                </form>
            </div>
        </div>

        <!-- YouTube Preview -->
        <div class="mt-8 bg-white rounded-lg shadow overflow-hidden">
            <div class="bg-gray-50 p-6 border-b">
                <h2 class="text-lg font-bold text-gray-800 flex items-center gap-2">
                    <i class="fas fa-eye text-blue-600"></i>Video Preview
                </h2>
            </div>
            <div class="p-6">
                <?php if($lesson && $lesson['video_url']): ?>
                    <div class="aspect-video bg-black rounded-lg overflow-hidden">
                        <?php
                        // Extract YouTube ID
                        $url = $lesson['video_url'];
                        $id = null;
                        
                        if(preg_match('/(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]+)/', $url, $matches)) {
                            $id = $matches[1];
                        } elseif(preg_match('/^[a-zA-Z0-9_-]{11}$/', $url)) {
                            $id = $url;
                        }
                        
                        if($id):
                        ?>
                            <iframe width="100%" height="100%" 
                                src="https://www.youtube.com/embed/<?= htmlspecialchars($id) ?>" 
                                frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                                allowfullscreen></iframe>
                        <?php else: ?>
                            <div class="w-full h-full flex items-center justify-center text-center">
                                <div>
                                    <i class="fas fa-video text-4xl text-gray-600 mb-2"></i>
                                    <p class="text-gray-600">Invalid YouTube URL format</p>
                                    <p class="text-sm text-gray-500 mt-2">Make sure it's a valid YouTube link</p>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <div class="aspect-video bg-gray-200 rounded-lg flex items-center justify-center">
                        <div class="text-center">
                            <i class="fas fa-video text-6xl text-gray-400 mb-3"></i>
                            <p class="text-gray-600">Add a YouTube URL above to see preview</p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>
