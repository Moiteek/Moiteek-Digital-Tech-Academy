// Fetch latest announcement
$fileBase = __DIR__ . '/../includes/';
require_once $fileBase . 'bootstrap.php';
require_once $fileBase . 'auth_check.php';
requireStudent();
$studentId = $_SESSION['student_id'];
$studentName = $_SESSION['student_name'] ?? 'Student';

// Fetch active courses (enrolled)
$stmt = $pdo->prepare('SELECT c.title, c.slug, c.description FROM courses c INNER JOIN enrollments e ON c.id = e.course_id WHERE e.student_id = ?');
$stmt->execute([$studentId]);
$activeCourses = $stmt->fetchAll();

// Fetch courses not yet enrolled
$stmt = $pdo->prepare('SELECT title, slug, description FROM courses WHERE id NOT IN (SELECT course_id FROM enrollments WHERE student_id = ?) LIMIT 3');
$stmt->execute([$studentId]);
$otherCourses = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
<?php include __DIR__ . '/../includes/header.php'; ?>
<div class="container mx-auto px-4 py-10">
    <?php
    // Show green alert if status=success in URL
    if (isset($_GET['status']) && $_GET['status'] === 'success') {
        echo '<div class="mb-8 p-4 bg-green-100 border-l-4 border-green-500 text-green-900 rounded shadow text-center">'
            . '<strong>Enrollment successful!</strong> You have been enrolled in the course. Awaiting approval.'</div>';
    }
    // Show flash message if present and type is success
    if (isset($flash) && $flash['type'] === 'success') {
        echo '<div class="mb-8 p-4 bg-green-100 border-l-4 border-green-500 text-green-900 rounded shadow text-center">'
            . htmlspecialchars($flash['message']) . '</div>';
    } elseif (isset($flash) && $flash['type'] === 'error') {
        echo '<div class="mb-8 p-4 bg-red-100 border-l-4 border-red-500 text-red-900 rounded shadow text-center">'
            . htmlspecialchars($flash['message']) . '</div>';
    }
    ?>
    <?php if ($announcement): ?>
        <div class="mb-8 p-4 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-900 rounded shadow text-center">
            <strong>Important Update:</strong> <?= htmlspecialchars($announcement['message']) ?>
        </div>
    <?php endif; ?>
    <div class="flex justify-between items-center mb-8">
        <h1 class="text-3xl font-bold text-blue-700">Hello, <?= htmlspecialchars($studentName) ?>!</h1>
        <a href="logout.php" class="text-red-600 hover:underline font-semibold">Logout</a>
    </div>
    <div class="mb-10">
        <h2 class="text-2xl font-semibold mb-4 text-green-700">Active Courses</h2>
        <?php if ($activeCourses): ?>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <?php foreach ($activeCourses as $course): ?>
                    <?php
                    // Get course_id
                    $stmt = $pdo->prepare('SELECT id FROM courses WHERE slug = ? LIMIT 1');
                    $stmt->execute([$course['slug']]);
                    $cid = $stmt->fetchColumn();
                    // Count total lessons
                    $stmt = $pdo->prepare('SELECT COUNT(*) FROM lessons l INNER JOIN modules m ON l.module_id = m.id WHERE m.course_id = ?');
                    $stmt->execute([$cid]);
                    $total = (int)$stmt->fetchColumn();
                    // Count completed lessons
                    $stmt = $pdo->prepare('SELECT COUNT(DISTINCT lp.lesson_id) FROM lesson_progress lp INNER JOIN lessons l ON lp.lesson_id = l.id INNER JOIN modules m ON l.module_id = m.id WHERE lp.student_id = ? AND m.course_id = ?');
                    $stmt->execute([$studentId, $cid]);
                    $done = (int)$stmt->fetchColumn();
                    $percent = ($total > 0) ? round(($done / $total) * 100) : 0;
                    ?>
                    <div class="bg-white rounded shadow p-5">
                        <h3 class="text-xl font-bold text-blue-800 mb-2"><?= htmlspecialchars($course['title']) ?></h3>
                        <p class="mb-3 text-gray-700"><?= htmlspecialchars($course['description']) ?></p>
                        <div class="mb-3">
                            <div class="flex justify-between mb-1">
                                <span class="text-sm font-semibold text-gray-700">Progress</span>
                                <span class="text-sm font-bold text-blue-600"><?= $percent ?>%</span>
                            </div>
                            <div class="w-full bg-gray-200 rounded-full h-2">
                                <div class="bg-blue-600 h-2 rounded-full transition-all" style="width: <?= $percent ?>%"></div>
                            </div>
                        </div>
                        <a href="../student/view_course.php?course_id=<?= $cid ?>" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">View Course</a>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p class="text-gray-500">You have not enrolled in any courses yet.</p>
        <?php endif; ?>
    </div>
    <div>
        <h2 class="text-2xl font-semibold mb-4 text-blue-700">Explore More</h2>
        <?php if ($otherCourses): ?>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <?php foreach ($otherCourses as $course): ?>
                    <div class="bg-white rounded shadow p-5">
                        <h3 class="text-xl font-bold text-blue-800 mb-2"><?= htmlspecialchars($course['title']) ?></h3>
                        <p class="mb-3 text-gray-700"><?= htmlspecialchars($course['description']) ?></p>
                        <a href="course.php?slug=<?= urlencode($course['slug']) ?>" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">View Details</a>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p class="text-gray-500">You have explored all available courses!</p>
        <?php endif; ?>
    </div>
</div>
</body>
</html>

<?php 
require_once '../bootstrap.php';

// Check student login
if(!Auth::isStudentLoggedIn()) {
    Response::redirect('../auth/login.php', 'Please login to access your dashboard', 'error');
}

$student_id = $_SESSION['student_id'];

// Get student details
$student = Database::getUserById($student_id, 'students');

// Get enrolled courses
$enrollments = Database::getStudentEnrollments($student_id);

// Get statistics
$stmt = $pdo->prepare("SELECT SUM(progress_percentage) as total_progress, COUNT(*) as course_count FROM progress WHERE student_id = ?");
$stmt->execute([$student_id]);
$stats = $stmt->fetch();

$flash = Response::getFlashMessage();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard - <?= APP_NAME ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .progress-ring {
            transform: rotate(-90deg);
        }
        .progress-ring-circle {
            transition: stroke-dashoffset 0.35s;
            stroke-dasharray: 282.743;
        }
        .card-hover {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .card-hover:hover {
            transform: translateY(-4px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Top Navigation -->
    <nav class="bg-white shadow-md sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <i class="fas fa-graduation-cap text-2xl text-blue-600"></i>
                <span class="font-bold text-lg text-gray-900"><?= APP_NAME ?></span>
                <span class="bg-purple-100 text-purple-800 text-xs px-3 py-1 rounded-full font-semibold">Student</span>
            </div>
            <div class="flex items-center gap-4">
                <div class="hidden md:flex items-center gap-2 text-gray-700">
                    <div class="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                        <i class="fas fa-user text-purple-600"></i>
                    </div>
                    <div>
                        <p class="text-sm font-semibold"><?= htmlspecialchars($student['fullname']) ?></p>
                        <p class="text-xs text-gray-600"><?= htmlspecialchars($student['email']) ?></p>
                    </div>
                </div>
                <a href="../auth/logout.php" class="p-2 text-gray-600 hover:bg-red-50 hover:text-red-600 rounded-lg transition">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </div>
    </nav>

    <!-- Flash Message -->
    <?php if($flash): ?>
        <div class="max-w-7xl mx-auto mt-4 px-4">
            <div class="p-4 rounded-lg bg-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-50 border border-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-200 flex items-center gap-3">
                <i class="fas fa-<?= $flash['type'] === 'error' ? 'exclamation-circle' : 'check-circle' ?> text-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-600"></i>
                <p class="text-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-700"><?= htmlspecialchars($flash['message']) ?></p>
            </div>
        </div>
    <?php endif; ?>

    <!-- Main Content -->
    <div class="max-w-7xl mx-auto px-4 py-8">
        <!-- Header -->
        <div class="mb-8">
            <h1 class="text-3xl md:text-4xl font-bold text-gray-900 mb-2">
                <i class="fas fa-chart-line text-purple-600 mr-2"></i>Welcome back, <?= htmlspecialchars(explode(' ', $student['fullname'])[0]) ?>!
            </h1>
            <p class="text-gray-600">Here's your learning progress and enrolled courses</p>
        </div>

        <!-- Stats Cards -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <!-- Total Courses -->
            <div class="bg-white rounded-xl shadow-md p-6 border-l-4 border-blue-600">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-600 text-sm font-semibold">Courses Enrolled</p>
                        <p class="text-3xl font-bold text-gray-900 mt-2"><?= count($enrollments) ?></p>
                    </div>
                    <i class="fas fa-book text-4xl text-blue-100"></i>
                </div>
            </div>

            <!-- In Progress -->
            <div class="bg-white rounded-xl shadow-md p-6 border-l-4 border-purple-600">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-600 text-sm font-semibold">In Progress</p>
                        <p class="text-3xl font-bold text-gray-900 mt-2">
                            <?php 
                                $in_progress = 0;
                                foreach($enrollments as $e) {
                                    if($e['payment_status'] === 'confirmed' && $e['status'] === 'active') {
                                        $in_progress++;
                                    }
                                }
                                echo $in_progress;
                            ?>
                        </p>
                    </div>
                    <i class="fas fa-spinner text-4xl text-purple-100"></i>
                </div>
            </div>

            <!-- Completed -->
            <div class="bg-white rounded-xl shadow-md p-6 border-l-4 border-green-600">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-600 text-sm font-semibold">Completed</p>
                        <p class="text-3xl font-bold text-gray-900 mt-2">
                            <?php 
                                $completed = 0;
                                foreach($enrollments as $e) {
                                    if($e['status'] === 'completed') {
                                        $completed++;
                                    }
                                }
                                echo $completed;
                            ?>
                        </p>
                    </div>
                    <i class="fas fa-check-circle text-4xl text-green-100"></i>
                </div>
            </div>

            <!-- Pending -->
            <div class="bg-white rounded-xl shadow-md p-6 border-l-4 border-yellow-600">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-600 text-sm font-semibold">Pending Approval</p>
                        <p class="text-3xl font-bold text-gray-900 mt-2">
                            <?php 
                                $pending = 0;
                                foreach($enrollments as $e) {
                                    if($e['payment_status'] === 'pending') {
                                        $pending++;
                                    }
                                }
                                echo $pending;
                            ?>
                        </p>
                    </div>
                    <i class="fas fa-clock text-4xl text-yellow-100"></i>
                </div>
            </div>
        </div>

        <!-- Enrolled Courses -->
        <div class="bg-white rounded-xl shadow-md p-6 mb-8">
            <h2 class="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                <i class="fas fa-graduation-cap text-blue-600"></i>My Courses
            </h2>

            <?php if(empty($enrollments)): ?>
                <div class="text-center py-12">
                    <i class="fas fa-inbox text-5xl text-gray-300 mb-4"></i>
                    <p class="text-gray-600 text-lg mb-6">You haven't enrolled in any courses yet</p>
                    <a href="../courses.php" class="inline-block bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition">
                        Explore Courses
                    </a>
                </div>
            <?php else: ?>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <?php foreach($enrollments as $enrollment): ?>
                        <div class="bg-gradient-to-br from-gray-50 to-white rounded-xl shadow-lg card-hover overflow-hidden border border-gray-200">
                            <!-- Thumbnail -->
                            <div class="h-40 bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center relative overflow-hidden">
                                <i class="fas fa-book text-5xl text-white opacity-80"></i>
                                
                                <!-- Status Badge -->
                                <?php if($enrollment['payment_status'] === 'confirmed'): ?>
                                    <span class="absolute top-3 right-3 bg-green-500 text-white px-3 py-1 rounded-full text-xs font-semibold flex items-center gap-1">
                                        <i class="fas fa-check-circle"></i> Active
                                    </span>
                                <?php elseif($enrollment['payment_status'] === 'pending'): ?>
                                    <span class="absolute top-3 right-3 bg-yellow-500 text-white px-3 py-1 rounded-full text-xs font-semibold flex items-center gap-1">
                                        <i class="fas fa-clock"></i> Pending
                                    </span>
                                <?php else: ?>
                                    <span class="absolute top-3 right-3 bg-red-500 text-white px-3 py-1 rounded-full text-xs font-semibold">Failed</span>
                                <?php endif; ?>
                            </div>

                            <!-- Content -->
                            <div class="p-6">
                                <h3 class="text-lg font-bold text-gray-900 mb-2 line-clamp-2">
                                    <?= htmlspecialchars($enrollment['title']) ?>
                                </h3>
                                <p class="text-sm text-gray-600 mb-4 line-clamp-1">
                                    <?= htmlspecialchars($enrollment['slug']) ?>
                                </p>

                                <!-- Progress Bar -->
                                <div class="mb-4">
                                    <div class="flex items-center justify-between mb-2">
                                        <label class="text-sm font-semibold text-gray-700">Progress</label>
                                        <span class="text-sm font-bold text-blue-600"><?= $enrollment['progress_percentage'] ?? 0 ?>%</span>
                                    </div>
                                    <div class="w-full bg-gray-200 rounded-full h-2">
                                        <div class="bg-gradient-to-r from-blue-600 to-purple-600 h-2 rounded-full transition-all" style="width: <?= $enrollment['progress_percentage'] ?? 0 ?>%"></div>
                                    </div>
                                </div>

                                <!-- Course Info -->
                                <div class="flex items-center justify-between text-xs text-gray-600 mb-4 pb-4 border-b border-gray-200">
                                    <span><i class="fas fa-tag mr-1"></i><?= Helper::formatCurrency($enrollment['price']) ?></span>
                                    <span><i class="fas fa-calendar mr-1"></i><?= Helper::timeAgo($enrollment['enrollment_date']) ?></span>
                                </div>

                                <!-- CTA -->
                                <a href="course.php?id=<?= $enrollment['course_id'] ?>" class="w-full block text-center bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg font-semibold transition text-sm">
                                    <i class="fas fa-play-circle mr-1"></i>Continue Learning
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Quick Actions -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <a href="../courses.php" class="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition text-center">
                <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-plus-circle text-2xl text-blue-600"></i>
                </div>
                <h3 class="text-lg font-bold text-gray-900 mb-1">Enroll New Courses</h3>
                <p class="text-sm text-gray-600">Browse and join more courses</p>
            </a>

            <div class="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition text-center">
                <div class="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-certificate text-2xl text-purple-600"></i>
                </div>
                <h3 class="text-lg font-bold text-gray-900 mb-1">My Certificates</h3>
                <p class="text-sm text-gray-600">View your accomplishments</p>
            </div>

            <div class="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition text-center">
                <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-cog text-2xl text-green-600"></i>
                </div>
                <h3 class="text-lg font-bold text-gray-900 mb-1">Account Settings</h3>
                <p class="text-sm text-gray-600">Manage your profile</p>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-gray-900 text-gray-400 py-8 mt-12">
        <div class="max-w-7xl mx-auto px-4 text-center text-sm">
            <p>&copy; 2026 <?= APP_NAME ?>. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
