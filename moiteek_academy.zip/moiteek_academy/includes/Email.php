<?php
/**
 * Email Helper Class
 * Handles email sending for notifications, verification, password reset
 * 
 * Note: This uses PHP's mail() function. For production, replace with:
 * - PHPMailer (recommended)
 * - SwiftMailer
 * - SendGrid API
 * - AWS SES
 */

class Email {
    private static $fromEmail = 'noreply@moiteek.com';
    private static $fromName = 'Moiteek Academy';
    private static $smtpEnabled = false;  // Set to true if SMTP configured
    
    /**
     * Set SMTP configuration (for advanced email sending)
     */
    public static function configureSmtp($host, $port, $username, $password) {
        self::$smtpEnabled = true;
        ini_set('SMTP', $host);
        ini_set('smtp_port', $port);
        // For secure SMTP, additional config needed with PHPMailer
    }

    /**
     * Send email with HTML content
     * 
     * @param string $to Recipient email
     * @param string $subject Email subject
     * @param string $htmlBody HTML body content
     * @param array $headers Optional additional headers
     * @return bool Success status
     */
    public static function send($to, $subject, $htmlBody, $headers = []) {
        // Validate email
        if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
            error_log("Invalid email: " . $to);
            return false;
        }

        // Set default headers
        $defaultHeaders = [
            'MIME-Version: 1.0',
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . self::$fromName . ' <' . self::$fromEmail . '>',
            'Reply-To: ' . self::$fromEmail,
            'X-Mailer: Moiteek Academy'
        ];

        // Merge with custom headers
        $allHeaders = array_merge($defaultHeaders, $headers);
        $headersStr = implode("\r\n", $allHeaders);

        // Send email
        $sent = @mail($to, $subject, $htmlBody, $headersStr);

        if ($sent) {
            error_log("Email sent to: " . $to . " | Subject: " . $subject);
        } else {
            error_log("Failed to send email to: " . $to);
        }

        return $sent;
    }

    /**
     * Send email verification link to student
     */
    public static function sendEmailVerification($to, $name, $verificationLink) {
        $subject = 'Verify Your Email - Moiteek Academy';
        
        $htmlBody = '
        <html>
        <head></head>
        <body style="font-family: Arial, sans-serif; color: #333;">
            <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                <h2>Welcome to Moiteek Academy, ' . htmlspecialchars($name) . '!</h2>
                
                <p>Thank you for registering. Please verify your email address to complete your registration.</p>
                
                <p>
                    <a href="' . htmlspecialchars($verificationLink) . '" 
                       style="display: inline-block; padding: 12px 30px; background-color: #3b82f6; 
                              color: white; text-decoration: none; border-radius: 5px;">
                        Verify Email Address
                    </a>
                </p>
                
                <p>Or copy and paste this link in your browser:</p>
                <p><code>' . htmlspecialchars($verificationLink) . '</code></p>
                
                <p>This link expires in 24 hours.</p>
                
                <hr>
                <p style="font-size: 12px; color: #666;">
                    If you did not create this account, please ignore this email.
                </p>
            </div>
        </body>
        </html>
        ';

        return self::send($to, $subject, $htmlBody);
    }

    /**
     * Send password reset link
     */
    public static function sendPasswordReset($to, $name, $resetLink) {
        $subject = 'Password Reset Request - Moiteek Academy';
        
        $htmlBody = '
        <html>
        <head></head>
        <body style="font-family: Arial, sans-serif; color: #333;">
            <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                <h2>Password Reset Request</h2>
                
                <p>Hi ' . htmlspecialchars($name) . ',</p>
                
                <p>We received a request to reset your password. Click the button below to create a new password:</p>
                
                <p>
                    <a href="' . htmlspecialchars($resetLink) . '" 
                       style="display: inline-block; padding: 12px 30px; background-color: #3b82f6; 
                              color: white; text-decoration: none; border-radius: 5px;">
                        Reset Password
                    </a>
                </p>
                
                <p>Or copy and paste this link:</p>
                <p><code>' . htmlspecialchars($resetLink) . '</code></p>
                
                <p><strong>This link expires in 1 hour.</strong></p>
                
                <p style="color: #f59e0b; font-weight: bold;">
                    If you did not request this, please ignore this email or contact support.
                </p>
                
                <hr>
                <p style="font-size: 12px; color: #666;">
                    For security, never share this link with anyone.
                </p>
            </div>
        </body>
        </html>
        ';

        return self::send($to, $subject, $htmlBody);
    }

    /**
     * Send admin approval notification
     */
    public static function sendApprovalNotification($to, $name) {
        $subject = 'Account Approved - Moiteek Academy';
        
        $htmlBody = '
        <html>
        <head></head>
        <body style="font-family: Arial, sans-serif; color: #333;">
            <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                <h2>Welcome to Moiteek Academy!</h2>
                
                <p>Hi ' . htmlspecialchars($name) . ',</p>
                
                <p>Great news! Your account has been approved by our admin team.</p>
                
                <p>You can now:</p>
                <ul>
                    <li>Browse and enroll in courses</li>
                    <li>Track your learning progress</li>
                    <li>Download course materials</li>
                    <li>Earn certificates</li>
                </ul>
                
                <p>
                    <a href="' . APP_URL . '/auth/login.php" 
                       style="display: inline-block; padding: 12px 30px; background-color: #10b981; 
                              color: white; text-decoration: none; border-radius: 5px;">
                        Log In Now
                    </a>
                </p>
                
                <hr>
                <p style="font-size: 12px; color: #666;">
                    Questions? Contact our support team at support@moiteek.com
                </p>
            </div>
        </body>
        </html>
        ';

        return self::send($to, $subject, $htmlBody);
    }

    /**
     * Send rejection notification
     */
    public static function sendRejectionNotification($to, $name, $reason = '') {
        $subject = 'Registration Status - Moiteek Academy';
        
        $reasonText = '';
        if (!empty($reason)) {
            $reasonText = '<p><strong>Reason:</strong> ' . htmlspecialchars($reason) . '</p>';
        }
        
        $htmlBody = '
        <html>
        <head></head>
        <body style="font-family: Arial, sans-serif; color: #333;">
            <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                <h2>Registration Update</h2>
                
                <p>Hi ' . htmlspecialchars($name) . ',</p>
                
                <p>Unfortunately, your registration request has been rejected.</p>
                
                ' . $reasonText . '
                
                <p>If you believe this is an error, please contact our support team at support@moiteek.com</p>
                
                <hr>
                <p style="font-size: 12px; color: #666;">
                    Thank you for your interest in Moiteek Academy.
                </p>
            </div>
        </body>
        </html>
        ';

        return self::send($to, $subject, $htmlBody);
    }

    /**
     * Send payment confirmation notification
     */
    public static function sendPaymentConfirmation($to, $name, $courseName, $amount) {
        $subject = 'Payment Confirmed - ' . $courseName . ' - Moiteek Academy';
        
        $htmlBody = '
        <html>
        <head></head>
        <body style="font-family: Arial, sans-serif; color: #333;">
            <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                <h2>Payment Confirmed!</h2>
                
                <p>Hi ' . htmlspecialchars($name) . ',</p>
                
                <p>Your payment has been confirmed. Welcome to the course!</p>
                
                <div style="background-color: #f0f9ff; border-left: 4px solid #3b82f6; padding: 15px; margin: 20px 0;">
                    <p><strong>Course:</strong> ' . htmlspecialchars($courseName) . '</p>
                    <p><strong>Amount Paid:</strong> $' . number_format($amount, 2) . '</p>
                </div>
                
                <p>
                    <a href="' . APP_URL . '/student/dashboard.php" 
                       style="display: inline-block; padding: 12px 30px; background-color: #3b82f6; 
                              color: white; text-decoration: none; border-radius: 5px;">
                        Start Learning
                    </a>
                </p>
                
                <hr>
                <p style="font-size: 12px; color: #666;">
                    Access your course from your student dashboard.
                </p>
            </div>
        </body>
        </html>
        ';

        return self::send($to, $subject, $htmlBody);
    }

    /**
     * Send security alert (suspicious login attempt)
     */
    public static function sendSecurityAlert($to, $name, $reason) {
        $subject = 'Security Alert - Moiteek Academy';
        
        $htmlBody = '
        <html>
        <head></head>
        <body style="font-family: Arial, sans-serif; color: #333;">
            <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                <h2 style="color: #ef4444;">⚠️ Security Alert</h2>
                
                <p>Hi ' . htmlspecialchars($name) . ',</p>
                
                <p>We detected suspicious activity on your account:</p>
                
                <p style="background-color: #fef2f2; border-left: 4px solid #ef4444; padding: 15px;">
                    <strong>' . htmlspecialchars($reason) . '</strong>
                </p>
                
                <p>If this was you, you can ignore this email.</p>
                
                <p>If you did not authorize this action:
                    <ol>
                        <li>Change your password immediately</li>
                        <li>Contact our support team</li>
                        <li>Do not share your password with anyone</li>
                    </ol>
                </p>
                
                <p style="color: #666; font-size: 12px;">
                    This is an automated security alert. Do not reply to this email.
                </p>
            </div>
        </body>
        </html>
        ';

        return self::send($to, $subject, $htmlBody);
    }

    /**
     * Send login credentials after payment approval
     */
    public static function sendLoginCredentials($to, $username, $password, $name) {
        $subject = 'Your Account is Ready! Login Credentials - Moiteek Academy';
        
        $htmlBody = '
        <html>
        <head></head>
        <body style="font-family: Arial, sans-serif; color: #333;">
            <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                <h2 style="color: #10b981;">✓ Payment Approved!</h2>
                
                <p>Hi ' . htmlspecialchars($name) . ',</p>
                
                <p>Your payment has been confirmed. Your account credentials are ready!</p>
                
                <div style="background-color: #f0fdf4; border-left: 4px solid #10b981; padding: 20px; margin: 20px 0; border-radius: 5px;">
                    <p><strong>Username:</strong> <code style="background-color: #e0f2fe; padding: 5px 10px; border-radius: 3px; font-family: monospace;">' . htmlspecialchars($username) . '</code></p>
                    <p><strong>Password:</strong> <code style="background-color: #e0f2fe; padding: 5px 10px; border-radius: 3px; font-family: monospace;">' . htmlspecialchars($password) . '</code></p>
                </div>
                
                <p style="background-color: #fef3c7; border-left: 4px solid #f59e0b; padding: 15px; border-radius: 5px; margin: 20px 0;">
                    <strong>⚠️ Important:</strong> Change your password on first login for security.
                </p>
                
                <p>
                    <a href="' . APP_URL . '/auth/login.php" 
                       style="display: inline-block; padding: 12px 30px; background-color: #10b981; 
                              color: white; text-decoration: none; border-radius: 5px; font-weight: bold;">
                        Login Now
                    </a>
                </p>
                
                <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e5e7eb;">
                    <h3>Getting Started:</h3>
                    <ol>
                        <li>Log in with your username and password</li>
                        <li>Update your profile picture and bio</li>
                        <li>Change your password to something only you know</li>
                        <li>Access your enrolled courses</li>
                    </ol>
                </div>
                
                <hr>
                <p style="font-size: 12px; color: #666;">
                    If you did not authorize this payment or have questions, contact us immediately at support@moiteek.com
                </p>
            </div>
        </body>
        </html>
        ';

        return self::send($to, $subject, $htmlBody);
    }

    /**
     * Send payment approval with login credentials
     */
    public static function sendPaymentApprovalWithCredentials($to, $name, $courseName, $username, $password, $amount) {
        $subject = 'Payment Approved! Your Credentials - Moiteek Academy';
        
        $htmlBody = '
        <html>
        <head></head>
        <body style="font-family: Arial, sans-serif; color: #333;">
            <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                <h2 style="color: #10b981;">✓ Payment Approved!</h2>
                
                <p>Hi ' . htmlspecialchars($name) . ',</p>
                
                <p>Excellent news! Your payment has been approved and your account is now active.</p>
                
                <div style="background-color: #ecfdf5; border-left: 4px solid #10b981; padding: 20px; margin: 20px 0; border-radius: 5px;">
                    <p style="margin: 0 0 10px 0;"><strong>Course:</strong> ' . htmlspecialchars($courseName) . '</p>
                    <p style="margin: 0 0 10px 0;"><strong>Amount Paid:</strong> $' . htmlspecialchars($amount) . '</p>
                    <p style="margin: 0;"><strong>Status:</strong> <span style="color: #10b981; font-weight: bold;">APPROVED</span></p>
                </div>
                
                <h3 style="color: #333; margin-top: 25px;">Your Login Credentials:</h3>
                
                <div style="background-color: #f0fdf4; border: 2px solid #10b981; padding: 20px; margin: 15px 0; border-radius: 5px;">
                    <p style="margin: 0 0 12px 0;">
                        <strong>Username:</strong><br>
                        <code style="background-color: #e0f2fe; padding: 8px 12px; border-radius: 3px; font-family: monospace; font-size: 14px;">' . htmlspecialchars($username) . '</code>
                    </p>
                    <p style="margin: 0;">
                        <strong>Password:</strong><br>
                        <code style="background-color: #e0f2fe; padding: 8px 12px; border-radius: 3px; font-family: monospace; font-size: 14px;">' . htmlspecialchars($password) . '</code>
                    </p>
                </div>
                
                <p style="background-color: #fef3c7; border-left: 4px solid #f59e0b; padding: 15px; border-radius: 5px; margin: 20px 0;">
                    <strong>⚠️ Security Reminder:</strong> <br>
                    • Save these credentials in a safe place<br>
                    • Change your password on first login<br>
                    • Never share your credentials with anyone
                </p>
                
                <p style="text-align: center; margin: 25px 0;">
                    <a href="' . APP_URL . '/auth/login.php" 
                       style="display: inline-block; padding: 14px 40px; background-color: #10b981; 
                              color: white; text-decoration: none; border-radius: 5px; font-weight: bold; font-size: 16px;">
                        Start Learning Now
                    </a>
                </p>
                
                <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e5e7eb;">
                    <h3 style="color: #333;">Next Steps:</h3>
                    <ol>
                        <li>Click the button above to login</li>
                        <li>Complete your profile (picture, bio, etc.)</li>
                        <li>Change your password in settings</li>
                        <li>Start exploring the course materials</li>
                    </ol>
                </div>
                
                <hr style="margin: 25px 0; border: none; border-top: 1px solid #e5e7eb;">
                <p style="font-size: 12px; color: #666;">
                    Questions? Contact our support team at support@moiteek.com<br>
                    This is an automated message. Please do not reply to this email.
                </p>
            </div>
        </body>
        </html>
        ';

        return self::send($to, $subject, $htmlBody);
    }

    /**
     * Send payment rejection notification
     */
    public static function sendPaymentRejection($to, $name, $courseName, $reason) {
        $subject = 'Payment Status Update - Moiteek Academy';
        
        $htmlBody = '
        <html>
        <head></head>
        <body style="font-family: Arial, sans-serif; color: #333;">
            <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                <h2 style="color: #ef4444;">⚠️ Payment Review Result</h2>
                
                <p>Hi ' . htmlspecialchars($name) . ',</p>
                
                <p>We have reviewed your payment submission for the following course:</p>
                
                <div style="background-color: #fef2f2; border-left: 4px solid #ef4444; padding: 20px; margin: 20px 0; border-radius: 5px;">
                    <p style="margin: 0 0 10px 0;"><strong>Course:</strong> ' . htmlspecialchars($courseName) . '</p>
                    <p style="margin: 0;"><strong>Status:</strong> <span style="color: #ef4444; font-weight: bold;">NOT APPROVED</span></p>
                </div>
                
                <h3 style="color: #333; margin-top: 25px;">Rejection Reason:</h3>
                
                <div style="background-color: #fef2f2; border: 2px solid #fed7d7; padding: 15px; margin: 15px 0; border-radius: 5px;">
                    <p style="color: #c53030; line-height: 1.6;">
                        ' . htmlspecialchars($reason) . '
                    </p>
                </div>
                
                <h3 style="color: #333; margin-top: 25px;">What Now?</h3>
                
                <p>Here are your options:</p>
                <ul>
                    <li><strong>Upload New Proof:</strong> Try submitting payment proof again with clearer images or details</li>
                    <li><strong>Contact Support:</strong> Email us at support@moiteek.com with any questions</li>
                    <li><strong>Choose Payment Method:</strong> If your payment method had issues, try a different method</li>
                </ul>
                
                <p style="text-align: center; margin: 25px 0;">
                    <a href="' . APP_URL . '/student/upload-payment.php" 
                       style="display: inline-block; padding: 12px 30px; background-color: #3b82f6; 
                              color: white; text-decoration: none; border-radius: 5px; font-weight: bold;">
                        Upload Payment Proof Again
                    </a>
                </p>
                
                <div style="margin-top: 30px; padding: 15px; background-color: #f0fdf4; border-left: 4px solid #10b981; border-radius: 5px;">
                    <p style="margin: 0; font-size: 14px;"><strong>💡 Tip:</strong> Make sure your payment proof includes:</p>
                    <ul style="margin: 10px 0 0 20px; padding: 0;">
                        <li>Transaction ID or reference number</li>
                        <li>Exact amount paid</li>
                        <li>Date and time of payment</li>
                        <li>Clear recipient information</li>
                    </ul>
                </div>
                
                <hr style="margin: 25px 0; border: none; border-top: 1px solid #e5e7eb;">
                <p style="font-size: 12px; color: #666;">
                    Need help? Contact our support team at support@moiteek.com<br>
                    This is an automated message. Please do not reply to this email.
                </p>
            </div>
        </body>
        </html>
        ';

        return self::send($to, $subject, $htmlBody);
    }
}
?>
