<?php
/**
 * Validator Class
 * Handles input validation and sanitization
 */

class Validator {
    private static $errors = [];

    /**
     * Validate email
     */
    public static function validateEmail($email) {
        if(empty($email)) {
            self::$errors['email'] = 'Email is required';
            return false;
        }
        if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            self::$errors['email'] = 'Invalid email format';
            return false;
        }
        return true;
    }

    /**
     * Validate password with strength requirements
     * 
     * Requirements:
     * - Minimum 8 characters
     * - At least 1 uppercase letter (A-Z)
     * - At least 1 lowercase letter (a-z)
     * - At least 1 number (0-9)
     * - At least 1 special character (@$!%*?&)
     */
    public static function validatePassword($password) {
        if(empty($password)) {
            self::$errors['password'] = 'Password is required';
            return false;
        }

        $errors = [];

        if(strlen($password) < 8) {
            $errors[] = 'Password must be at least 8 characters';
        }

        if(!preg_match('/[A-Z]/', $password)) {
            $errors[] = 'Password must contain at least one uppercase letter';
        }

        if(!preg_match('/[a-z]/', $password)) {
            $errors[] = 'Password must contain at least one lowercase letter';
        }

        if(!preg_match('/[0-9]/', $password)) {
            $errors[] = 'Password must contain at least one number';
        }

        if(!preg_match('/[@$!%*?&]/', $password)) {
            $errors[] = 'Password must contain at least one special character (@$!%*?&)';
        }

        if(!empty($errors)) {
            self::$errors['password'] = implode('. ', $errors);
            return false;
        }

        return true;
    }

    /**
     * Validate full name
     */
    public static function validateFullName($name) {
        if(empty($name)) {
            self::$errors['fullname'] = 'Full name is required';
            return false;
        }
        if(strlen($name) < 3) {
            self::$errors['fullname'] = 'Name must be at least 3 characters';
            return false;
        }
        if(!preg_match('/^[a-zA-Z\s]*$/', $name)) {
            self::$errors['fullname'] = 'Name can only contain letters and spaces';
            return false;
        }
        return true;
    }

    /**
     * Validate phone number
     */
    public static function validatePhone($phone) {
        if(empty($phone)) {
            self::$errors['phone'] = 'Phone number is required';
            return false;
        }
        if(!preg_match('/^[\d\+\-\s\(\)]{7,}$/', $phone)) {
            self::$errors['phone'] = 'Invalid phone number format';
            return false;
        }
        return true;
    }

    /**
     * Validate username
     */
    public static function validateUsername($username) {
        if(empty($username)) {
            self::$errors['username'] = 'Username is required';
            return false;
        }
        if(strlen($username) < 3 || strlen($username) > 20) {
            self::$errors['username'] = 'Username must be 3-20 characters';
            return false;
        }
        if(!preg_match('/^[a-zA-Z0-9_]*$/', $username)) {
            self::$errors['username'] = 'Username can only contain letters, numbers, and underscores';
            return false;
        }
        return true;
    }

    /**
     * Validate file upload
     */
    public static function validateFileUpload($file, $max_size = 5242880, $allowed_types = ['image/jpeg', 'image/png', 'application/pdf']) {
        if(empty($file['name'])) {
            self::$errors['file'] = 'File is required';
            return false;
        }
        if($file['size'] > $max_size) {
            self::$errors['file'] = 'File size exceeds maximum allowed';
            return false;
        }
        if(!in_array($file['type'], $allowed_types)) {
            self::$errors['file'] = 'Invalid file type';
            return false;
        }
        return true;
    }

    /**
     * Sanitize input
     */
    public static function sanitizeInput($input) {
        if(is_array($input)) {
            return array_map([self::class, 'sanitizeInput'], $input);
        }
        return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
    }

    /**
     * Get validation errors
     */
    public static function getErrors() {
        return self::$errors;
    }

    /**
     * Clear errors
     */
    public static function clearErrors() {
        self::$errors = [];
    }

    /**
     * Validate payment amount
     */
    public static function validateAmount($amount) {
        if(!is_numeric($amount) || $amount <= 0) {
            self::$errors['amount'] = 'Invalid amount';
            return false;
        }
        return true;
    }
}
?>