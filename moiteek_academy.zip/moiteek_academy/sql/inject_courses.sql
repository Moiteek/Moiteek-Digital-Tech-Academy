INSERT INTO `courses` (`title`, `slug`, `description`, `price`, `image_url`, `is_published`, `category`) VALUES
-- Inject real course data for all categories
('Fullstack PHP Mastery', 'fullstack-php-mastery', 'Master PHP for backend and fullstack web development.', 48000.00, 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?auto=format&fit=crop&w=600&q=80', 1, 'Web Development'),
('React & Tailwind', 'react-tailwind', 'Build modern UIs with React and Tailwind CSS.', 46000.00, 'https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=600&q=80', 1, 'Web Development'),
('Photoshop Pro', 'photoshop-pro', 'Become a pro in Adobe Photoshop for creative design.', 37000.00, 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=600&q=80', 1, 'Graphics Design'),
('UI/UX Essentials', 'ui-ux-essentials', 'Learn the essentials of UI/UX design.', 41000.00, 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=600&q=80', 1, 'Graphics Design'),
('SEO Strategy', 'seo-strategy', 'Boost your site with SEO strategies.', 32000.00, 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=600&q=80', 1, 'Digital Skills'),
('Social Media Ads', 'social-media-ads', 'Create and manage effective social media ad campaigns.', 34000.00, 'https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?auto=format&fit=crop&w=600&q=80', 1, 'Digital Skills'),
('Computer Science 101', 'computer-science-101', 'A beginner-friendly introduction to computer science.', 26000.00, 'https://images.unsplash.com/photo-1465101046530-73398c7f28ca?auto=format&fit=crop&w=600&q=80', 1, 'Tech Basics');
