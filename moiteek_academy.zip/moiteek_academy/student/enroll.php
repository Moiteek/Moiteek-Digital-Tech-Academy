<?php
require_once '../includes/bootstrap.php';

if (!isset($_SESSION['student_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../courses.php');
    exit;
}

$student_id = $_SESSION['student_id'];
$course_id = (int)($_POST['course_id'] ?? 0);

if (!$course_id) {
    Response::redirect('../courses.php', 'Invalid course selection.', 'error');
}

try {
    $stmt = $pdo->prepare('INSERT INTO enrollments (student_id, course_id, status) VALUES (?, ?, ?)');
    $stmt->execute([$student_id, $course_id, 'pending']);
    // Redirect to dashboard with status=success in URL
    header('Location: dashboard.php?status=success');
    exit;
} catch (PDOException $e) {
    if ($e->getCode() == 23000) { // Integrity constraint violation
        Response::redirect('../courses.php', 'You are already enrolled or there was a database constraint error.', 'error');
    } else {
        Response::redirect('../courses.php', 'Enrollment failed: ' . $e->getMessage(), 'error');
    }
}
