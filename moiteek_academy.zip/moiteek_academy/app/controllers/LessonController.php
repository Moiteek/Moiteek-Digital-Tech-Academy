<?php
// app/controllers/LessonController.php
// Handles lesson creation, video support, resource links, ordering, and completion

class LessonController extends Controller {
    public function create() {
        // ...existing logic...
        // Accept video_type (youtube, vimeo, upload), video_url, video_file, resource_links, lesson_order
        Lesson::create([
            'course_id' => $courseId,
            'module_id' => $moduleId,
            'title' => $title,
            'description' => $desc,
            'video_type' => $videoType,
            'video_url' => $videoUrl,
            'video_file' => $videoFile,
            'resource_links' => $resourceLinks,
            'lesson_order' => $lessonOrder,
        ]);
    }

    public function reorder($lessonId, $newOrder) {
        Lesson::updateOrder($lessonId, $newOrder);
    }

    public function markCompleted($enrollmentId, $lessonId) {
        // Mark lesson as completed for student
        LessonProgress::markCompleted($enrollmentId, $lessonId);
        // If all lessons completed, update enrollment.completed_at
        if (LessonProgress::allCompleted($enrollmentId)) {
            Enrollment::updateCompletedAt($enrollmentId);
        }
    }
}
