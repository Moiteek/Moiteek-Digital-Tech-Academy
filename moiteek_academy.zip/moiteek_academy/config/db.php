<?php
// Session timeout in seconds (e.g., 1800 = 30 minutes)
// Define SSL_ENABLED (set to false for local development, true for production)
if (!defined('SSL_ENABLED')) {
    define('SSL_ENABLED', false);
}
if (!defined('SESSION_TIMEOUT')) {
    define('SESSION_TIMEOUT', 1800); // 30 minutes
}
// Session ID regeneration interval in seconds (e.g., 300 = 5 minutes)
if (!defined('SESSION_REGENERATE_INTERVAL')) {
    define('SESSION_REGENERATE_INTERVAL', 300); // 5 minutes
}
$env = require __DIR__ . '/env.php';
// Define SECURE_COOKIE for local development (set to false if not defined)
if (!defined('SECURE_COOKIE')) {
    define('SECURE_COOKIE', false);
}
$isLocal = in_array($_SERVER['SERVER_NAME'] ?? '', ['localhost', '127.0.0.1']) || strpos($_SERVER['SERVER_NAME'] ?? '', '192.168.') === 0;
$config = $isLocal ? $env['local'] : $env['production'];
$host = $config['DB_HOST'];
$db   = $config['DB_NAME'];
$user = $config['DB_USER'];
$pass = $config['DB_PASS'];
$charset = 'utf8mb4';
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];
try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    die('Database connection failed: ' . htmlspecialchars($e->getMessage()));
}
// Make Paystack secret key available globally if needed
if (!defined('PAYSTACK_SECRET_KEY')) {
    define('PAYSTACK_SECRET_KEY', $config['PAYSTACK_SECRET_KEY']);
}

$sessionConfig = [
    'cookie_secure' => SECURE_COOKIE,          // true for HTTPS only
    'cookie_httponly' => true,                 // Prevent JavaScript access
    'cookie_samesite' => 'Strict',             // CSRF protection
    'use_strict_mode' => true,                 // Strict session ID validation
    'use_trans_sid' => false,                  // Don't auto-prepend session ID
    'use_cookies' => true,
    'use_only_cookies' => true,                // Don't allow query string session IDs
    'gc_probability' => 1,
    'gc_divisor' => 100,
    'gc_maxlifetime' => SESSION_TIMEOUT
];

// Start/resume session with security settings
if (session_status() === PHP_SESSION_NONE) {
    session_start($sessionConfig);
}

// ==========================================
// SESSION TIMEOUT MANAGEMENT
// ==========================================

// Check for session timeout
if (isset($_SESSION['last_activity'])) {
    $inactiveTime = time() - $_SESSION['last_activity'];
    
    if ($inactiveTime > SESSION_TIMEOUT) {
        // Session expired, destroy it
        error_log("Session timeout for user: " . ($_SESSION['admin_email'] ?? $_SESSION['student_email'] ?? 'unknown'));
        
        $_SESSION = [];
        session_destroy();
        if (session_status() === PHP_SESSION_NONE) {
            session_start($sessionConfig);
        }
        
        // Redirect to login if user was authenticated
        if (isset($_GET['message'])) {
            // Already showing message
        } else if ($_GET['redirect'] ?? false) {
            header('Location: /moiteek_academy/auth/login.php?message=session_expired');
            exit;
        }
    } else {
        // Regenerate session ID periodically (every 5 minutes)
        if (!isset($_SESSION['last_regeneration']) || 
            (time() - $_SESSION['last_regeneration']) > SESSION_REGENERATE_INTERVAL) {
            session_regenerate_id(true);
            $_SESSION['last_regeneration'] = time();
        }
    }
}

// Update last activity time
$_SESSION['last_activity'] = time();

// ==========================================
// SECURITY HEADERS
// ==========================================

if (!headers_sent()) {
    // Prevent content-type sniffing
    header('X-Content-Type-Options: nosniff');
    
    // Prevent clickjacking
    header('X-Frame-Options: SAMEORIGIN');
    
    // Enable XSS protection
    header('X-XSS-Protection: 1; mode=block');
    
    // Control referrer information
    header('Referrer-Policy: strict-origin-when-cross-origin');
    
    // Require HTTPS (optional, enable for production)
    if (SSL_ENABLED) {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
    
    // Control which features can be used
    header('Permissions-Policy: geolocation=(), microphone=(), camera=()');
}

// ==========================================
// ERROR HANDLING & LOGGING
// ==========================================

// Production: suppress error display
if (php_uname('s') !== 'Linux') {
    ini_set('display_errors', 0);
} else {
    // Development: show errors (comment out in production)
    ini_set('display_errors', 1);
}

// Always log errors
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../logs/php_errors.log');

// Create logs directory if it doesn't exist
if (!is_dir(__DIR__ . '/../logs')) {
    @mkdir(__DIR__ . '/../logs', 0755, true);
}

?>

