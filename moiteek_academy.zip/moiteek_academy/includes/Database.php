<?php
/**
 * Database Helper Class
 * Common database operations
 */

class Database {
    private static $pdo = null;

    public static function setPDO($pdo) {
        self::$pdo = $pdo;
    }

    private static function connect() {
        global $pdo;
        if (!self::$pdo && isset($pdo)) {
            self::$pdo = $pdo;
        }
        if (!self::$pdo) {
            // Fallback: try to include db.php if not already loaded
            $dbPath = __DIR__ . '/../config/db.php';
            if (file_exists($dbPath)) {
                require_once $dbPath;
                if (isset($pdo)) {
                    self::$pdo = $pdo;
                }
            }
        }
        if (!self::$pdo) {
            // Instead of throwing, return false so the site doesn't crash
            return false;
        }
        return self::$pdo;
    }

    /**
     * Check if email exists
     */
    public static function emailExists($email, $table = 'students') {
        self::connect();
        $stmt = self::$pdo->prepare("SELECT id FROM $table WHERE email = ?");
        $stmt->execute([$email]);
        return $stmt->rowCount() > 0;
    }

    /**
     * Check if username exists
     */
    public static function usernameExists($username) {
        self::connect();
        $stmt = self::$pdo->prepare("SELECT id FROM students WHERE username = ?");
        $stmt->execute([$username]);
        return $stmt->rowCount() > 0;
    }

    /**
     * Get user by ID
     */
    public static function getUserById($id, $table = 'students') {
        self::connect();
        $stmt = self::$pdo->prepare("SELECT * FROM $table WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    /**
     * Get all courses
     */
    public static function getCourses($published_only = true, $category = null) {
        self::connect();
        $sql = "SELECT * FROM courses";
        $params = [];
        $where = [];
        if ($published_only) {
            $where[] = "is_published = 1";
        }
        if ($category) {
            $where[] = "LOWER(category) LIKE ?";
            $params[] = strtolower($category);
        }
        if ($where) {
            $sql .= " WHERE " . implode(' AND ', $where);
        }
        $sql .= " ORDER BY created_at DESC";
        $stmt = self::$pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /**
     * Get course by ID
     */
    public static function getCourseById($id) {
        self::connect();
        $stmt = self::$pdo->prepare("SELECT * FROM courses WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    /**
     * Get student enrollments
     */
    public static function getStudentEnrollments($student_id) {
        self::connect();
        $stmt = self::$pdo->prepare("
            SELECT e.*, c.title, c.slug, c.thumbnail, c.price, p.progress_percentage
            FROM enrollments e
            JOIN courses c ON e.course_id = c.id
            LEFT JOIN progress p ON e.student_id = p.student_id AND e.course_id = p.course_id
            WHERE e.student_id = ?
            ORDER BY e.enrollment_date DESC
        ");
        $stmt->execute([$student_id]);
        return $stmt->fetchAll();
    }

    /**
     * Get course enrollments (admin)
     */
    public static function getCourseEnrollments($course_id) {
        self::connect();
        $stmt = self::$pdo->prepare("
            SELECT e.*, s.fullname, s.email, s.phone, p.progress_percentage
            FROM enrollments e
            JOIN students s ON e.student_id = s.id
            LEFT JOIN progress p ON e.student_id = p.student_id AND e.course_id = p.course_id
            WHERE e.course_id = ?
            ORDER BY e.enrollment_date DESC
        ");
        $stmt->execute([$course_id]);
        return $stmt->fetchAll();
    }

    /**
     * Get pending enrollments
     */
    public static function getPendingEnrollments() {
        self::connect();
        $stmt = self::$pdo->prepare("
            SELECT e.*, s.fullname, s.email, c.title, c.id as course_id
            FROM enrollments e
            JOIN students s ON e.student_id = s.id
            JOIN courses c ON e.course_id = c.id
            WHERE e.payment_status = 'pending'
            ORDER BY e.enrollment_date DESC
        ");
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * Get pending students
     */
    public static function getPendingStudents() {
        self::connect();
        $stmt = self::$pdo->query("SELECT * FROM students WHERE status = 'pending' ORDER BY enrollment_date DESC");
        return $stmt->fetchAll();
    }

    /**
     * Update student status
     */
    public static function updateStudentStatus($student_id, $status) {
        self::connect();
        $stmt = self::$pdo->prepare("UPDATE students SET status = ?, is_active = 1 WHERE id = ?");
        return $stmt->execute([$status, $student_id]);
    }

    /**
     * Get total students
     */
    public static function getTotalStudents($status = null) {
        self::connect();
        if ($status) {
            $stmt = self::$pdo->prepare("SELECT COUNT(*) as total FROM students WHERE status = ?");
            $stmt->execute([$status]);
            return $stmt->fetch()['total'];
        }
        return self::$pdo->query("SELECT COUNT(*) as total FROM students")->fetch()['total'];
    }

    /**
     * Get total courses
     */
    public static function getTotalCourses() {
        self::connect();
        return self::$pdo->query("SELECT COUNT(*) as total FROM courses WHERE is_published = 1")->fetch()['total'];
    }

    /**
     * Get total enrollments
     */
    public static function getTotalEnrollments() {
        self::connect();
        return self::$pdo->query("SELECT COUNT(*) as total FROM enrollments")->fetch()['total'];
    }

    /**
     * Get revenue summary
     */
    public static function getRevenueSummary() {
        self::connect();
        return self::$pdo->query("
            SELECT 
                SUM(amount) as total_revenue,
                SUM(CASE WHEN payment_status = 'confirmed' THEN amount ELSE 0 END) as confirmed_revenue,
                COUNT(*) as total_transactions,
                SUM(CASE WHEN payment_status = 'pending' THEN 1 ELSE 0 END) as pending_count
            FROM payments
        ")->fetch();
    }
}
?>