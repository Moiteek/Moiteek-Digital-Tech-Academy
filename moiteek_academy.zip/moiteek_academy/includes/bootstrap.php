<?php
// Global root path constant
if (!defined('ROOT_PATH')) {
    define('ROOT_PATH', realpath(__DIR__ . '/../') . DIRECTORY_SEPARATOR);
}
error_reporting(E_ALL);
ini_set('display_errors', 1);
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
// Error reporting (only once, at the top)
ini_set('display_startup_errors', 1);

// Absolute path to project root
if (!defined('BASE_PATH')) {
    define('BASE_PATH', dirname(__DIR__));
}

// Absolute URL to site root (adjust if not in web root)
if (!defined('BASE_URL')) {
    define('BASE_URL', 'http://localhost/moiteek_academy/');
}

// Require config/db.php using ROOT_PATH
require_once ROOT_PATH . 'config/db.php';
// Require Database.php using ROOT_PATH
require_once ROOT_PATH . 'includes/Database.php';

// Initialize Database static connection
if (isset($pdo)) {
    Database::setPDO($pdo);
}

if (!function_exists('isLoggedIn')) {
    function isLoggedIn() {
        return isset($_SESSION['student_id']) || isset($_SESSION['admin_id']);
    }
}

// Optionally, set timezone
if (!ini_get('date.timezone')) {
    date_default_timezone_set('UTC');
}
