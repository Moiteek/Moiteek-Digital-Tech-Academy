# Student Learning Portal Documentation

## Overview

The Student Learning Portal is a professional learning management system interface that allows enrolled students to:
- View organized course lessons with YouTube video embeds
- Download course resources (books, PDFs, code templates)
- Track lesson and course completion progress
- Navigate between lessons seamlessly

## Features

### 1. **Professional Learning Interface**
- Dark mode design with gradient accents
- Responsive layout adapting to desktop and mobile devices
- Real-time progress tracking with visual progress bars
- Clean, modern UI built with Tailwind CSS

### 2. **Organized Lesson Management**
- Sequential lesson organization
- Lesson duration display
- Lesson descriptions and detailed content
- Automatic selection of first lesson on page load
- Easy navigation between lessons with Previous/Next buttons

### 3. **Video Integration**
- YouTube video embedding via iframe
- Support for multiple YouTube URL formats:
  - Full URLs: `https://www.youtube.com/watch?v=dQw4w9WgXcQ`
  - Short URLs: `https://youtu.be/dQw4w9WgXcQ`
  - Direct IDs: `dQw4w9WgXcQ`
- Modestbranding mode for clean player interface
- Fullscreen support

### 4. **Resource Downloads**
- Support for multiple resource types:
  - PDF documents
  - Books
  - Code files
  - Templates
  - Generic documents
- Direct download links for local files
- External links for remote resources
- Categorized resource display with appropriate icons

### 5. **Progress Tracking**
- Per-module completion tracking
- Overall course progress percentage
- Visual progress bar (0-100%)
- Module completion counter (e.g., "5/12 lessons")
- Course completion badge when 100% finished
- Persistent progress storage in database

### 6. **Student Enrollment Verification**
- Only enrolled students can access their courses
- Payment status must be "approved"
- Secure access control via Auth class
- Automatic redirect to dashboard if not enrolled

## Database Schema

### Core Tables

#### 1. `course_modules` - Course Lessons
Stores individual lessons for each course.

```sql
CREATE TABLE course_modules (
    id INT PRIMARY KEY AUTO_INCREMENT,
    course_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    content LONGTEXT,
    video_url VARCHAR(500),
    sequence_order INT DEFAULT 0,
    duration INT DEFAULT 0,  -- in minutes
    is_published TINYINT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    INDEX (course_id, sequence_order)
);
```

**Fields:**
- `title`: Lesson name (max 255 characters)
- `description`: Short lesson overview (for sidebar display)
- `content`: Long-form lesson content (markdown supported)
- `video_url`: YouTube video URL or video ID
- `sequence_order`: Order in which lessons appear (0-based)
- `duration`: Estimated lesson duration in minutes
- `is_published`: Controls visibility (1 = visible, 0 = hidden)

#### 2. `course_resources` - Downloadable Materials
Stores downloadable resources associated with lessons or courses.

```sql
CREATE TABLE course_resources (
    id INT PRIMARY KEY AUTO_INCREMENT,
    course_id INT NOT NULL,
    module_id INT,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    resource_type ENUM('pdf', 'document', 'book', 'code', 'template', 'other') DEFAULT 'document',
    file_path VARCHAR(500),  -- for local files
    file_url VARCHAR(500),   -- for external links
    is_external TINYINT DEFAULT 0,
    sequence_order INT DEFAULT 0,
    is_published TINYINT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    FOREIGN KEY (module_id) REFERENCES course_modules(id) ON DELETE SET NULL,
    INDEX (course_id, module_id, sequence_order)
);
```

**Fields:**
- `resource_type`: Type of resource (pdf, book, code, template, etc.)
- `file_path`: Local path for uploaded files (e.g., `course_1/lesson_1.pdf`)
- `file_url`: URL for external links or CDN resources
- `is_external`: Flag indicating external link (1) vs local file (0)
- `sequence_order`: Display order within module
- `is_published`: Visibility control

#### 3. `module_progress` - Lesson Tracking
Tracks which lessons each student has completed.

```sql
CREATE TABLE module_progress (
    student_id INT NOT NULL,
    module_id INT NOT NULL,
    course_id INT NOT NULL,
    is_completed TINYINT DEFAULT 0,
    watched_duration INT DEFAULT 0,  -- in seconds
    completed_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (student_id, module_id),
    FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (module_id) REFERENCES course_modules(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    INDEX (student_id, course_id, is_completed)
);
```

**Fields:**
- `student_id`: Reference to enrolled student
- `module_id`: Reference to lesson
- `is_completed`: Boolean (1 = completed, 0 = not completed)
- `watched_duration`: Seconds watched in video
- `completed_at`: Timestamp when marked complete

#### 4. `progress` - Course Progress Summary
Stores overall course progress per student.

```sql
CREATE TABLE progress (
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    progress_percentage INT DEFAULT 0,
    completed_modules INT DEFAULT 0,
    time_spent INT DEFAULT 0,  -- in minutes
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (student_id, course_id),
    FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
);
```

## File Structure

```
moiteek_academy/
├── student/
│   ├── course.php              # Main learning portal page
│   ├── dashboard.php           # Student dashboard
│   └── upload-payment.php      # Payment upload handler
├── api/
│   └── progress.php            # AJAX progress API endpoint
├── uploads/
│   ├── resources/              # Resource downloads
│   │   ├── course_1/
│   │   │   ├── lesson_1.pdf
│   │   │   └── code_template.zip
│   │   └── course_2/
│   └── avatars/                # Student profile pictures
└── sql/
    └── database.sql            # Database schema
```

## API Endpoints

### Progress Update API
**Endpoint:** `/api/progress.php`  
**Method:** `POST`  
**Authentication:** Required (student session)

#### Actions

#### 1. Complete Module
**Action:** `complete_module`

Request:
```json
{
    "action": "complete_module",
    "module_id": 5,
    "course_id": 2,
    "csrf_token": "..."
}
```

Response:
```json
{
    "success": true,
    "progress": {
        "percentage": 45,
        "completed_modules": 5,
        "total_modules": 12,
        "is_completed": false
    }
}
```

#### 2. Mark Incomplete
**Action:** `mark_incomplete`

Request:
```json
{
    "action": "mark_incomplete",
    "module_id": 5,
    "course_id": 2,
    "csrf_token": "..."
}
```

#### 3. Update Watch Time
**Action:** `update_watched_time`

Request:
```json
{
    "action": "update_watched_time",
    "module_id": 5,
    "duration": 480,
    "csrf_token": "..."
}
```

#### 4. Get Progress
**Action:** `get_progress`

Request:
```json
{
    "action": "get_progress",
    "course_id": 2,
    "csrf_token": "..."
}
```

Response:
```json
{
    "success": true,
    "progress": {
        "percentage": 45,
        "completed_modules": 5,
        "total_modules": 12,
        "modules": [
            {
                "module_id": 5,
                "is_completed": true
            }
        ],
        "is_completed": false
    }
}
```

## Front-End Elements

### Learning Portal Layout

```
┌─────────────────────────────────────────────────────────┐
│  Course Title │ Instructor │         Back │ Logout       │
│  Progress: XX%                                              │
└─────────────────────────────────────────────────────────┘

┌──────────────────────────────┬──────────────────┐
│                              │  Progress Card   │
│  Video Player (16:9)         │  45% (5/12)      │
│  YouTube Embed               │  Green bar       │
│                              │  "Course Done!" ·│
│                              │  (if 100%)       │
├──────────────────────────────├──────────────────┤
│  Lesson Title                │  Lessons (12)    │
│  Duration: 12 min            │  □ Lesson 1      │
│  [Mark Complete] Button      │  ☑ Lesson 2 ✓    │
│                              │  □ Lesson 3      │
│  Lesson Description          │  ...             │
│  [Long paragraph of text]    │  □ Lesson 12     │
│                              ├──────────────────┤
│  Lesson Content              │  Resources       │
│  [Structured content]        │  📄 PDF File     │
│                              │  📕 Book.pdf     │
│  [Prev] [Next] Buttons       │  💻 Code.zip     │
│                              │  📋 Template     │
└──────────────────────────────┴──────────────────┘
```

## Usage Instructions

### For Students

1. **Access Learning Portal**
   - Click "Continue Learning" on dashboard course card
   - Or navigate directly: `/student/course.php?id={course_id}`

2. **View Lessons**
   - Lesson list appears in right sidebar
   - Click any lesson to view its content
   - Currently selected lesson highlighted in blue

3. **Watch Videos**
   - YouTube video appears in main viewing area
   - Use standard YouTube controls (play, pause, volume, fullscreen)
   - Video embed includes related videos disabled for focus

4. **Mark Lesson Complete**
   - Click "Mark Complete" button after watching
   - Button turns green when completed
   - Progress bar updates immediately
   - Module shows checkmark in lesson list

5. **Download Resources**
   - Access resources in right sidebar
   - Click resource to download or open
   - PDFs open in browser, files trigger downloads

6. **Track Progress**
   - Monitor progress card at top of right sidebar
   - Shows "X/Y lessons completed" and percentage
   - Visual progress bar updates in real-time
   - Completion badge appears when course finished (100%)

### For Administrators/Instructors

#### Adding Course Modules (Lessons)

1. **Insert into `course_modules` table:**
   ```sql
   INSERT INTO course_modules (course_id, title, description, content, video_url, sequence_order, duration, is_published)
   VALUES (
       2,
       'Introduction to Web Design',
       'Learn the fundamentals of responsive web design principles',
       'Lesson content with detailed explanation...',
       'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
       1,
       45,
       1
   );
   ```

2. **Required fields:**
   - `course_id`: ID of the course
   - `title`: Lesson title (display name)
   - `sequence_order`: Display order (0, 1, 2, ...)
   - `is_published`: Set to 1 to make visible

#### Adding Course Resources

1. **Insert into `course_resources` table:**
   ```sql
   INSERT INTO course_resources (course_id, module_id, title, description, resource_type, file_path, is_external, sequence_order, is_published)
   VALUES (
       2,
       15,
       'Web Design Best Practices PDF',
       'Comprehensive guide to modern web design principles',
       'pdf',
       'course_2/lesson_1/design_guide.pdf',
       0,
       1,
       1
   );
   ```

2. **For external resources (external links):**
   ```sql
   INSERT INTO course_resources (course_id, module_id, title, description, resource_type, file_url, is_external, is_published)
   VALUES (
       2,
       15,
       'Bootstrap Documentation',
       'Official Bootstrap 5 documentation',
       'document',
       'https://getbootstrap.com/docs/5.0/',
       1,
       1
   );
   ```

#### File Upload Management

1. **Upload location:** `/uploads/resources/course_{id}/`
2. **Naming convention:** `lesson_{id}_{filename}`
3. **Supported formats:** PDF, ZIP, DOC, DOCX, PPT, PPTX, images
4. **Max file size:** Configure in PHP ini settings (typically 100MB)

#### Video URL Formats Supported

All these formats work in the learning portal:

```
Full URL: https://www.youtube.com/watch?v=dQw4w9WgXcQ
Short URL: https://youtu.be/dQw4w9WgXcQ
Direct ID: dQw4w9WgXcQ
```

## Progress Calculation

**Formula:**
```
Progress % = (Completed Modules / Total Modules) × 100
```

**Example:**
- Total modules in course: 12
- Modules completed by student: 5
- Progress percentage: (5 / 12) × 100 = 41.67% → rounds to 42%

## Security Features

1. **Authentication Required**
   - Students must be logged in via `Auth::isStudentLoggedIn()`
   - Session ID verified on each request

2. **Enrollment Verification**
   - Student must be enrolled in course
   - Payment status must be "approved"
   - Automatic redirect if unauthorized

3. **CSRF Protection**
   - All progress updates protected with CSRF tokens
   - `CSRF::validateRequest()` called on form submissions
   - `CSRF::generateTokenField()` in forms

4. **Input Validation**
   - All course/module IDs validated as numeric
   - HTML entities escaped in output
   - SQL prepared statements prevent injection

5. **Access Control**
   - Students can only access their own enrolled courses
   - Cannot modify other students' progress data
   - API enforces student_id verification

## Troubleshooting

### Videos Not Displaying
- **Issue:** Video player shows "No video available"
- **Solution:** 
  1. Verify video_url is valid YouTube URL or ID
  2. Check URL format matches supported formats
  3. Ensure video is public on YouTube

### Progress Not Updating
- **Issue:** "Mark Complete" button doesn't update progress bar
- **Solution:**
  1. Verify CSRF token is valid
  2. Check browser console for JavaScript errors
  3. Ensure database has module_progress table
  4. Check student is enrolled with "approved" payment_status

### Resources Not Displaying
- **Issue:** Resource downloads don't appear in sidebar
- **Solution:**
  1. Verify `is_published = 1` in course_resources table
  2. Check file path exists in `/uploads/resources/`
  3. Ensure file permissions allow reading
  4. For external links, verify URL is accessible

### Lessons Not Appearing
- **Issue:** No lessons shown in sidebar or main area
- **Solution:**
  1. Verify course_modules exist for this course
  2. Check `is_published = 1` for modules
  3. Verify course_id matches in URL parameter
  4. Ensure student is enrolled in the course

## Performance Optimization

1. **Database Indexes**
   - Queries use indexed columns: course_id, student_id, sequence_order
   - Reduces lookup time for large datasets

2. **Caching Opportunities**
   - Lesson content could be cached for 1 hour
   - Progress summaries could be cached per session

3. **Query Optimization**
   - Single query fetches all modules ordered
   - JOIN operations minimize database calls
   - Prepared statements prevent query compilation overhead

## Future Enhancements

1. **Video Analytics**
   - Track watch time per student
   - Identify engagement patterns
   - Recommend review of incomplete lessons

2. **Discussion Forums**
   - Per-lesson discussion threads
   - Student-to-student interaction
   - Instructor Q&A responses

3. **Quizzes & Assignments**
   - Module-level assessments
   - Auto-grading system
   - Assignment submission tracking

4. **Certificates**
   - Generate upon 100% completion
   - Display on student profile
   - Shareable certificate links

5. **Mobile App**
   - Native mobile learning experience
   - Offline video viewing
   - Push progress notifications

6. **Advanced Analytics**
   - Course completion trends
   - Time-to-completion metrics
   - Student performance analytics

## Support & Maintenance

### Regular Maintenance Tasks

- **Weekly:** Verify all video links remain accessible
- **Monthly:** Clean up obsolete resources from /uploads/
- **Quarterly:** Archive completed course progress data
- **Yearly:** Audit security, update dependencies

### Reporting Issues

If you encounter bugs or issues:
1. Check browser console for JavaScript errors
2. Review PHP error logs
3. Verify database integrity
4. Test with different browser/device

---

**Version:** 1.0  
**Last Updated:** 2024  
**Compatible With:** PHP 7.4+, MySQL 5.7+
