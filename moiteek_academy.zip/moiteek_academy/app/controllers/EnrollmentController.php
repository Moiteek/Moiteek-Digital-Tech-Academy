<?php
// app/controllers/EnrollmentController.php
// Handles student enrollment, payment, and admin approval

class EnrollmentController extends Controller {
    public function register() {
        // ...existing registration logic...
        // On registration, create enrollment with status 'pending'
        $enrollmentId = Enrollment::create([
            'student_id' => $studentId,
            'course_id' => $courseId,
            'status' => 'pending',
        ]);
        // Redirect to payment page
        Response::redirect('/payment/initiate.php?enrollment_id=' . $enrollmentId);
    }

    public function paymentInitiate($enrollmentId, $gateway) {
        // Create payment record with status 'pending', gateway info
        $paymentId = Payment::create([
            'enrollment_id' => $enrollmentId,
            'student_id' => $studentId,
            'course_id' => $courseId,
            'amount' => $amount,
            'gateway' => $gateway,
            'payment_status' => 'pending',
        ]);
        // Redirect to gateway handler (Paystack, Flutterwave, Stripe, or show bank transfer info)
        // ...gateway integration logic...
    }

    public function paymentWebhook($gateway) {
        // Receive webhook, verify signature, update payment status
        $payload = file_get_contents('php://input');
        $data = json_decode($payload, true);
        // ...verify and update payment, log transaction...
        Payment::updateStatusFromWebhook($data);
        // Log webhook
        PaymentTransaction::logWebhook($data);
    }

    public function adminApprove($enrollmentId) {
        // Admin approves enrollment after payment
        Enrollment::updateStatus($enrollmentId, 'approved');
        // Optionally notify student
    }

    public function adminReject($enrollmentId, $reason) {
        Enrollment::updateStatus($enrollmentId, 'rejected', $reason);
        // Optionally notify student
    }

    public function complete($enrollmentId) {
        Enrollment::updateStatus($enrollmentId, 'completed');
    }

    public function manualOverride($paymentId, $status, $reason) {
        Payment::manualOverride($paymentId, $status, $reason);
        // Log override
    }
}
