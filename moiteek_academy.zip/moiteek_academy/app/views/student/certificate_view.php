<?php
// app/views/student/certificate_view.php
?>
<div class="container mx-auto p-4">
  <h2 class="text-xl font-bold mb-2">Certificate of Completion</h2>
  <p><strong>Student:</strong> <?= htmlspecialchars($certificate['student_name']) ?></p>
  <p><strong>Course:</strong> <?= htmlspecialchars($certificate['course_title']) ?></p>
  <p><strong>Date:</strong> <?= $certificate['issue_date'] ?></p>
  <p><strong>Verification Code:</strong> <?= $certificate['certificate_code'] ?></p>
  <a href="/student/download_certificate.php?cert_id=<?= $certificate['id'] ?>" class="bg-blue-600 text-white px-4 py-2 rounded">Download PDF</a>
</div>
