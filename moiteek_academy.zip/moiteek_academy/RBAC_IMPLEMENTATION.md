# Role-Based Access Control (RBAC) for PHP LMS

## Roles
- Admin: Full access (manage users, courses, payments, reports)
- Student: Enroll, view courses, submit assignments, take quizzes
- Instructor (optional): Manage own courses, grade assignments/quizzes

## Implementation
- Add `role` column to users/admins table (ENUM: 'admin', 'student', 'instructor')
- Store role in session after login
- In Auth.php/core, add:
  - `Auth::checkRole($role)` to verify access
  - Middleware in controllers to restrict actions by role
- In views, show/hide UI elements based on role

## Example Usage
```php
if (!Auth::checkRole('admin')) {
    Response::redirect('auth/login.php', 'Access denied', 'error');
}
```

> RBAC ensures only authorized users can access sensitive features.
