<!-- 404 Error Page: Tailwind Udemy-style -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>404 Not Found</title>
  <link rel="stylesheet" href="https://cdn.tailwindcss.com">
</head>
<body class="bg-gray-50 flex items-center justify-center min-h-screen">
  <div class="bg-white p-8 rounded-lg shadow-lg text-center">
    <h1 class="text-4xl font-bold text-red-600 mb-4">404</h1>
    <p class="text-lg mb-6">Sorry, the page you’re looking for doesn’t exist.</p>
    <a href="/index.php" class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 font-semibold">Back to Home</a>
  </div>
</body>
</html>
