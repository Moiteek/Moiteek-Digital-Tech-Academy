# DATABASE_MIGRATION.md - Upgrade to Security-Enhanced Version

Migration guide for upgrading existing Moiteek Academy installations to the security-enhanced version.

---

## 📋 **Pre-Migration Checklist**

- [ ] Backup current database
- [ ] Backup application files
- [ ] Test on development environment first  
- [ ] Schedule maintenance window (5-10 minutes)
- [ ] Notify users of brief maintenance

---

## 🆙 **Migration Steps**

### **Step 1: Backup Existing Database**

**Windows (Command Prompt):**
```bash
cd c:\xampp\mysql\bin
mysqldump -u root -p moiteek_academy > backup_before_upgrade.sql
```

**Linux/Mac:**
```bash
mysqldump -u root -p moiteek_academy > backup_before_upgrade.sql
```

---

### **Step 2: Add Email Verification Column to Students Table**

**If `email_verified` column doesn't exist:**

```sql
ALTER TABLE students ADD COLUMN email_verified TINYINT(1) DEFAULT 0 AFTER status;
```

**Verify it was added:**
```sql
DESCRIBE students;
-- Should show: email_verified | tinyint(1) | YES | | 0 |
```

---

### **Step 3: Create Email Verification Tokens Table**

```sql
CREATE TABLE IF NOT EXISTS email_verification_tokens(
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    token VARCHAR(64) UNIQUE NOT NULL,
    email VARCHAR(100) NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    INDEX idx_token (token),
    INDEX idx_student_id (student_id),
    INDEX idx_expires_at (expires_at)
);
```

---

### **Step 4: Create Password Reset Tokens Table**

```sql
CREATE TABLE IF NOT EXISTS password_reset_tokens(
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    token VARCHAR(64) UNIQUE NOT NULL,
    email VARCHAR(100) NOT NULL,
    user_type ENUM('admin', 'student') NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_token (token),
    INDEX idx_user_id (user_id),
    INDEX idx_expires_at (expires_at)
);
```

---

### **Step 5: Create Login Activity Log Table**

```sql
CREATE TABLE IF NOT EXISTS login_activity(
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    user_type ENUM('admin', 'student'),
    email VARCHAR(100),
    ip_address VARCHAR(45),
    user_agent TEXT,
    login_status ENUM('success', 'failed', 'locked') DEFAULT 'success',
    failure_reason VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_email (email),
    INDEX idx_created_at (created_at)
);
```

---

### **Step 6: Create CSRF Tokens Table (Optional)**

```sql
CREATE TABLE IF NOT EXISTS csrf_tokens(
    id INT AUTO_INCREMENT PRIMARY KEY,
    token VARCHAR(64) UNIQUE NOT NULL,
    session_id VARCHAR(255),
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_token (token),
    INDEX idx_session_id (session_id),
    INDEX idx_expires_at (expires_at)
);
```

---

### **Step 7: Update Existing Students (Mark as Email Verified)**

Mark all existing approved students as email verified (they already have emails):

```sql
UPDATE students SET email_verified = 1 WHERE status = 'approved';
```

**Verify:**
```sql
SELECT COUNT(*) as verified_count FROM students WHERE email_verified = 1;
SELECT COUNT(*) as total_count FROM students;
```

---

### **Step 8: Add Database Indexes**

Ensure proper indexing on students table:

```sql
-- Check if email_verified index exists
SHOW INDEX FROM students WHERE Column_name = 'email_verified';

-- If not, add it
ALTER TABLE students ADD INDEX idx_email_verified (email_verified);
```

---

### **Step 9: Update Application Files**

Replace these files in your installation:

**Delete/Replace:**
- `includes/Auth.php` (complete rewrite)
- `includes/Validator.php` (enhancements)
- `bootstrap.php` (updated to include new classes)
- `config/db.php` (enhanced security)

**Create New:**
- `includes/Email.php`
- `includes/CSRF.php`
- `SECURITY.md`
- `SECURITY_IMPROVEMENTS.md`
- `DATABASE_MIGRATION.md` (this file)

---

### **Step 10: Test the Migration**

**Test Admin Login:**
1. Visit: http://localhost/moiteek_academy/auth/login.php
2. Login with admin account
3. Should see admin dashboard

**Test Student Registration:**
1. Visit: http://localhost/moiteek_academy/auth/register.php
2. Fill registration form
3. Submit → Should get email verification link
4. Check email and click link
5. Navigate to login and try to login (should say "pending approval")

**Test Admin Approval:**
1. Login as admin
2. Go to Students management
3. Find new student
4. Approve student
5. Student can now login

---

## 🔄 **Roll-Back Plan**

If something goes wrong:

**Step 1: Stop the application**
```bash
# Stop web server
sudo systemctl stop apache2  # or nginx
```

**Step 2: Restore database backup**
```bash
mysql -u root -p moiteek_academy < backup_before_upgrade.sql
```

**Step 3: Restore application files**
```bash
# From your backup
cp -r backup_version/* /var/www/html/moiteek_academy/
```

**Step 4: Restart and verify**
```bash
sudo systemctl start apache2
# Visit http://localhost/moiteek_academy
```

---

## ⚠️ **Known Issues & Solutions**

### **Issue: Table Already Exists**

**Error:** `Table 'email_verification_tokens' already exists`

**Solution:** Use `IF NOT EXISTS` (already in scripts above)

---

### **Issue: Column Already Exists**

**Error:** `Duplicate column name 'email_verified'`

**Solution:** Skip that step if column exists
```sql
-- Check if exists
SHOW COLUMNS FROM students WHERE Field = 'email_verified';

-- If it shows, skip the ADD COLUMN step
```

---

### **Issue: Foreign Key Constraint Failed**

**Error:** `Cannot add foreign key constraint`

**Solution:** Ensure students and admins tables exist with proper indexes
```sql
-- Check tables
SHOW TABLES;

-- Check constraints
SHOW CREATE TABLE email_verification_tokens\G
```

---

### **Issue: Email Not Sending**

**Error:** Emails not being received after registration

**Solution:** Configure SMTP in `includes/Email.php`
```php
Email::configureSmtp(
    'smtp.gmail.com',  // Host
    465,               // Port
    'your@email.com',  // Username
    'password'         // Password
);
```

---

## 📊 **Migration Verification Checklist**

**Database:**
- [ ] `email_verification_tokens` table created
- [ ] `password_reset_tokens` table created
- [ ] `login_activity` table created
- [ ] `csrf_tokens` table created (optional)
- [ ] `students.email_verified` column added
- [ ] Existing students marked as verified
- [ ] All indexes created

**Application:**
- [ ] `includes/Email.php` uploaded
- [ ] `includes/CSRF.php` uploaded
- [ ] `includes/Auth.php` replaced
- [ ] `includes/Validator.php` updated
- [ ] `bootstrap.php` updated
- [ ] `config/db.php` updated

**Functionality:**
- [ ] Admin login works
- [ ] Student registration works
- [ ] Verification email sent
- [ ] Email verification link works
- [ ] Admin approval workflow works
- [ ] Login rate limiting works
- [ ] CSRF tokens generated
- [ ] Password reset works

**Documentation:**
- [ ] `SECURITY.md` added
- [ ] `SECURITY_IMPROVEMENTS.md` added
- [ ] This migration guide present

---

## 🚀 **Post-Migration Tasks**

### **1. Update Configuration**

Edit `config/db.php`:
```php
// For HTTPS in production
define('SECURE_COOKIE', true);
define('SSL_ENABLED', true);

// Update app URL
define('APP_URL', 'https://yourdomain.com');
```

---

### **2. Configure Email (Optional but Recommended)**

For production, configure SMTP instead of using PHP mail():

**Install PHPMailer (if using):**
```bash
composer require phpmailer/phpmailer
```

**Update Email.php to use PHPMailer:**
```php
use PHPMailer\PHPMailer\PHPMailer;

public static function send($to, $subject, $htmlBody) {
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->Port = 465;
    // ... configure ...
    $mail->addAddress($to);
    $mail->Subject = $subject;
    $mail->Body = $htmlBody;
    // ... send ...
}
```

---

### **3. Test All Workflows**

- [ ] Fresh user registration (email verification)
- [ ] Admin approval/rejection
- [ ] Student login (approved)
- [ ] Forgot password flow
- [ ] Login rate limiting
- [ ] Session timeout
- [ ] CSRF protection

---

### **4. Update Documentation**

- [ ] Update README.md with new features
- [ ] Document SMTP configuration
- [ ] Document security best practices
- [ ] Update deployment guide

---

### **5. Notify Users**

If you have existing students:

**Email Template:**
```
Subject: Security Improvements

Hello,

We've upgraded our platform with enhanced security features:

✓ Email verification for new accounts
✓ Admin approval requirement
✓ Secure password reset
✓ Login attempt protection
✓ CSRF protection

Your account is ready to use with these new features.

Questions? Contact support@moiteek.com

Best regards,
Moiteek Academy Team
```

---

## 📞 **Migration Support**

**Common Questions:**

**Q: Do I need to update existing student accounts?**
A: No, existing students are automatically marked as verified and approved.

**Q: Will users lose access during migration?**
A: Brief downtime (5-10 min) during database updates. Plan for off-hours if possible.

**Q: Do I need to update passwords?**
A: No, existing bcrypt passwords remain valid.

**Q: What about old password hashes?**
A: They're automatically upgraded to latest bcrypt cost on next login.

**Q: Can I revert if something breaks?**
A: Yes, follow the Roll-Back Plan section above.

---

## ✅ **Migration Complete!**

Your Moiteek Academy is now security-enhanced! 🎉

**What Changed:**
- ✅ Email verification workflow
- ✅ Admin approval requirement
- ✅ Login rate limiting
- ✅ Password reset system
- ✅ CSRF tokens
- ✅ Enhanced activity logging
- ✅ Security headers
- ✅ Session regeneration

**Next Steps:**
1. Review `SECURITY.md` for all features
2. Test all user workflows
3. Update your documentation
4. Notify users of improvements
5. Monitor activity logs

---

**Questions? Check SECURITY.md or DEVELOPMENT.md!**
