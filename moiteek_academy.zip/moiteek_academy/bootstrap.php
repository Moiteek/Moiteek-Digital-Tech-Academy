<?php
/**
 * Application Bootstrap
 * Initialize all required classes and configurations
 */

// Include database connection
require_once __DIR__ . '/config/db.php';

// Include all helper classes
require_once __DIR__ . '/includes/Auth.php';
require_once __DIR__ . '/includes/Validator.php';
require_once __DIR__ . '/includes/Response.php';
require_once __DIR__ . '/includes/Database.php';
require_once __DIR__ . '/includes/FileManager.php';
require_once __DIR__ . '/includes/Email.php';
require_once __DIR__ . '/includes/CSRF.php';

// Initialize helper classes with PDO
Auth::setPDO($pdo);
Database::setPDO($pdo);

// Initialize CSRF protection
CSRF::init();

// Application constants
define('APP_NAME', 'Moiteek Digital Tech Academy');
define('APP_VERSION', '1.0.0');
define('APP_THEME', 'modern');
define('APP_URL', 'http://localhost/moiteek_academy');  // Update for production

// Security headers
if(!headers_sent()) {
    header("X-Content-Type-Options: nosniff");
    header("X-Frame-Options: SAMEORIGIN");
    header("X-XSS-Protection: 1; mode=block");
    header("Referrer-Policy: strict-origin-when-cross-origin");
}
?>