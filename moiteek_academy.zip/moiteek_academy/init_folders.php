<?php
// init_folders.php - One-time folder setup for local environment
$folders = [
    __DIR__ . '/uploads/payments/',
    __DIR__ . '/uploads/courses/',
    __DIR__ . '/assets/css/',
];
$created = [];
foreach ($folders as $folder) {
    if (!is_dir($folder)) {
        if (mkdir($folder, 0777, true)) {
            $created[] = $folder;
        }
    }
}
if (empty($created)) {
    echo "All folders already exist.";
} else {
    echo "Created folders:<br>" . implode('<br>', $created);
}
