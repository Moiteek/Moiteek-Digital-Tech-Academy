<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
function requireAdmin() {
    if (empty($_SESSION['admin_id'])) {
        header('Location: /admin/login.php?error=unauthorized');
        exit;
    }
}
function requireStudent() {
    if (empty($_SESSION['student_id'])) {
        header('Location: /auth/login.php?error=unauthorized');
        exit;
    }
    // Check if student is approved/active
    global $pdo;
    $stmt = $pdo->prepare('SELECT status FROM students WHERE id = ?');
    $stmt->execute([$_SESSION['student_id']]);
    $status = $stmt->fetchColumn();
    if ($status !== 'active') {
        session_unset();
        session_destroy();
        header('Location: /auth/login.php?error=not_approved');
        exit;
    }
}
