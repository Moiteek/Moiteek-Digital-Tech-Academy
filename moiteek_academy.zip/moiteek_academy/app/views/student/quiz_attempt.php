<?php
// app/views/student/quiz_attempt.php
?>
<div class="container mx-auto p-4">
  <h2 class="text-xl font-bold mb-2">Quiz Attempt</h2>
  <form method="POST" action="/student/quiz_submit.php">
    <input type="hidden" name="quiz_id" value="<?= $quiz_id ?>">
    <?php foreach ($questions as $q): ?>
      <div class="mb-4">
        <label class="font-semibold">Q: <?= htmlspecialchars($q['question_text']) ?></label>
        <?php if ($q['question_type'] === 'mcq'): ?>
          <?php foreach (explode("\n", $q['options']) as $opt): ?>
            <div>
              <input type="radio" name="answers[<?= $q['id'] ?>]" value="<?= htmlspecialchars($opt) ?>" required> <?= htmlspecialchars($opt) ?>
            </div>
          <?php endforeach; ?>
        <?php else: ?>
          <textarea name="answers[<?= $q['id'] ?>]" class="border px-2 py-1 w-full" required></textarea>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Submit Quiz</button>
  </form>
</div>
