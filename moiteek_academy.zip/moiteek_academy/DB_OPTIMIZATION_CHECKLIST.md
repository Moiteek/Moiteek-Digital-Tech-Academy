# Database Optimization Checklist

- All tables have primary keys
- Use proper indexes on foreign keys and search columns
- Use ENUMs for status/role fields
- Use `created_at`, `updated_at` timestamps
- Use `ON DELETE CASCADE` for foreign keys where appropriate
- Normalize tables (no redundant data)
- Use pagination (LIMIT/OFFSET) for large queries
- Use prepared statements for all queries
- Analyze slow queries and add indexes as needed
- Use transactions for multi-step DB operations

> These optimizations ensure fast, reliable, and scalable database performance.
