<?php
require_once '../bootstrap.php';

if(!Auth::isAdminLoggedIn()) {
    Response::redirect('../admin/login.php', 'Please login', 'error');
}

// Handle actions
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $student_id = (int)$_POST['student_id'];
    $action = Validator::sanitizeInput($_POST['action']);
    
    $stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
    $stmt->execute([$student_id]);
    $student = $stmt->fetch();
    
    if($student) {
        switch($action) {

            case 'approve':
                // Generate random 8-character password
                $randomPassword = substr(bin2hex(random_bytes(8)), 0, 8);
                $hashedPassword = password_hash($randomPassword, PASSWORD_DEFAULT);
                // Set status to 'active' and update password
                $update = $pdo->prepare("UPDATE students SET status = 'active', password = ? WHERE id = ?");
                $update->execute([$hashedPassword, $student_id]);
                // Prepare login details notification (could be email or flash message)
                $_SESSION['login_details_notification'] = [
                    'student_id' => $student_id,
                    'password' => $randomPassword
                ];
                Response::redirect('students.php', 'Student approved and login details generated!', 'success');
                break;
                
            case 'suspend':
                $update = $pdo->prepare("UPDATE students SET status = 'suspended', is_active = 0 WHERE id = ?");
                $update->execute([$student_id]);
                Response::redirect('students.php', 'Student suspended successfully!', 'success');
                break;
                
            case 'reject':
                $update = $pdo->prepare("UPDATE students SET status = 'rejected', is_active = 0 WHERE id = ?");
                $update->execute([$student_id]);
                Response::redirect('students.php', 'Student rejected!', 'success');
                break;
                
            case 'delete':
                // Delete related records first
                $pdo->prepare("DELETE FROM enrollments WHERE student_id = ?")->execute([$student_id]);
                $pdo->prepare("DELETE FROM module_progress WHERE student_id = ?")->execute([$student_id]);
                $pdo->prepare("DELETE FROM progress WHERE student_id = ?")->execute([$student_id]);
                $pdo->prepare("DELETE FROM students WHERE id = ?")->execute([$student_id]);
                Response::redirect('students.php', 'Student deleted successfully!', 'success');
                break;
                
            case 'activate':
                $update = $pdo->prepare("UPDATE students SET is_active = 1, status = 'approved' WHERE id = ?");
                $update->execute([$student_id]);
                Response::redirect('students.php', 'Student activated!', 'success');
                break;
        }
    }
}

// Get filter
$status_filter = Validator::sanitizeInput($_GET['status'] ?? '');
$search = Validator::sanitizeInput($_GET['search'] ?? '');

// Get students with filters
$sql = "SELECT * FROM students WHERE 1=1";
$params = [];

if($status_filter && in_array($status_filter, ['pending', 'approved', 'rejected', 'suspended'])) {
    $sql .= " AND status = ?";
    $params[] = $status_filter;
}

if($search) {
    $sql .= " AND (fullname LIKE ? OR email LIKE ?)";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
}

$sql .= " ORDER BY enrollment_date DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$students = $stmt->fetchAll();

// Get student stats  
$stats = $pdo->query("
    SELECT 
        status,
        COUNT(*) as count 
    FROM students 
    GROUP BY status
")->fetchAll(PDO::FETCH_KEY_PAIR);

$flash = Response::getFlashMessage();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Students Management - <?= APP_NAME ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <i class="fas fa-graduation-cap text-2xl text-blue-600"></i>
                <span class="font-bold text-lg text-gray-800"><?= APP_NAME ?></span>
            </div>
            <div class="flex items-center gap-4">
                <a href="dashboard.php" class="text-gray-600 hover:text-blue-600">
                    <i class="fas fa-home mr-1"></i>Dashboard
                </a>
                <a href="../auth/logout.php" class="p-2 text-gray-600 hover:bg-red-50 hover:text-red-600 rounded-lg transition">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </div>
    </nav>

    <div class="flex">
        <!-- Sidebar -->
        <aside class="w-64 bg-white shadow-lg min-h-screen">
            <div class="p-4 space-y-2">
                <a href="dashboard.php" class="block px-4 py-3 rounded-lg hover:bg-gray-100 transition">
                    <i class="fas fa-chart-line mr-2"></i>Dashboard
                </a>
                <a href="students.php" class="block px-4 py-3 rounded-lg bg-blue-600 text-white font-semibold">
                    <i class="fas fa-users mr-2"></i>Students
                </a>
                <a href="courses.php" class="block px-4 py-3 rounded-lg hover:bg-gray-100 transition">
                    <i class="fas fa-book mr-2"></i>Courses
                </a>
                <a href="payments.php" class="block px-4 py-3 rounded-lg hover:bg-gray-100 transition">
                    <i class="fas fa-credit-card mr-2"></i>Payments
                </a>
                <a href="enrollments.php" class="block px-4 py-3 rounded-lg hover:bg-gray-100 transition">
                    <i class="fas fa-list mr-2"></i>Enrollments
                </a>
                <hr class="my-3">
                <a href="analytics.php" class="block px-4 py-3 rounded-lg hover:bg-gray-100 transition">
                    <i class="fas fa-chart-bar mr-2"></i>Analytics
                </a>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="flex-1 p-8">
            <!-- Flash Message -->
            <?php if($flash): ?>
                <div class="mb-6 p-4 rounded-lg bg-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-50 border border-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-200 flex items-center gap-3">
                    <i class="fas fa-<?= $flash['type'] === 'error' ? 'exclamation-circle' : 'check-circle' ?> text-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-600"></i>
                    <p class="text-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-700"><?= htmlspecialchars($flash['message']) ?></p>
                </div>
            <?php endif; ?>

            <!-- Page Header -->
            <div class="mb-8">
                <h1 class="text-3xl font-bold text-gray-800 flex items-center gap-2 mb-2">
                    <i class="fas fa-users text-blue-600"></i>Students Management
                </h1>
                <p class="text-gray-600">Approve, manage, and monitor student accounts</p>
            </div>

            <!-- Stats Cards -->
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
                <div class="bg-white rounded-lg shadow p-4 border-l-4 border-blue-600">
                    <p class="text-gray-600 text-sm">Total Students</p>
                    <p class="text-2xl font-bold text-gray-800 mt-1"><?= array_sum($stats) ?></p>
                </div>
                <div class="bg-white rounded-lg shadow p-4 border-l-4 border-yellow-600">
                    <p class="text-gray-600 text-sm">Pending Approval</p>
                    <p class="text-2xl font-bold text-yellow-600 mt-1"><?= $stats['pending'] ?? 0 ?></p>
                </div>
                <div class="bg-white rounded-lg shadow p-4 border-l-4 border-green-600">
                    <p class="text-gray-600 text-sm">Approved</p>
                    <p class="text-2xl font-bold text-green-600 mt-1"><?= $stats['approved'] ?? 0 ?></p>
                </div>
                <div class="bg-white rounded-lg shadow p-4 border-l-4 border-red-600">
                    <p class="text-gray-600 text-sm">Suspended</p>
                    <p class="text-2xl font-bold text-red-600 mt-1"><?= $stats['suspended'] ?? 0 ?></p>
                </div>
            </div>

            <!-- Filters & Search -->
            <div class="bg-white rounded-lg shadow p-6 mb-6">
                <form method="GET" class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Search by Name or Email</label>
                        <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Search..." class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Status Filter</label>
                        <select name="status" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                            <option value="">All Status</option>
                            <option value="pending" <?= $status_filter === 'pending' ? 'selected' : '' ?>>Pending</option>
                            <option value="approved" <?= $status_filter === 'approved' ? 'selected' : '' ?>>Approved</option>
                            <option value="suspended" <?= $status_filter === 'suspended' ? 'selected' : '' ?>>Suspended</option>
                            <option value="rejected" <?= $status_filter === 'rejected' ? 'selected' : '' ?>>Rejected</option>
                        </select>
                    </div>
                    <div class="flex items-end gap-2">
                        <button type="submit" class="flex-1 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 font-semibold transition">
                            <i class="fas fa-search mr-1"></i>Search
                        </button>
                        <a href="students.php" class="flex-1 bg-gray-300 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-400 font-semibold transition text-center">
                            <i class="fas fa-times mr-1"></i>Reset
                        </a>
                    </div>
                </form>
            </div>

            <!-- Students Table -->
            <div class="bg-white rounded-lg shadow overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead class="bg-gray-50 border-b">
                            <tr>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-700">Student</th>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-700">Email</th>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-700">Status</th>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-700">Joined</th>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-700">Last Login</th>
                                <th class="px-6 py-3 text-center text-sm font-semibold text-gray-700">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y">
                            <?php if(empty($students)): ?>
                                <tr>
                                    <td colspan="6" class="px-6 py-8 text-center text-gray-500">
                                        <i class="fas fa-inbox text-4xl text-gray-300 mb-2"></i>
                                        <p>No students found</p>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach($students as $student): ?>
                                    <tr class="hover:bg-gray-50 transition">
                                        <td class="px-6 py-4">
                                            <div class="flex items-center gap-3">
                                                <div class="w-10 h-10 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center text-white font-bold">
                                                    <?= strtoupper(substr($student['fullname'], 0, 1)) ?>
                                                </div>
                                                <div>
                                                    <p class="font-semibold text-gray-800"><?= htmlspecialchars($student['fullname']) ?></p>
                                                    <p class="text-xs text-gray-500">@<?= htmlspecialchars($student['username']) ?></p>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 text-gray-800"><?= htmlspecialchars($student['email']) ?></td>
                                        <td class="px-6 py-4">
                                            <span class="px-3 py-1 rounded-full text-xs font-bold 
                                                <?php 
                                                if($student['status'] === 'approved') echo 'bg-green-100 text-green-800';
                                                elseif($student['status'] === 'pending') echo 'bg-yellow-100 text-yellow-800';
                                                elseif($student['status'] === 'suspended') echo 'bg-red-100 text-red-800';
                                                else echo 'bg-gray-100 text-gray-800';
                                                ?>">
                                                <?= ucfirst($student['status']) ?>
                                            </span>
                                        </td>
                                        <td class="px-6 py-4 text-sm text-gray-600"><?= date('M d, Y', strtotime($student['enrollment_date'])) ?></td>
                                        <td class="px-6 py-4 text-sm text-gray-600">
                                            <?= $student['last_login'] ? date('M d, Y H:i', strtotime($student['last_login'])) : 'Never' ?>
                                        </td>
                                        <td class="px-6 py-4">
                                            <div class="flex items-center justify-center gap-2">
                                                <a href="student-detail.php?id=<?= $student['id'] ?>" class="p-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 transition" title="View Details">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <?php if($student['status'] === 'pending'): ?>
                                                    <form method="POST" style="display:inline;">
                                                        <input type="hidden" name="student_id" value="<?= $student['id'] ?>">
                                                        <input type="hidden" name="action" value="approve">
                                                        <button type="submit" class="p-2 bg-green-100 text-green-600 rounded-lg hover:bg-green-200 transition" title="Approve">
                                                            <i class="fas fa-check"></i>
                                                        </button>
                                                    </form>
                                                    <form method="POST" style="display:inline;">
                                                        <input type="hidden" name="student_id" value="<?= $student['id'] ?>">
                                                        <input type="hidden" name="action" value="reject">
                                                        <button type="submit" class="p-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition" title="Reject">
                                                            <i class="fas fa-times"></i>
                                                        </button>
                                                    </form>
                                                <?php endif; ?>
                                                <?php if($student['status'] === 'approved' && $student['is_active']): ?>
                                                    <form method="POST" style="display:inline;">
                                                        <input type="hidden" name="student_id" value="<?= $student['id'] ?>">
                                                        <input type="hidden" name="action" value="suspend">
                                                        <button type="submit" onclick="return confirm('Suspend this student?')" class="p-2 bg-yellow-100 text-yellow-600 rounded-lg hover:bg-yellow-200 transition" title="Suspend">
                                                            <i class="fas fa-ban"></i>
                                                        </button>
                                                    </form>
                                                <?php endif; ?>
                                                <?php if($student['status'] === 'suspended'): ?>
                                                    <form method="POST" style="display:inline;">
                                                        <input type="hidden" name="student_id" value="<?= $student['id'] ?>">
                                                        <input type="hidden" name="action" value="activate">
                                                        <button type="submit" class="p-2 bg-green-100 text-green-600 rounded-lg hover:bg-green-200 transition" title="Reactivate">
                                                            <i class="fas fa-unlock"></i>
                                                        </button>
                                                    </form>
                                                <?php endif; ?>
                                                <form method="POST" style="display:inline;">
                                                    <input type="hidden" name="student_id" value="<?= $student['id'] ?>">
                                                    <input type="hidden" name="action" value="delete">
                                                    <button type="submit" onclick="return confirm('Permanently delete this student? This action cannot be undone.')" class="p-2 bg-gray-200 text-gray-600 rounded-lg hover:bg-red-200 hover:text-red-600 transition" title="Delete">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Students Management - <?= APP_NAME ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <i class="fas fa-graduation-cap text-2xl text-blue-600"></i>
                <span class="font-bold text-lg text-gray-800"><?= APP_NAME ?></span>
                <span class="bg-blue-100 text-blue-800 text-xs px-3 py-1 rounded-full font-semibold">Admin</span>
            </div>
            <div class="flex items-center gap-4">
                <a href="dashboard.php" class="text-gray-600 hover:text-blue-600">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
                <a href="../auth/logout.php" class="p-2 text-gray-600 hover:bg-red-50 hover:text-red-600 rounded-lg transition">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </div>
    </nav>

    <div class="flex">
        <!-- Sidebar -->
        <aside class="w-64 bg-white shadow-lg min-h-screen">
            <div class="p-4 space-y-2">
                <a href="dashboard.php" class="block px-4 py-3 rounded-lg hover:bg-gray-100">
                    <i class="fas fa-chart-line mr-2"></i>Dashboard
                </a>
                <a href="students.php" class="block px-4 py-3 rounded-lg bg-blue-600 text-white font-semibold">
                    <i class="fas fa-users mr-2"></i>Students
                </a>
                <a href="courses.php" class="block px-4 py-3 rounded-lg hover:bg-gray-100">
                    <i class="fas fa-book mr-2"></i>Courses
                </a>
                <a href="payments.php" class="block px-4 py-3 rounded-lg hover:bg-gray-100">
                    <i class="fas fa-credit-card mr-2"></i>Payments
                </a>
                <a href="enrollments.php" class="block px-4 py-3 rounded-lg hover:bg-gray-100">
                    <i class="fas fa-clipboard-list mr-2"></i>Enrollments
                </a>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="flex-1 p-8">
            <!-- Flash Message -->
            <?php if($flash): ?>
                <div class="mb-6 p-4 rounded-lg bg-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-50 border border-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-200 flex items-center gap-3">
                    <i class="fas fa-<?= $flash['type'] === 'error' ? 'exclamation-circle' : 'check-circle' ?> text-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-600"></i>
                    <p class="text-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-700"><?= htmlspecialchars($flash['message']) ?></p>
                </div>
            <?php endif; ?>

            <!-- Page Header -->
            <div class="mb-8">
                <h1 class="text-3xl font-bold text-gray-800 flex items-center gap-2 mb-2">
                    <i class="fas fa-users text-blue-600"></i>Students Management
                </h1>
                <p class="text-gray-600">Manage and approve student registrations</p>
            </div>

            <!-- Filters -->
            <div class="bg-white rounded-lg shadow p-6 mb-6">
                <div class="flex items-center gap-4">
                    <span class="text-sm font-semibold text-gray-700">Filter by Status:</span>
                    <div class="flex gap-2">
                        <a href="students.php" class="px-4 py-2 rounded-lg <?= empty($status_filter) ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200' ?> text-sm font-semibold transition">
                            All
                        </a>
                        <a href="students.php?status=pending" class="px-4 py-2 rounded-lg <?= $status_filter === 'pending' ? 'bg-yellow-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200' ?> text-sm font-semibold transition">
                            Pending
                        </a>
                        <a href="students.php?status=approved" class="px-4 py-2 rounded-lg <?= $status_filter === 'approved' ? 'bg-green-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200' ?> text-sm font-semibold transition">
                            Approved
                        </a>
                        <a href="students.php?status=rejected" class="px-4 py-2 rounded-lg <?= $status_filter === 'rejected' ? 'bg-red-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200' ?> text-sm font-semibold transition">
                            Rejected
                        </a>
                    </div>
                </div>
            </div>

            <!-- Students Table -->
            <div class="bg-white rounded-lg shadow overflow-hidden">
                <table class="w-full">
                    <thead class="bg-gray-50 border-b">
                        <tr>
                            <th class="px-6 py-4 text-left text-sm font-semibold text-gray-700">Name</th>
                            <th class="px-6 py-4 text-left text-sm font-semibold text-gray-700">Email</th>
                            <th class="px-6 py-4 text-left text-sm font-semibold text-gray-700">Username</th>
                            <th class="px-6 py-4 text-left text-sm font-semibold text-gray-700">Status</th>
                            <th class="px-6 py-4 text-left text-sm font-semibold text-gray-700">Enrolled</th>
                            <th class="px-6 py-4 text-left text-sm font-semibold text-gray-700">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($students)): ?>
                            <tr>
                                <td colspan="6" class="px-6 py-8 text-center text-gray-600">
                                    <i class="fas fa-inbox text-3xl mb-2"></i>
                                    <p class="mt-2">No students found</p>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach($students as $student): ?>
                                <tr class="border-b hover:bg-gray-50">
                                    <td class="px-6 py-4">
                                        <div class="flex items-center gap-3">
                                            <div class="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                                                <i class="fas fa-user text-blue-600"></i>
                                            </div>
                                            <span class="font-semibold text-gray-800"><?= htmlspecialchars($student['fullname']) ?></span>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 text-gray-700"><?= htmlspecialchars($student['email']) ?></td>
                                    <td class="px-6 py-4 text-gray-700">@<?= htmlspecialchars($student['username']) ?></td>
                                    <td class="px-6 py-4">
                                        <span class="px-3 py-1 rounded-full text-xs font-semibold bg-<?= $student['status'] === 'approved' ? 'green' : ($student['status'] === 'pending' ? 'yellow' : 'red') ?>-100 text-<?= $student['status'] === 'approved' ? 'green' : ($student['status'] === 'pending' ? 'yellow' : 'red') ?>-800">
                                            <?= ucfirst($student['status']) ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 text-sm text-gray-600"><?= Helper::formatDate($student['enrollment_date']) ?></td>
                                    <td class="px-6 py-4 space-x-2">
                                        <a href="student_detail.php?id=<?= $student['id'] ?>" class="text-blue-600 hover:text-blue-800 text-sm font-semibold">
                                            <i class="fas fa-eye"></i> View
                                        </a>
                                        <?php if($student['status'] === 'pending'): ?>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="student_id" value="<?= $student['id'] ?>">
                                                <input type="hidden" name="action" value="approve">
                                                <button type="submit" class="text-green-600 hover:text-green-800 text-sm font-semibold">
                                                    <i class="fas fa-check"></i> Approve
                                                </button>
                                            </form>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="student_id" value="<?= $student['id'] ?>">
                                                <input type="hidden" name="action" value="reject">
                                                <button type="submit" class="text-red-600 hover:text-red-800 text-sm font-semibold" onclick="return confirm('Are you sure?')">
                                                    <i class="fas fa-times"></i> Reject
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</body>
</html>