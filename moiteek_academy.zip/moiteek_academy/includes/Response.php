<?php
/**
 * Response Handler Class
 * Standardized response format for API and frontend
 */

class Response {
    
    /**
     * Send success response
     */
    public static function success($data = [], $message = 'Success', $code = 200) {
        http_response_code($code);
        return [
            'success' => true,
            'message' => $message,
            'data' => $data,
            'code' => $code
        ];
    }

    /**
     * Send error response
     */
    public static function error($message = 'Error', $errors = [], $code = 400) {
        http_response_code($code);
        return [
            'success' => false,
            'message' => $message,
            'errors' => $errors,
            'code' => $code
        ];
    }

    /**
     * Redirect with message
     */
    public static function redirect($url, $message = '', $type = 'success') {
        if($message) {
            $_SESSION['flash_message'] = $message;
            $_SESSION['flash_type'] = $type;
        }
        header("Location: $url");
        exit();
    }

    /**
     * Get flash message
     */
    public static function getFlashMessage() {
        if(isset($_SESSION['flash_message'])) {
            $msg = $_SESSION['flash_message'];
            $type = $_SESSION['flash_type'] ?? 'info';
            unset($_SESSION['flash_message'], $_SESSION['flash_type']);
            return ['message' => $msg, 'type' => $type];
        }
        return null;
    }

    /**
     * Send JSON response
     */
    public static function json($data, $code = 200) {
        header('Content-Type: application/json');
        http_response_code($code);
        echo json_encode($data);
        exit();
    }
}
?>