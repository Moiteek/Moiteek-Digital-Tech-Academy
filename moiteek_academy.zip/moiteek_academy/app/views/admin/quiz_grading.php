<?php
// app/views/admin/quiz_grading.php
?>
<div class="container mx-auto p-4">
  <h2 class="text-xl font-bold mb-2">Quiz Grading</h2>
  <table class="min-w-full bg-white border">
    <thead>
      <tr><th>Student</th><th>Question</th><th>Answer</th><th>Correct?</th><th>Feedback</th><th>Action</th></tr>
    </thead>
    <tbody>
      <?php foreach ($answers as $a): ?>
      <tr>
        <td><?= htmlspecialchars($a['student_name']) ?></td>
        <td><?= htmlspecialchars($a['question_text']) ?></td>
        <td><?= htmlspecialchars($a['answer']) ?></td>
        <td><?= $a['is_correct'] ? 'Yes' : 'No' ?></td>
        <td><?= $a['feedback'] ?></td>
        <td>
          <form method="POST" action="/admin/quiz_grade.php">
            <input type="hidden" name="answer_id" value="<?= $a['id'] ?>">
            <select name="is_correct">
              <option value="1">Correct</option>
              <option value="0">Incorrect</option>
            </select>
            <input type="text" name="feedback" placeholder="Feedback" class="border px-2">
            <button type="submit" class="bg-green-600 text-white px-2 py-1 rounded">Submit</button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
