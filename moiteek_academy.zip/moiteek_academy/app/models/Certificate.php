<?php
// app/models/Certificate.php
class Certificate extends Model {
    public static function create($data) {
        $sql = "INSERT INTO certificates (student_id, course_id, certificate_code, grade) VALUES (?, ?, ?, ?)";
        return self::insert($sql, [$data['student_id'], $data['course_id'], $data['certificate_code'], $data['grade']]);
    }
    public static function findByCode($code) {
        $sql = "SELECT * FROM certificates WHERE certificate_code = ? AND revoked = 0";
        return self::fetchOne($sql, [$code]);
    }
    public static function reissue($certId) {
        $sql = "UPDATE certificates SET reissued_at = NOW() WHERE id = ?";
        return self::update($sql, [$certId]);
    }
    public static function revoke($certId, $reason) {
        $sql = "UPDATE certificates SET revoked = 1, revoked_reason = ? WHERE id = ?";
        return self::update($sql, [$reason, $certId]);
    }
}
