<?php
// app/views/admin/certificate_admin.php
?>
<div class="container mx-auto p-4">
  <h2 class="text-xl font-bold mb-2">Certificate Management</h2>
  <table class="min-w-full bg-white border">
    <thead>
      <tr><th>Student</th><th>Course</th><th>Code</th><th>Date</th><th>Revoked</th><th>Action</th></tr>
    </thead>
    <tbody>
      <?php foreach ($certificates as $c): ?>
      <tr>
        <td><?= htmlspecialchars($c['student_name']) ?></td>
        <td><?= htmlspecialchars($c['course_title']) ?></td>
        <td><?= $c['certificate_code'] ?></td>
        <td><?= $c['issue_date'] ?></td>
        <td><?= $c['revoked'] ? 'Yes' : 'No' ?></td>
        <td>
          <?php if (!$c['revoked']): ?>
            <form method="POST" action="/admin/certificate_revoke.php">
              <input type="hidden" name="cert_id" value="<?= $c['id'] ?>">
              <input type="text" name="reason" placeholder="Reason" class="border px-2">
              <button type="submit" class="bg-red-600 text-white px-2 py-1 rounded">Revoke</button>
            </form>
            <form method="POST" action="/admin/certificate_reissue.php">
              <input type="hidden" name="cert_id" value="<?= $c['id'] ?>">
              <button type="submit" class="bg-green-600 text-white px-2 py-1 rounded">Reissue</button>
            </form>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
