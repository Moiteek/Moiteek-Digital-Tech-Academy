# PAYMENT_QUICKSTART.md - Get Payment System Running in 5 Minutes

Quick setup guide to activate the payment system immediately.

---

## ⚡ **5-Minute Setup**

### **Step 1: Update Database (1 minute)**

Run these SQL commands in phpMyAdmin or MySQL client:

```sql
-- Add new payment tables
SOURCE /path/to/moiteek_academy/sql/database.sql;

-- Or manually create if errors:

-- payments table
CREATE TABLE IF NOT EXISTS payments(
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'USD',
    payment_method ENUM('bank_transfer', 'mobile_money', 'paystack', 'flutterwave', 'other'),
    reference_number VARCHAR(100) UNIQUE,
    proof_file_path VARCHAR(255),
    proof_file_type VARCHAR(50),
    payment_date_submitted TIMESTAMP NOT NULL,
    status ENUM('pending', 'approved', 'rejected', 'cancellation_requested') DEFAULT 'pending',
    approval_notes TEXT,
    rejection_reason TEXT,
    approved_by INT,
    approved_at TIMESTAMP NULL,
    transaction_id VARCHAR(255),
    external_api_response LONGTEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    FOREIGN KEY (approved_by) REFERENCES admins(id) ON SET NULL,
    INDEX idx_student_id (student_id),
    INDEX idx_course_id (course_id),
    INDEX idx_status (status),
    INDEX idx_reference (reference_number)
);
```

Verify:
```sql
SHOW TABLES;  -- Should see: payments, payment_integrations, payment_transactions
DESCRIBE payments;  -- Check columns created
```

---

### **Step 2: Upload Files (2 minutes)**

1. **Delete old:** `/admin/payments.php` (old version)
2. **Upload new files:**
   - `/student/upload-payment.php` (NEW)
   - `/admin/payments.php` (UPDATED)
   - `/includes/Auth.php` (UPDATED)
   - `/includes/Email.php` (UPDATED)

3. **Create upload directory:**
   ```bash
   # Windows (PowerShell)
   mkdir c:\xampp\htdocs\moiteek_academy\uploads\payment_proofs

   # Linux/Mac
   mkdir -p /var/www/moiteek_academy/uploads/payment_proofs
   chmod 755 /var/www/moiteek_academy/uploads/payment_proofs
   ```

---

### **Step 3: Configure Email (1 minute)**

Test email sending. Edit `/includes/Email.php`:

```php
// Line ~15
private static $fromEmail = 'noreply@yourdomain.com';
private static $fromName = 'Moiteek Academy';

// For Gmail (optional):
// Configure SMTP in config/db.php if needed
```

Current setup uses PHP's `mail()` function. If not sending:
- Check server mail logs
- Verify /etc/ssmtp/ssmtp.conf on Linux
- Use PHPMailer for better reliability

---

### **Step 4: Test It (1 minute)**

**As Student:**
1. Login to `/student/dashboard.php`
2. Find a course
3. Click "Upload Payment" (URL: `/student/upload-payment.php?course_id=1`)
4. Fill form with test data
5. Upload any image file
6. Submit

**As Admin:**
1. Login to `/admin/dashboard.php`
2. Click "Payments" (or go to `/admin/payments.php`)
3. See payment statistics
4. Find pending payment
5. Click "Review"
6. Click "Approve"
7. Check student's email (may arrive as spam)
8. Student can now login with generated credentials!

---

## 🎯 **Quick Reference**

### **Student URL:**
```
/student/upload-payment.php?course_id=1
/student/upload-payment.php?course_id=2
(etc for each course)
```

### **Admin URL:**
```
/admin/payments.php?status=pending    (default)
/admin/payments.php?status=approved
/admin/payments.php?status=rejected
```

### **Generated Credentials Example:**
```
Username: john_doe_3
Password: M7$kL4@pQ9wR2x
(Automatically generated on approval)
```

---

## ✅ **Verification Checklist**

- [ ] Database tables created
- [ ] Upload directory exists
- [ ] File permissions set (755)
- [ ] New files uploaded
- [ ] Student can upload proof
- [ ] Admin sees pending payment
- [ ] Admin can approve payment
- [ ] Student received email
- [ ] Student can login with credentials

---

## 🐛 **Troubleshooting**

### **"File upload directory not writable"**
```bash
# Fix permissions
chmod 755 uploads/payment_proofs/
chmod 777 uploads/payment_proofs/  # If still failing
```

### **"Payment not appearing in admin"**
```sql
-- Check table exists
SHOW TABLES LIKE 'payments';

-- Check record was inserted
SELECT * FROM payments WHERE student_id = 1;

-- Check status
SELECT status, COUNT(*) FROM payments GROUP BY status;
```

### **"Email not sending"**
```php
// Test email in PHP
mail('test@example.com', 'Test', 'Hello');

// Check system logs
tail -f /var/log/mail.log  // Linux
Get-EventLog -LogName Application -Newest 10  // Windows
```

### **"Cannot approve payment"**
```sql
-- Verify admin logged in as admin
SELECT * FROM admins WHERE email = 'admin@email.com';

-- Check Auth::isAdminLoggedIn() working
-- Look at session cookies in browser DevTools
```

---

## 🔧 **Manual Steps if Needed**

### **Manually Create payments Table:**
```sql
USE moiteek_academy;

CREATE TABLE payments(
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    reference_number VARCHAR(100) UNIQUE,
    proof_file_path VARCHAR(255),
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    approved_by INT,
    approved_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id),
    FOREIGN KEY (course_id) REFERENCES courses(id),
    FOREIGN KEY (approved_by) REFERENCES admins(id)
);
```

### **Manually Create Upload Directory:**
```bash
# Option 1: Command line
mkdir -p c:/xampp/htdocs/moiteek_academy/uploads/payment_proofs/

# Option 2: In PHP (one-time)
<?php
if (!is_dir('uploads/payment_proofs')) {
    mkdir('uploads/payment_proofs', 0755, true);
}
?>
```

---

## 📱 **Access Points**

### **For Students:**
- **Course Page:** Add button to `/student/upload-payment.php?course_id={id}`
- **Dashboard:** Add "Upload Payment Proof" card
- **Email:** Approval email has direct login link

### **For Admins:**
- **Dashboard:** Add "Payments" card linking to `/admin/payments.php`
- **Sidebar:** Add "Payments" menu item
- **Statistics:** Show pending/approved/revenue

---

## 💡 **Pro Tips**

1. **Test Email First:**
   ```php
   // Add to any page to test
   Email::send('your@email.com', 'Test', 'This is a test');
   ```

2. **View Payment Details:**
   ```php
   // In phpmyadmin, run:
   SELECT * FROM payments 
   JOIN students ON payments.student_id = students.id 
   JOIN courses ON payments.course_id = courses.id
   ORDER BY payments.created_at DESC;
   ```

3. **Check Generated Credentials:**
   ```php
   // Updated student records
   SELECT id, email, username, status FROM students 
   WHERE username IS NOT NULL 
   ORDER BY updated_at DESC LIMIT 10;
   ```

4. **View Admin Actions:**
   ```php
   // See who approved what
   SELECT p.id, s.fullname, c.title, a.fullname as approved_by, p.approved_at
   FROM payments p
   JOIN students s ON p.student_id = s.id
   JOIN courses c ON p.course_id = c.id
   LEFT JOIN admins a ON p.approved_by = a.id
   WHERE p.status = 'approved'
   ORDER BY p.approved_at DESC;
   ```

---

## 🎓 **Full Documentation**

For detailed information, see:

1. **PAYMENT_SYSTEM.md** - Complete system documentation
2. **PAYMENT_IMPLEMENTATION_SUMMARY.md** - What was implemented
3. **DATABASE_MIGRATION.md** - Full database setup
4. **DEVELOPER_GUIDE.md** - Code examples
5. **SECURITY.md** - Security features

---

## 🚀 **You're Ready!**

The payment system is now active. Students can upload payment proofs, admins can review and approve them, and credentials are automatically generated and sent!

**Next:** Link the system in your course pages and notify users.

**Questions?** Check the full documentation files above.

---

**Setup Time:** ~5 minutes  
**Status:** Ready ✅
