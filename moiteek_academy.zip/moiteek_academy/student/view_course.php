// Fetch quizzes for current lesson
$quizzes = [];
if ($current_lesson) {
    $stmt = $pdo->prepare('SELECT * FROM quizzes WHERE lesson_id = ?');
    $stmt->execute([$current_lesson['id']]);
    $quizzes = $stmt->fetchAll();
}

$quiz_feedback = '';
$quiz_correct = false;
if ($current_lesson && $quizzes && isset($_POST['quiz_submit'])) {
    $all_correct = true;
    foreach ($quizzes as $q) {
        $ans = $_POST['quiz_' . $q['id']] ?? '';
        if (strtoupper($ans) !== strtoupper($q['correct_option'])) {
            $all_correct = false;
            break;
        }
    }
    if ($all_correct) {
        $quiz_feedback = '<div class="mb-4 p-3 bg-green-100 text-green-800 rounded">Correct! You can now proceed.</div>';
        $quiz_correct = true;
    } else {
        $quiz_feedback = '<div class="mb-4 p-3 bg-red-100 text-red-800 rounded">Incorrect, please try again.</div>';
    }
}
<?php
require_once __DIR__ . '/../includes/bootstrap.php';

// Get course_id and lesson_id from URL
$course_id = isset($_GET['course_id']) ? (int)$_GET['course_id'] : 0;
$lesson_id = isset($_GET['lesson_id']) ? (int)$_GET['lesson_id'] : 0;

// Check student session
if (!isset($_SESSION['student_id'])) {
    header('Location: ../auth/login.php');
    exit;
}
$student_id = $_SESSION['student_id'];

// Security: Verify enrollment
$stmt = $pdo->prepare('SELECT id FROM enrollments WHERE student_id = ? AND course_id = ? LIMIT 1');
$stmt->execute([$student_id, $course_id]);
if (!$stmt->fetch()) {
    header('Location: dashboard.php');
    exit;
}

// Fetch course info
$stmt = $pdo->prepare('SELECT title FROM courses WHERE id = ?');
$stmt->execute([$course_id]);
$course = $stmt->fetch();
if (!$course) {
    header('Location: dashboard.php');
    exit;
}

// Fetch modules and lessons
$stmt = $pdo->prepare('SELECT m.id as module_id, m.title as module_title, l.id as lesson_id, l.title as lesson_title, l.video_url
    FROM modules m
    LEFT JOIN lessons l ON l.module_id = m.id
    WHERE m.course_id = ?
    ORDER BY m.position, l.position');
$stmt->execute([$course_id]);
$rows = $stmt->fetchAll();

// Organize modules/lessons
$modules = [];
$first_lesson_id = 0;
foreach ($rows as $row) {
    $mid = $row['module_id'];
    if (!isset($modules[$mid])) {
        $modules[$mid] = [
            'title' => $row['module_title'],
            'lessons' => []
        ];
    }
    if ($row['lesson_id']) {
        $modules[$mid]['lessons'][] = [
            'id' => $row['lesson_id'],
            'title' => $row['lesson_title'],
            'video_url' => $row['video_url']
        ];
        if (!$first_lesson_id) {
            $first_lesson_id = $row['lesson_id'];
        }
    }
}

// Determine current lesson
if (!$lesson_id && $first_lesson_id) {
    $lesson_id = $first_lesson_id;
}
$current_lesson = null;
foreach ($modules as $mod) {
    foreach ($mod['lessons'] as $lesson) {
        if ($lesson['id'] == $lesson_id) {
            $current_lesson = $lesson;
            break 2;
        }
    }
}

// Handle 'Mark as Completed'
$completed = false;
$course_completed = false;
$show_certificate = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $current_lesson) {
    $stmt = $pdo->prepare('INSERT IGNORE INTO lesson_progress (student_id, lesson_id, completed_at) VALUES (?, ?, NOW())');
    $stmt->execute([$student_id, $current_lesson['id']]);
    $completed = true;
    // Check if all lessons are completed
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM lessons l INNER JOIN modules m ON l.module_id = m.id WHERE m.course_id = ?');
    $stmt->execute([$course_id]);
    $total_lessons = $stmt->fetchColumn();
    $stmt = $pdo->prepare('SELECT COUNT(DISTINCT lesson_id) FROM lesson_progress lp INNER JOIN lessons l ON lp.lesson_id = l.id INNER JOIN modules m ON l.module_id = m.id WHERE lp.student_id = ? AND m.course_id = ?');
    $stmt->execute([$student_id, $course_id]);
    $completed_lessons = $stmt->fetchColumn();
    if ($total_lessons > 0 && $completed_lessons == $total_lessons) {
        // Generate unique certificate ID
        function generateCertificateId($pdo) {
            do {
                $id = 'MTK-' . strtoupper(bin2hex(random_bytes(2))) . '-' . rand(10,99);
                $stmt = $pdo->prepare('SELECT 1 FROM enrollments WHERE certificate_id = ?');
                $stmt->execute([$id]);
            } while ($stmt->fetch());
            return $id;
        }
        $cert_id = generateCertificateId($pdo);
        $stmt = $pdo->prepare('UPDATE enrollments SET status = "completed", completed_at = CURRENT_TIMESTAMP, certificate_id = ? WHERE student_id = ? AND course_id = ?');
        $stmt->execute([$cert_id, $student_id, $course_id]);
        $_SESSION['success_message'] = 'Congratulations! You have finished this course.';
        $course_completed = true;
        $show_certificate = true;
    }
}
// Check if already completed
if ($current_lesson) {
    $stmt = $pdo->prepare('SELECT id FROM lesson_progress WHERE student_id = ? AND lesson_id = ?');
    $stmt->execute([$student_id, $current_lesson['id']]);
    if ($stmt->fetch()) {
        $completed = true;
    }
}
// Check if course is already completed
$stmt = $pdo->prepare('SELECT status FROM enrollments WHERE student_id = ? AND course_id = ?');
$stmt->execute([$student_id, $course_id]);
$enrollment = $stmt->fetch();
if ($enrollment && $enrollment['status'] === 'completed') {
    $course_completed = true;
    $show_certificate = true;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($course['title']) ?> - Classroom</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        .sidebar { width: 280px; }
        .active-lesson { background: #e0f2fe; }
    </style>
</head>
<body class="bg-gray-100">
<div class="flex min-h-screen">
    <!-- Sidebar -->
    <div class="sidebar bg-white shadow-lg p-6">
        <h2 class="text-xl font-bold mb-4 text-blue-700">Modules & Lessons</h2>
        <?php foreach ($modules as $mid => $mod): ?>
            <div class="mb-3">
                <div class="font-semibold text-blue-900 mb-1"><?= htmlspecialchars($mod['title']) ?></div>
                <ul>
                    <?php foreach ($mod['lessons'] as $lesson): ?>
                        <li class="mb-1 <?php if ($lesson['id'] == $lesson_id) echo 'active-lesson'; ?>">
                            <a href="view_course.php?course_id=<?= $course_id ?>&lesson_id=<?= $lesson['id'] ?>" class="block px-2 py-1 rounded <?php if ($lesson['id'] == $lesson_id) echo 'font-bold text-blue-700'; ?>">
                                <?= htmlspecialchars($lesson['title']) ?>
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endforeach; ?>
        <a href="dashboard.php" class="block mt-8 text-blue-600 hover:underline">&larr; Back to Dashboard</a>
    </div>
    <!-- Main Content -->
    <div class="flex-1 p-10">
        <h1 class="text-2xl font-bold mb-6 text-blue-800">Classroom: <?= htmlspecialchars($course['title']) ?></h1>
        <?php if ($course_completed): ?>
            <div class="mb-8 p-6 bg-green-100 text-green-900 rounded shadow text-center">
                <h2 class="text-2xl font-bold mb-2">Congratulations! You have finished this course.</h2>
                <a href="generate_certificate.php?course_id=<?= $course_id ?>" class="inline-block mt-4 bg-blue-700 text-white px-6 py-3 rounded hover:bg-blue-800 font-semibold">Download Certificate</a>
            </div>
        <?php endif; ?>
        <?php if ($current_lesson): ?>
            <div class="mb-6">
                <h2 class="text-xl font-semibold mb-2 text-blue-700">Lesson: <?= htmlspecialchars($current_lesson['title']) ?></h2>
                <?php if ($current_lesson['video_url']): ?>
                    <div class="mb-4">
                        <iframe width="720" height="405" src="<?= htmlspecialchars($current_lesson['video_url']) ?>" frameborder="0" allowfullscreen class="rounded shadow"></iframe>
                    </div>
                <?php endif; ?>
                <?php if ($quizzes): ?>
                    <form method="post" class="mb-4">
                        <h3 class="text-lg font-bold mb-2 text-purple-700">Quiz</h3>
                        <?php foreach ($quizzes as $q): ?>
                            <div class="mb-3">
                                <div class="font-semibold mb-1"><?= htmlspecialchars($q['question']) ?></div>
                                <div class="space-y-1">
                                    <label class="block"><input type="radio" name="quiz_<?= $q['id'] ?>" value="A" required> <?= htmlspecialchars($q['option_a']) ?></label>
                                    <label class="block"><input type="radio" name="quiz_<?= $q['id'] ?>" value="B"> <?= htmlspecialchars($q['option_b']) ?></label>
                                    <label class="block"><input type="radio" name="quiz_<?= $q['id'] ?>" value="C"> <?= htmlspecialchars($q['option_c']) ?></label>
                                    <label class="block"><input type="radio" name="quiz_<?= $q['id'] ?>" value="D"> <?= htmlspecialchars($q['option_d']) ?></label>
                                </div>
                            </div>
                        <?php endforeach; ?>
                        <button type="submit" name="quiz_submit" class="bg-blue-600 text-white px-4 py-2 rounded">Submit Answers</button>
                    </form>
                    <?= $quiz_feedback ?>
                <?php endif; ?>
                <?php if (!$course_completed && (!$quizzes || $quiz_correct || $completed)): ?>
                <form method="post">
                    <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded hover:bg-green-700" <?php if ($completed) echo 'disabled style=\"opacity:.6;cursor:not-allowed;\"'; ?>>
                        <?= $completed ? 'Completed' : 'Mark as Completed' ?>
                    </button>
                </form>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <p class="text-gray-600">No lesson selected or available.</p>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
