<?php
// app/models/Enrollment.php
class Enrollment extends Model {
    public static function create($data) {
        $sql = "INSERT INTO enrollments (student_id, course_id, status) VALUES (?, ?, ?)";
        return self::insert($sql, [$data['student_id'], $data['course_id'], $data['status']]);
    }
    public static function updateStatus($enrollmentId, $status, $reason = null) {
        $sql = "UPDATE enrollments SET status = ?, rejection_reason = ? WHERE id = ?";
        return self::update($sql, [$status, $reason, $enrollmentId]);
    }
}

// app/models/Payment.php
class Payment extends Model {
    public static function create($data) {
        $sql = "INSERT INTO payments (enrollment_id, student_id, course_id, amount, gateway, payment_status) VALUES (?, ?, ?, ?, ?, ?)";
        return self::insert($sql, [$data['enrollment_id'], $data['student_id'], $data['course_id'], $data['amount'], $data['gateway'], $data['payment_status']]);
    }
    public static function updateStatusFromWebhook($data) {
        // ...parse $data, update payment status, set webhook_verified...
    }
    public static function manualOverride($paymentId, $status, $reason) {
        $sql = "UPDATE payments SET payment_status = ?, manual_override = 1, override_reason = ? WHERE id = ?";
        return self::update($sql, [$status, $reason, $paymentId]);
    }
}

// app/models/PaymentTransaction.php
class PaymentTransaction extends Model {
    public static function logWebhook($data) {
        $sql = "INSERT INTO payment_transactions (payment_id, gateway, transaction_ref, status, amount, log_type, payload) VALUES (?, ?, ?, ?, ?, 'webhook', ?)";
        // ...extract fields from $data...
        // self::insert($sql, [...]);
    }
}
