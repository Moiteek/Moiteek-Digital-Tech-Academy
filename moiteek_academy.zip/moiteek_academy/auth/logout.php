<?php
require_once '../bootstrap.php';

// Check if user is logged in
if(!Auth::isAdminLoggedIn() && !Auth::isStudentLoggedIn()) {
    Response::redirect('../', 'Not logged in', 'info');
}

// Logout user
Auth::logout();

// Determine redirect URL based on user type
$redirect = '../';

Response::redirect($redirect, 'You have been logged out successfully', 'success');
?>