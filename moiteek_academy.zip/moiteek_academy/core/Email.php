<?php
// core/Email.php
class Email {
    private static $smtpConfig = [
        'host' => getenv('SMTP_HOST'),
        'port' => getenv('SMTP_PORT'),
        'username' => getenv('SMTP_USER'),
        'password' => getenv('SMTP_PASS'),
        'from' => getenv('SMTP_FROM'),
        'from_name' => getenv('SMTP_FROM_NAME'),
    ];
    public static function send($to, $subject, $body, $attachments = []) {
        $maxRetries = 3;
        $attempt = 0;
        $success = false;
        while ($attempt < $maxRetries && !$success) {
            try {
                $mail = new PHPMailer(true);
                $mail->isSMTP();
                $mail->Host = self::$smtpConfig['host'];
                $mail->Port = self::$smtpConfig['port'];
                $mail->SMTPAuth = true;
                $mail->Username = self::$smtpConfig['username'];
                $mail->Password = self::$smtpConfig['password'];
                $mail->setFrom(self::$smtpConfig['from'], self::$smtpConfig['from_name']);
                $mail->addAddress($to);
                $mail->Subject = $subject;
                $mail->Body = $body;
                foreach ($attachments as $file) {
                    $mail->addAttachment($file);
                }
                $mail->send();
                $success = true;
                error_log("Email sent to: $to | Subject: $subject");
            } catch (Exception $e) {
                error_log("Email error (attempt $attempt): " . $e->getMessage());
                $attempt++;
                sleep(2); // retry delay
            }
        }
        return $success;
    }
    // Notification templates
    public static function registrationConfirmation($to, $name) {
        $subject = "Welcome to Moiteek Academy";
        $body = "Hello $name,\n\nYour registration is confirmed.\n\nRegards,\nMoiteek Academy";
        return self::send($to, $subject, $body);
    }
    public static function enrollmentApproval($to, $course) {
        $subject = "Enrollment Approved";
        $body = "Congratulations! Your enrollment for $course has been approved.";
        return self::send($to, $subject, $body);
    }
    public static function paymentConfirmation($to, $amount, $course) {
        $subject = "Payment Received";
        $body = "Your payment of $amount for $course has been confirmed.";
        return self::send($to, $subject, $body);
    }
    public static function assignmentFeedback($to, $lesson, $feedback) {
        $subject = "Assignment Feedback";
        $body = "Feedback for your assignment in $lesson: $feedback";
        return self::send($to, $subject, $body);
    }
    public static function quizResults($to, $quiz, $score) {
        $subject = "Quiz Results";
        $body = "Your score for $quiz: $score";
        return self::send($to, $subject, $body);
    }
    public static function certificateIssued($to, $course, $code) {
        $subject = "Certificate Issued";
        $body = "Your certificate for $course has been issued. Verification code: $code";
        return self::send($to, $subject, $body);
    }
}
