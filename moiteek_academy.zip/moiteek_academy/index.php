
<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/Database.php';

// Fetch all courses
$stmt = $pdo->query('SELECT title, description, price, slug FROM courses ORDER BY id DESC');
$courses = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Moiteek Academy - Home</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-50">
    <?php include __DIR__ . '/includes/header.php'; ?>
    <div class="max-w-7xl mx-auto px-4 py-10">
        <h1 class="text-4xl font-bold text-center mb-10 text-blue-700">Welcome to Moiteek Academy</h1>
        <div class="row">
            <?php foreach ($courses as $course): ?>
                <div class="col-md-4 mb-4">
                    <div class="card h-100 shadow-sm">
                        <?php
                        $img = $course['image_url'] ?? $course['thumbnail'] ?? '';
                        $placeholder = 'https://images.unsplash.com/photo-1501504905252-473c47e087f8?auto=format&fit=crop&w=600&q=80';
                        $imgPath = (!empty($img) && file_exists(__DIR__ . '/' . $img)) ? $img : $placeholder;
                        ?>
                        <img src="<?= htmlspecialchars($imgPath) ?>"
                             class="card-img-top" alt="Course Image"
                             onerror="this.onerror=null;this.src='<?= $placeholder ?>';">
                        <div class="card-body d-flex flex-column">
                            <h2 class="card-title text-2xl font-semibold mb-2 text-blue-800"><?= htmlspecialchars($course['title']) ?></h2>
                            <p class="card-text text-gray-700 mb-4"><?= htmlspecialchars($course['description']) ?></p>
                        </div>
                        <div class="card-footer bg-white border-0 mt-auto d-flex justify-content-between align-items-center">
                            <span class="text-lg font-bold text-green-600">$<?= number_format($course['price'], 2) ?></span>
                            <a href="course_details.php?slug=<?= urlencode($course['slug']) ?>" class="btn btn-primary bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">View Details</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <?php if (empty($courses)): ?>
            <p class="text-center text-gray-500 mt-10">No courses available at the moment. Please check back soon!</p>
        <?php endif; ?>
    </div>
</body>
</html>
<?php require_once 'bootstrap.php'; 
require_once 'includes/seo_helper.php';
echo generateMetaTags('Moiteek Academy - Learn, Grow, Succeed', 'Join Moiteek Academy for professional courses and career growth.', '/assets/logo.png');

$courses = Database::getCourses();
$flash = Response::getFlashMessage();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= APP_NAME ?> - Learn Digital Skills That Pay</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .gradient-text {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .hero-gradient {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%);
        }
        .card-hover {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .card-hover:hover {
            transform: translateY(-8px);
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
        }
    </style>
</head>
<body class="bg-white">
    <!-- Navigation -->
    <nav class="sticky top-0 z-50 bg-white shadow-md">
        <div class="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
            <div class="flex items-center gap-2">
                <i class="fas fa-graduation-cap text-3xl text-blue-600"></i>
                <span class="font-bold text-xl text-gray-900"><?= APP_NAME ?></span>
            </div>
            <div class="hidden md:flex items-center gap-6">
                <a href="#courses" class="text-gray-700 hover:text-blue-600 font-semibold transition">Courses</a>
                <a href="#testimonials" class="text-gray-700 hover:text-blue-600 font-semibold transition">Testimonials</a>
                <a href="#about" class="text-gray-700 hover:text-blue-600 font-semibold transition">About</a>
            </div>
            <div class="flex items-center gap-3">
                <a href="auth/login.php" class="text-gray-700 hover:text-blue-600 font-semibold transition">
                    <i class="fas fa-sign-in-alt mr-1"></i>Login
                </a>
                <a href="courses.php" class="bg-gradient-to-r from-blue-600 to-purple-600 hover:shadow-lg text-white px-6 py-2 rounded-lg font-semibold transition">
                    Enroll Now
                </a>
            </div>
        </div>
    </nav>

    <!-- Flash Message -->
    <?php if($flash): ?>
        <div class="max-w-7xl mx-auto mt-4 px-4">
            <div class="p-4 rounded-lg bg-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-50 border border-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-200 flex items-center gap-3">
                <i class="fas fa-<?= $flash['type'] === 'error' ? 'exclamation-circle' : 'check-circle' ?> text-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-600"></i>
                <p class="text-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-700"><?= htmlspecialchars($flash['message']) ?></p>
            </div>
        </div>
    <?php endif; ?>

    <!-- Hero Section -->
    <section class="hero-gradient text-white py-24 md:py-32">
        <div class="max-w-7xl mx-auto px-4">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
                <div>
                    <h1 class="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6">
                        Learn Digital Skills That <span class="text-yellow-300">Pay</span>
                    </h1>
                    <p class="text-lg md:text-xl text-gray-100 mb-8 leading-relaxed">
                        Master in-demand digital skills with industry experts. From web development to UI/UX design, we've got courses for every skill level.
                    </p>
                    <div class="flex flex-col sm:flex-row gap-4">
                        <a href="courses.php" class="inline-flex items-center justify-center bg-white text-blue-600 hover:bg-gray-100 px-8 py-4 rounded-lg font-bold text-lg transition shadow-lg">
                            <i class="fas fa-play-circle mr-2"></i>Start Learning
                        </a>
                        <a href="#courses" class="inline-flex items-center justify-center border-2 border-white text-white hover:bg-white hover:text-blue-600 px-8 py-4 rounded-lg font-bold text-lg transition">
                            <i class="fas fa-arrow-down mr-2"></i>Explore Courses
                        </a>
                    </div>
                    <div class="mt-12 flex items-center gap-8 text-sm">
                        <div>
                            <p class="text-3xl font-bold text-yellow-300">50K+</p>
                            <p class="text-gray-100">Students</p>
                        </div>
                        <div>
                            <p class="text-3xl font-bold text-yellow-300"><?= count($courses) ?>+</p>
                            <p class="text-gray-100">Courses</p>
                        </div>
                        <div>
                            <p class="text-3xl font-bold text-yellow-300">4.8★</p>
                            <p class="text-gray-100">Rating</p>
                        </div>
                    </div>
                </div>
                <div class="hidden md:block">
                    <div class="relative">
                        <div class="absolute inset-0 bg-white opacity-10 rounded-3xl blur-3xl"></div>
                        <div class="relative bg-gradient-to-br from-white/20 to-white/5 rounded-3xl p-12 border border-white/20">
                            <i class="fas fa-laptop-code text-8xl text-white/30"></i>
                            <div class="mt-6 space-y-4">
                                <div class="h-3 bg-white/20 rounded w-3/4"></div>
                                <div class="h-3 bg-white/20 rounded w-full"></div>
                                <div class="h-3 bg-white/20 rounded w-5/6"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Features -->
    <section class="py-16 md:py-24 bg-gray-50">
        <div class="max-w-7xl mx-auto px-4">
            <div class="text-center mb-16">
                <h2 class="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Why Choose Us?</h2>
                <p class="text-gray-600 text-lg max-w-2xl mx-auto">Learn from industry experts with real-world experience and get certified</p>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div class="bg-white rounded-xl p-8 shadow-md hover:shadow-xl transition text-center">
                    <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-star text-2xl text-blue-600"></i>
                    </div>
                    <h3 class="text-xl font-bold text-gray-900 mb-3">Expert Instructors</h3>
                    <p class="text-gray-600">Learn from professionals with years of industry experience</p>
                </div>
                <div class="bg-white rounded-xl p-8 shadow-md hover:shadow-xl transition text-center">
                    <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-certificate text-2xl text-green-600"></i>
                    </div>
                    <h3 class="text-xl font-bold text-gray-900 mb-3">Certifications</h3>
                    <p class="text-gray-600">Get industry-recognized certificates upon completion</p>
                </div>
                <div class="bg-white rounded-xl p-8 shadow-md hover:shadow-xl transition text-center">
                    <div class="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-users text-2xl text-purple-600"></i>
                    </div>
                    <h3 class="text-xl font-bold text-gray-900 mb-3">Community</h3>
                    <p class="text-gray-600">Join a supportive community of learners worldwide</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Courses Section -->
    <section id="courses" class="py-16 md:py-24 bg-white">
        <div class="max-w-7xl mx-auto px-4">
            <div class="text-center mb-16">
                <h2 class="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Featured Courses</h2>
                <p class="text-gray-600 text-lg max-w-2xl mx-auto">Start your learning journey with our most popular courses</p>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <?php foreach($courses as $course): ?>
                    <div class="bg-white rounded-xl shadow-lg card-hover overflow-hidden border border-gray-100">
                        <!-- Course Thumbnail -->
                        <div class="h-40 bg-gradient-to-br from-blue-500 to-purple-600 relative overflow-hidden flex items-center justify-center">
                            <i class="fas fa-<?= count($courses) % 3 === 0 ? 'code' : (count($courses) % 3 === 1 ? 'palette' : 'database') ?> text-5xl text-white opacity-80"></i>
                            <?php $level = $course['level'] ?? 'beginner'; ?>
                            <?php if($level === 'beginner'): ?>
                                <span class="absolute top-3 right-3 bg-green-500 text-white px-3 py-1 rounded-full text-xs font-semibold">Beginner</span>
                            <?php elseif($level === 'intermediate'): ?>
                                <span class="absolute top-3 right-3 bg-yellow-500 text-white px-3 py-1 rounded-full text-xs font-semibold">Intermediate</span>
                            <?php else: ?>
                                <span class="absolute top-3 right-3 bg-red-500 text-white px-3 py-1 rounded-full text-xs font-semibold">Advanced</span>
                            <?php endif; ?>
                        </div>

                        <!-- Content -->
                        <div class="p-6">
                            <div class="flex items-center gap-2 mb-3">
                                <i class="fas fa-tag text-gray-400 text-sm"></i>
                                <span class="text-sm text-gray-600 font-semibold"><?= htmlspecialchars($course['category'] ?? 'N/A') ?></span>
                            </div>
                            <h3 class="text-xl font-bold text-gray-900 mb-3 line-clamp-2"><?= htmlspecialchars($course['title'] ?? 'Untitled') ?></h3>
                            <p class="text-gray-600 text-sm mb-4 line-clamp-2"><?= htmlspecialchars($course['description'] ?? 'N/A') ?></p>

                            <!-- Instructor & Info -->
                            <div class="flex items-center gap-3 mb-4 pb-4 border-b border-gray-200">
                                <div class="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                                    <i class="fas fa-user text-blue-600 text-xs"></i>
                                </div>
                                <div>
                                    <p class="text-xs text-gray-600"><?= htmlspecialchars($course['instructor_name'] ?? 'N/A') ?></p>
                                </div>
                            </div>

                            <!-- Stats -->
                            <div class="flex items-center justify-between mb-4 text-sm text-gray-600">
                                <span><i class="fas fa-clock mr-1"></i><?= htmlspecialchars($course['duration'] ?? 'N/A') ?></span>
                                <span><i class="fas fa-play-circle mr-1"></i><?= isset($course['total_modules']) ? $course['total_modules'] : 0 ?> modules</span>
                            </div>

                            <!-- Rating & Price -->
                            <div class="flex items-center justify-between">
                                <div class="flex items-center gap-1">
                                    <div class="text-yellow-400">
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star-half-alt"></i>
                                    </div>
                                    <span class="text-xs text-gray-600">(1.2K)</span>
                                </div>
                                <span class="text-2xl font-bold text-blue-600"><?= Helper::formatCurrency($course['price']) ?></span>
                            </div>
                        </div>

                        <!-- CTA -->
                        <div class="px-6 pb-6">
                            <a href="course_details.php?id=<?= $course['id'] ?>" class="w-full block text-center bg-gradient-to-r from-blue-600 to-purple-600 hover:shadow-lg text-white py-3 rounded-lg font-bold transition">
                                <i class="fas fa-arrow-right mr-2"></i>View Course
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <div class="text-center mt-12">
                <a href="courses.php" class="inline-block border-2 border-blue-600 text-blue-600 hover:bg-blue-50 px-8 py-3 rounded-lg font-bold transition">
                    View All Courses <i class="fas fa-arrow-right ml-2"></i>
                </a>
            </div>
        </div>
    </section>

    <!-- Testimonials Section -->
    <section id="testimonials" class="py-16 md:py-24 bg-gray-900 text-white">
        <div class="max-w-7xl mx-auto px-4">
            <div class="text-center mb-16">
                <h2 class="text-3xl md:text-4xl font-bold mb-4">What Students Say</h2>
                <p class="text-gray-400 text-lg">Join thousands of successful learners</p>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div class="bg-gray-800 rounded-xl p-8 border border-gray-700">
                    <div class="flex items-center gap-1 mb-4 text-yellow-400">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <p class="text-gray-300 mb-6 italic">"This course transformed my career. The instructors are knowledgeable and the content is structured perfectly for learners."</p>
                    <div class="flex items-center gap-3">
                        <div class="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center">
                            <i class="fas fa-user text-white"></i>
                        </div>
                        <div>
                            <p class="font-bold">Sarah Ahmed</p>
                            <p class="text-sm text-gray-400">Web Developer</p>
                        </div>
                    </div>
                </div>
                <div class="bg-gray-800 rounded-xl p-8 border border-gray-700">
                    <div class="flex items-center gap-1 mb-4 text-yellow-400">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <p class="text-gray-300 mb-6 italic">"Fantastic learning experience! The practical projects helped me build a real portfolio that got me hired."</p>
                    <div class="flex items-center gap-3">
                        <div class="w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center">
                            <i class="fas fa-user text-white"></i>
                        </div>
                        <div>
                            <p class="font-bold">Michael Chen</p>
                            <p class="text-sm text-gray-400">Full Stack Developer</p>
                        </div>
                    </div>
                </div>
                <div class="bg-gray-800 rounded-xl p-8 border border-gray-700">
                    <div class="flex items-center gap-1 mb-4 text-yellow-400">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <p class="text-gray-300 mb-6 italic">"Best investment in my education. The support team is amazing and the community is so helpful!"</p>
                    <div class="flex items-center gap-3">
                        <div class="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center">
                            <i class="fas fa-user text-white"></i>
                        </div>
                        <div>
                            <p class="font-bold">Emma Rodriguez</p>
                            <p class="text-sm text-gray-400">UI/UX Designer</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="py-16 md:py-24 bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <div class="max-w-4xl mx-auto px-4 text-center">
            <h2 class="text-3xl md:text-4xl font-bold mb-6">Ready to Get Started?</h2>
            <p class="text-lg md:text-xl text-gray-100 mb-8">Join thousands of students learning digital skills today</p>
            <a href="courses.php" class="inline-block bg-white text-blue-600 hover:bg-gray-100 px-10 py-4 rounded-lg font-bold text-lg transition shadow-lg">
                <i class="fas fa-play-circle mr-2"></i>Start Learning Now
            </a>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-gray-900 text-gray-400 py-12">
        <div class="max-w-7xl mx-auto px-4">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
                <div>
                    <div class="flex items-center gap-2 mb-4">
                        <i class="fas fa-graduation-cap text-2xl text-blue-400"></i>
                        <span class="font-bold text-white"><?= APP_NAME ?></span>
                    </div>
                    <p class="text-sm">Learn skills that matter, build your future.</p>
                </div>
                <div>
                    <h4 class="font-bold text-white mb-4">Platform</h4>
                    <ul class="space-y-2 text-sm">
                        <li><a href="/" class="hover:text-white transition">Home</a></li>
                        <li><a href="courses.php" class="hover:text-white transition">Courses</a></li>
                        <li><a href="auth/login.php" class="hover:text-white transition">Login</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-bold text-white mb-4">Support</h4>
                    <ul class="space-y-2 text-sm">
                        <li><a href="#" class="hover:text-white transition">Help Center</a></li>
                        <li><a href="#" class="hover:text-white transition">Contact Us</a></li>
                        <li><a href="#" class="hover:text-white transition">FAQ</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-bold text-white mb-4">Follow Us</h4>
                    <div class="flex gap-4">
                        <a href="#" class="text-gray-400 hover:text-blue-400 text-lg transition">
                            <i class="fab fa-facebook"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-blue-400 text-lg transition">
                            <i class="fab fa-twitter"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-blue-400 text-lg transition">
                            <i class="fab fa-linkedin"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-blue-400 text-lg transition">
                            <i class="fab fa-instagram"></i>
                        </a>
                    </div>
                </div>
            </div>
            <div class="border-t border-gray-800 pt-8 text-center text-sm">
                <p>&copy; 2026 <?= APP_NAME ?>. All rights reserved.</p>
            </div>
        </div>
    </footer>
</body>
</html>
