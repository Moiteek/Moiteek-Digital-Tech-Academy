<?php
header('Content-Type: application/xml');
require_once 'config/db.php';

$siteUrl = 'https://moiteek.com';
$stmt = $pdo->prepare("SELECT slug FROM courses WHERE is_published = 1");
$stmt->execute();
$courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "<?xml version='1.0' encoding='UTF-8'?>\n";
echo "<urlset xmlns='http://www.sitemaps.org/schemas/sitemap/0.9'>\n";
foreach ($courses as $course) {
    echo "  <url>\n";
    echo "    <loc>" . $siteUrl . "/course/" . htmlspecialchars($course['slug']) . "</loc>\n";
    echo "    <changefreq>weekly</changefreq>\n";
    echo "    <priority>0.8</priority>\n";
    echo "  </url>\n";
}
echo "</urlset>\n";
