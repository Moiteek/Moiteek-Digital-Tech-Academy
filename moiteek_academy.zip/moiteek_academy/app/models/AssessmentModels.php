<?php
// app/models/Assignment.php
class Assignment extends Model {
    public static function create($data) {
        $sql = "INSERT INTO assignments (lesson_id, student_id, file_path, file_type) VALUES (?, ?, ?, ?)";
        return self::insert($sql, [$data['lesson_id'], $data['student_id'], $data['file_path'], $data['file_type']]);
    }
    public static function grade($assignmentId, $grade, $feedback, $adminId) {
        $sql = "UPDATE assignments SET grade = ?, feedback = ?, graded_by = ?, graded_at = NOW() WHERE id = ?";
        return self::update($sql, [$grade, $feedback, $adminId, $assignmentId]);
    }
}

// app/models/QuizAttempt.php
class QuizAttempt extends Model {
    public static function create($quizId, $studentId) {
        $sql = "INSERT INTO quiz_attempts (quiz_id, student_id) VALUES (?, ?)";
        return self::insert($sql, [$quizId, $studentId]);
    }
    public static function calculateScore($attemptId) {
        $sql = "SELECT SUM(is_correct) as score FROM quiz_answers WHERE attempt_id = ?";
        $row = self::fetchOne($sql, [$attemptId]);
        return $row['score'];
    }
    public static function updateScore($attemptId, $score) {
        $sql = "UPDATE quiz_attempts SET score = ? WHERE id = ?";
        return self::update($sql, [$score, $attemptId]);
    }
}

// app/models/QuizAnswer.php
class QuizAnswer extends Model {
    public static function create($attemptId, $questionId, $answer, $isCorrect) {
        $sql = "INSERT INTO quiz_answers (attempt_id, question_id, answer, is_correct) VALUES (?, ?, ?, ?)";
        return self::insert($sql, [$attemptId, $questionId, $answer, $isCorrect]);
    }
    public static function grade($answerId, $isCorrect, $feedback, $adminId) {
        $sql = "UPDATE quiz_answers SET is_correct = ?, feedback = ?, graded_by = ?, graded_at = NOW() WHERE id = ?";
        return self::update($sql, [$isCorrect, $feedback, $adminId, $answerId]);
    }
}
