<?php
/**
 * CSRF Protection Helper Class
 * Handles CSRF token generation, validation, and management
 * 
 * Usage:
 * In forms: <?php echo CSRF::generateTokenField(); ?>
 * Validation: CSRF::validateToken($_POST['csrf_token']);
 */

class CSRF {
    const TOKEN_FIELD_NAME = 'csrf_token';
    const TOKEN_SESSION_KEY = 'csrf_tokens';
    const TOKEN_TTL = 3600;  // 1 hour
    const MAX_TOKENS = 10;   // Max stored tokens per session

    /**
     * Initialize CSRF protection
     * Call this in bootstrap.php
     */
    public static function init() {
        if (!isset($_SESSION[self::TOKEN_SESSION_KEY])) {
            $_SESSION[self::TOKEN_SESSION_KEY] = [];
        }
    }

    /**
     * Generate a new CSRF token
     * 
     * @return string Generated token
     */
    public static function generateToken() {
        self::init();
        
        // Generate random token
        $token = bin2hex(random_bytes(32));
        $timestamp = time();
        
        // Store token with timestamp
        $_SESSION[self::TOKEN_SESSION_KEY][$token] = $timestamp;
        
        // Clean old tokens
        self::cleanOldTokens();
        
        // Limit stored tokens
        if (count($_SESSION[self::TOKEN_SESSION_KEY]) > self::MAX_TOKENS) {
            array_shift($_SESSION[self::TOKEN_SESSION_KEY]);
        }
        
        return $token;
    }

    /**
     * Generate HTML field for CSRF token in forms
     * 
     * @return string HTML input field
     */
    public static function generateTokenField() {
        $token = self::generateToken();
        return '<input type="hidden" name="' . self::TOKEN_FIELD_NAME . '" value="' . htmlspecialchars($token) . '">';
    }

    /**
     * Validate CSRF token
     * 
     * @param string $token Token to validate (usually from POST)
     * @return bool True if valid, false otherwise
     */
    public static function validateToken($token) {
        self::init();
        
        // Check if token exists
        if (!isset($_SESSION[self::TOKEN_SESSION_KEY][$token])) {
            error_log("CSRF: Invalid token provided");
            return false;
        }
        
        // Check if token has expired
        $timestamp = $_SESSION[self::TOKEN_SESSION_KEY][$token];
        if (time() - $timestamp > self::TOKEN_TTL) {
            unset($_SESSION[self::TOKEN_SESSION_KEY][$token]);
            error_log("CSRF: Token expired");
            return false;
        }
        
        // Token is valid - remove it (one-time use)
        unset($_SESSION[self::TOKEN_SESSION_KEY][$token]);
        
        return true;
    }

    /**
     * Get CSRF token from POST/GET
     * 
     * @return string|null Token if exists, null otherwise
     */
    public static function getTokenFromRequest() {
        if (isset($_POST[self::TOKEN_FIELD_NAME])) {
            return $_POST[self::TOKEN_FIELD_NAME];
        }
        if (isset($_GET[self::TOKEN_FIELD_NAME])) {
            return $_GET[self::TOKEN_FIELD_NAME];
        }
        return null;
    }

    /**
     * Validate request CSRF token
     * Validates token from POST/GET and returns result
     * 
     * @return bool True if valid
     */
    public static function validateRequest() {
        $token = self::getTokenFromRequest();
        
        if (!$token) {
            error_log("CSRF: No token in request");
            return false;
        }
        
        return self::validateToken($token);
    }

    /**
     * Clean expired tokens from session
     */
    private static function cleanOldTokens() {
        self::init();
        
        $currentTime = time();
        foreach ($_SESSION[self::TOKEN_SESSION_KEY] as $token => $timestamp) {
            if ($currentTime - $timestamp > self::TOKEN_TTL) {
                unset($_SESSION[self::TOKEN_SESSION_KEY][$token]);
            }
        }
    }

    /**
     * Clear all CSRF tokens from session
     * (Usually on logout)
     */
    public static function clearTokens() {
        $_SESSION[self::TOKEN_SESSION_KEY] = [];
    }

    /**
     * Get token count (for debugging)
     */
    public static function getTokenCount() {
        self::init();
        return count($_SESSION[self::TOKEN_SESSION_KEY]);
    }
}
?>
