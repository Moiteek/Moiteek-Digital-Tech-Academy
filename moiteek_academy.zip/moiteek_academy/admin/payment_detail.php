<?php
require_once '../bootstrap.php';

if(!Auth::isAdminLoggedIn()) {
    Response::redirect('../admin/login.php', 'Please login', 'error');
}

$enrollment_id = Validator::sanitizeInput($_GET['id'] ?? '');
if(!$enrollment_id || !is_numeric($enrollment_id)) {
    Response::redirect('payments.php', 'Invalid payment', 'error');
}

$stmt = $pdo->prepare("
    SELECT e.*, s.fullname, s.email, s.phone, c.title, c.price
    FROM enrollments e
    JOIN students s ON e.student_id = s.id
    JOIN courses c ON e.course_id = c.id
    WHERE e.id = ?
");
$stmt->execute([$enrollment_id]);
$payment = $stmt->fetch();

if(!$payment) {
    Response::redirect('payments.php', 'Payment not found', 'error');
}

$flash = Response::getFlashMessage();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Details - <?= APP_NAME ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <nav class="bg-white shadow-lg sticky top-0 z-50">
        <div class="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
            <a href="payments.php" class="text-blue-600 hover:text-blue-700 font-semibold">
                <i class="fas fa-arrow-left mr-2"></i>Back to Payments
            </a>
            <a href="../auth/logout.php" class="p-2 text-gray-600 hover:bg-red-50 rounded-lg">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </nav>

    <div class="max-w-4xl mx-auto p-8">
        <!-- Flash -->
        <?php if($flash): ?>
            <div class="mb-6 p-4 rounded-lg bg-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-50 border border-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-200 flex items-center gap-3">
                <i class="fas fa-<?= $flash['type'] === 'error' ? 'exclamation-circle' : 'check-circle' ?> text-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-600"></i>
                <p class="text-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-700"><?= htmlspecialchars($flash['message']) ?></p>
            </div>
        <?php endif; ?>

        <!-- Main Card -->
        <div class="bg-white rounded-xl shadow-lg overflow-hidden">
            <!-- Header -->
            <div class="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-8">
                <h1 class="text-3xl font-bold mb-2">Payment Details</h1>
                <p class="text-blue-100">Transaction ID: <?= Helper::generateReference('TXN') ?></p>
            </div>

            <!-- Content -->
            <div class="p-8 space-y-8">
                <!-- Status -->
                <div class="p-6 rounded-lg bg-<?= $payment['payment_status'] === 'confirmed' ? 'green' : ($payment['payment_status'] === 'pending' ? 'yellow' : 'red') ?>-50 border border-<?= $payment['payment_status'] === 'confirmed' ? 'green' : ($payment['payment_status'] === 'pending' ? 'yellow' : 'red') ?>-200">
                    <div class="flex items-center gap-3">
                        <i class="fas fa-<?= $payment['payment_status'] === 'confirmed' ? 'check-circle' : ($payment['payment_status'] === 'pending' ? 'clock' : 'times-circle') ?> text-2xl text-<?= $payment['payment_status'] === 'confirmed' ? 'green' : ($payment['payment_status'] === 'pending' ? 'yellow' : 'red') ?>-600"></i>
                        <div>
                            <p class="text-sm text-<?= $payment['payment_status'] === 'confirmed' ? 'green' : ($payment['payment_status'] === 'pending' ? 'yellow' : 'red') ?>-700">Payment Status</p>
                            <p class="text-2xl font-bold text-<?= $payment['payment_status'] === 'confirmed' ? 'green' : ($payment['payment_status'] === 'pending' ? 'yellow' : 'red') ?>-900"><?= ucfirst($payment['payment_status']) ?></p>
                        </div>
                    </div>
                </div>

                <!-- Grid -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <!-- Student Info -->
                    <div>
                        <h3 class="text-lg font-bold text-gray-900 mb-4">Student Information</h3>
                        <div class="space-y-4">
                            <div>
                                <p class="text-sm text-gray-600">Full Name</p>
                                <p class="font-semibold text-gray-900"><?= htmlspecialchars($payment['fullname']) ?></p>
                            </div>
                            <div>
                                <p class="text-sm text-gray-600">Email</p>
                                <p class="font-semibold text-gray-900"><?= htmlspecialchars($payment['email']) ?></p>
                            </div>
                            <div>
                                <p class="text-sm text-gray-600">Phone</p>
                                <p class="font-semibold text-gray-900"><?= htmlspecialchars($payment['phone']) ?></p>
                            </div>
                        </div>
                    </div>

                    <!-- Course Info -->
                    <div>
                        <h3 class="text-lg font-bold text-gray-900 mb-4">Course Information</h3>
                        <div class="space-y-4">
                            <div>
                                <p class="text-sm text-gray-600">Course Name</p>
                                <p class="font-semibold text-gray-900"><?= htmlspecialchars($payment['title']) ?></p>
                            </div>
                            <div>
                                <p class="text-sm text-gray-600">Amount</p>
                                <p class="font-bold text-2xl text-blue-600"><?= Helper::formatCurrency($payment['price']) ?></p>
                            </div>
                            <div>
                                <p class="text-sm text-gray-600">Enrollment Date</p>
                                <p class="font-semibold text-gray-900"><?= Helper::formatDate($payment['enrollment_date']) ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Action Buttons -->
                <?php if($payment['payment_status'] === 'pending'): ?>
                    <div class="pt-6 border-t border-gray-200 flex gap-4">
                        <form method="POST" action="payments.php" style="display: inline;">
                            <input type="hidden" name="enrollment_id" value="<?= $enrollment_id ?>">
                            <input type="hidden" name="action" value="confirm">
                            <button type="submit" class="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-bold transition flex items-center gap-2">
                                <i class="fas fa-check-circle"></i>Confirm Payment
                            </button>
                        </form>
                        <a href="payments.php" class="bg-gray-300 hover:bg-gray-400 text-gray-800 px-6 py-3 rounded-lg font-bold transition flex items-center gap-2">
                            <i class="fas fa-times"></i>Cancel
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>