

<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/Database.php';

// Redirect if already logged in as student
if (isset($_SESSION['student_id'])) {
    header('Location: ../student/dashboard.php');
    exit;
}

$course_id = isset($_GET['course_id']) ? (int)$_GET['course_id'] : 0;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $course_id = isset($_POST['course_id']) ? (int)$_POST['course_id'] : 0;
}

// Validate course_id
if(!$course_id || !is_numeric($course_id)) {
    Response::redirect('../courses.php', 'Invalid course', 'error');
}

// Get course details
$course = Database::getCourseById($course_id);
if(!$course) {
    Response::redirect('../courses.php', 'Course not found', 'error');
}

$errors = [];
$success = false;

// Handle registration form submission
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    Validator::clearErrors();

    $fullname = Validator::sanitizeInput($_POST['fullname'] ?? '');
    $email = Validator::sanitizeInput($_POST['email'] ?? '');
    $phone = Validator::sanitizeInput($_POST['phone'] ?? '');
    $username = Validator::sanitizeInput($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $password_confirm = $_POST['password_confirm'] ?? '';

    // Validate inputs
    $valid = true;
    
    if(!Validator::validateFullName($fullname)) {
        $valid = false;
    }
    if(!Validator::validateEmail($email)) {
        $valid = false;
    }
    if(Database::emailExists($email, 'students')) {
        Validator::$errors['email'] = 'Email already registered';
        $valid = false;
    }
    if(!Validator::validatePhone($phone)) {
        $valid = false;
    }
    if(!Validator::validateUsername($username)) {
        $valid = false;
    }
    if(Database::usernameExists($username)) {
        Validator::$errors['username'] = 'Username already taken';
        $valid = false;
    }
    if(!Validator::validatePassword($password)) {
        $valid = false;
    }
    if($password !== $password_confirm) {
        Validator::$errors['password_confirm'] = 'Passwords do not match';
        $valid = false;
    }

    // Handle payment proof file
    $payment_proof = null;
    if(isset($_FILES['payment_proof']) && $_FILES['payment_proof']['name']) {
        $file_result = FileManager::uploadFile($_FILES['payment_proof'], 'payments/');
        if(!$file_result['success']) {
            Validator::$errors['payment_proof'] = $file_result['message'];
            $valid = false;
        } else {
            $payment_proof = $file_result['filename'];
        }
    } else {
        Validator::$errors['payment_proof'] = 'Payment proof is required';
        $valid = false;
    }

    if($valid) {
        try {
            // Insert student
            $stmt = $pdo->prepare("
                INSERT INTO students 
                (fullname, email, phone, username, password, is_active) 
                VALUES (?, ?, ?, ?, ?, 0)
            ");
            $stmt->execute([
                $fullname,
                $email,
                $phone,
                $username,
                Auth::hashPassword($password)
            ]);
            $student_id = $pdo->lastInsertId();

            // Create enrollment
            $enrollment_stmt = $pdo->prepare("
                INSERT INTO enrollments 
                (student_id, course_id, payment_status, payment_method, payment_proof, status) 
                VALUES (?, ?, 'pending', 'manual', ?, 'pending')
            ");
            $enrollment_stmt->execute([$student_id, $course_id, $payment_proof]);

            $success = true;
            $message = 'Application received! Please wait for admin approval.';
            // Redirect to dashboard with message
            Response::redirect('../student/dashboard.php', $message, 'success');
        } catch(Exception $e) {
            $errors['general'] = 'Registration failed. Please try again.';
        }
    } else {
        $errors = Validator::getErrors();
    }
}
// Handle registration form submission
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    Validator::clearErrors();

    $fullname = Validator::sanitizeInput($_POST['fullname'] ?? '');
    $email = Validator::sanitizeInput($_POST['email'] ?? '');
    $phone = Validator::sanitizeInput($_POST['phone'] ?? '');
    $username = Validator::sanitizeInput($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $password_confirm = $_POST['password_confirm'] ?? '';

    // Validate inputs
    $valid = true;
    
    if(!Validator::validateFullName($fullname)) {
        $valid = false;
    }
    if(!Validator::validateEmail($email)) {
        $valid = false;
    }
    if(Database::emailExists($email, 'students')) {
        Validator::$errors['email'] = 'Email already registered';
        $valid = false;
    }
    if(!Validator::validatePhone($phone)) {
        $valid = false;
    }
    if(!Validator::validateUsername($username)) {
        $valid = false;
    }
    if(Database::usernameExists($username)) {
        Validator::$errors['username'] = 'Username already taken';
        $valid = false;
    }
    if(!Validator::validatePassword($password)) {
        $valid = false;
    }
    if($password !== $password_confirm) {
        Validator::$errors['password_confirm'] = 'Passwords do not match';
        $valid = false;
    }

    // Handle payment proof file
    $payment_proof = null;
    if(isset($_FILES['payment_proof']) && $_FILES['payment_proof']['name']) {
        $file_result = FileManager::uploadFile($_FILES['payment_proof'], 'payments/');
        if(!$file_result['success']) {
            Validator::$errors['payment_proof'] = $file_result['message'];
            $valid = false;
        } else {
            $payment_proof = $file_result['filename'];
        }
    } else {
        Validator::$errors['payment_proof'] = 'Payment proof is required';
        $valid = false;
    }

    if($valid) {
        try {
            // Insert student
            $stmt = $pdo->prepare("
                INSERT INTO students 
                (fullname, email, phone, username, password, is_active) 
                VALUES (?, ?, ?, ?, ?, 0)
            ");
            $stmt->execute([
                $fullname,
                $email,
                $phone,
                $username,
                Auth::hashPassword($password)
            ]);
            $student_id = $pdo->lastInsertId();

            // Create enrollment
            $enrollment_stmt = $pdo->prepare("
                INSERT INTO enrollments 
                (student_id, course_id, payment_status, payment_method, payment_proof, status) 
                VALUES (?, ?, 'pending', 'manual', ?, 'active')
            ");
            $enrollment_stmt->execute([$student_id, $course_id, $payment_proof]);

            $success = true;
            $message = 'Registration successful! Your account is pending admin approval. You will receive an email when approved.';
        } catch(Exception $e) {
            $errors['general'] = 'Registration failed. Please try again.';
        }
    } else {
        $errors = Validator::getErrors();
    }
}

$flash = Response::getFlashMessage();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration - <?= APP_NAME ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow">
        <div class="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
            <div class="flex items-center gap-2">
                <i class="fas fa-graduation-cap text-2xl text-blue-600"></i>
                <span class="font-bold text-lg text-gray-800"><?= APP_NAME ?></span>
            </div>
            <a href="../" class="text-gray-600 hover:text-gray-900"><i class="fas fa-times"></i></a>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="max-w-2xl mx-auto py-12 px-4">
        <!-- Success Message -->
        <?php if($success): ?>
            <div class="bg-green-50 border border-green-200 rounded-lg p-6 mb-6">
                <div class="flex items-start gap-4">
                    <i class="fas fa-check-circle text-green-600 text-2xl mt-1"></i>
                    <div>
                        <h3 class="text-lg font-bold text-green-900 mb-2">Registration Successful!</h3>
                        <p class="text-green-800"><?= $message ?></p>
                        <a href="../" class="mt-4 inline-block bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                            Return to Home
                        </a>
                    </div>
                </div>
            </div>
        <?php else: ?>

        <!-- Course Info Card -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-8">
            <div class="flex items-center gap-4">
                <div class="w-16 h-16 bg-blue-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-book text-2xl text-blue-600"></i>
                </div>
                <div>
                    <h2 class="text-xl font-bold text-gray-800"><?= htmlspecialchars($course['title']) ?></h2>
                    <p class="text-gray-600"><?= htmlspecialchars($course['description']) ?></p>
                    <?php if($course['price'] > 0): ?>
                        <p class="text-lg font-bold text-blue-600 mt-2"><?= Helper::formatCurrency($course['price']) ?></p>
                    <?php else: ?>
                        <p class="text-lg font-bold text-green-600 mt-2">FREE</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Registration Form -->
        <div class="bg-white rounded-lg shadow-md overflow-hidden">
            <div class="bg-gradient-to-r from-blue-600 to-indigo-600 p-6">
                <h3 class="text-2xl font-bold text-white flex items-center gap-2">
                    <i class="fas fa-user-plus"></i>Enroll in Course
                </h3>
            </div>

            <form method="POST" enctype="multipart/form-data" class="p-6 space-y-6">
                <!-- General Error -->
                <?php if(isset($errors['general'])): ?>
                    <div class="p-4 bg-red-50 border border-red-200 rounded-lg">
                        <p class="text-red-700"><i class="fas fa-exclamation-circle mr-2"></i><?= $errors['general'] ?></p>
                    </div>
                <?php endif; ?>

                <!-- Full Name -->
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                        <i class="fas fa-user text-blue-600 mr-1"></i>Full Name *
                    </label>
                    <input 
                        type="text" 
                        name="fullname" 
                        value="<?= isset($_POST['fullname']) ? htmlspecialchars($_POST['fullname']) : '' ?>"
                        class="w-full px-4 py-2 border <?= isset($errors['fullname']) ? 'border-red-400' : 'border-gray-300' ?> rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="John Doe"
                        required
                    >
                    <?php if(isset($errors['fullname'])): ?>
                        <p class="text-red-600 text-sm mt-1"><i class="fas fa-info-circle mr-1"></i><?= $errors['fullname'] ?></p>
                    <?php endif; ?>
                </div>

                <!-- Email -->
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                        <i class="fas fa-envelope text-blue-600 mr-1"></i>Email Address *
                    </label>
                    <input 
                        type="email" 
                        name="email" 
                        value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '' ?>"
                        class="w-full px-4 py-2 border <?= isset($errors['email']) ? 'border-red-400' : 'border-gray-300' ?> rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="student@example.com"
                        required
                    >
                    <?php if(isset($errors['email'])): ?>
                        <p class="text-red-600 text-sm mt-1"><i class="fas fa-info-circle mr-1"></i><?= $errors['email'] ?></p>
                    <?php endif; ?>
                </div>

                <!-- Phone -->
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                        <i class="fas fa-phone text-blue-600 mr-1"></i>Phone Number *
                    </label>
                    <input 
                        type="tel" 
                        name="phone" 
                        value="<?= isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : '' ?>"
                        class="w-full px-4 py-2 border <?= isset($errors['phone']) ? 'border-red-400' : 'border-gray-300' ?> rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="+1 (555) 123-4567"
                        required
                    >
                    <?php if(isset($errors['phone'])): ?>
                        <p class="text-red-600 text-sm mt-1"><i class="fas fa-info-circle mr-1"></i><?= $errors['phone'] ?></p>
                    <?php endif; ?>
                </div>

                <!-- Username -->
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                        <i class="fas fa-at text-blue-600 mr-1"></i>Username *
                    </label>
                    <input 
                        type="text" 
                        name="username" 
                        value="<?= isset($_POST['username']) ? htmlspecialchars($_POST['username']) : '' ?>"
                        class="w-full px-4 py-2 border <?= isset($errors['username']) ? 'border-red-400' : 'border-gray-300' ?> rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="john_doe"
                        required
                    >
                    <?php if(isset($errors['username'])): ?>
                        <p class="text-red-600 text-sm mt-1"><i class="fas fa-info-circle mr-1"></i><?= $errors['username'] ?></p>
                    <?php endif; ?>
                </div>

                <!-- Password -->
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                        <i class="fas fa-lock text-blue-600 mr-1"></i>Password *
                    </label>
                    <input 
                        type="password" 
                        name="password" 
                        class="w-full px-4 py-2 border <?= isset($errors['password']) ? 'border-red-400' : 'border-gray-300' ?> rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="••••••••"
                        required
                    >
                    <p class="text-xs text-gray-600 mt-1"><i class="fas fa-lightbulb mr-1"></i>Min 8 chars, uppercase letter & number</p>
                    <?php if(isset($errors['password'])): ?>
                        <p class="text-red-600 text-sm mt-1"><i class="fas fa-info-circle mr-1"></i><?= $errors['password'] ?></p>
                    <?php endif; ?>
                </div>

                <!-- Confirm Password -->
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                        <i class="fas fa-lock text-blue-600 mr-1"></i>Confirm Password *
                    </label>
                    <input 
                        type="password" 
                        name="password_confirm" 
                        class="w-full px-4 py-2 border <?= isset($errors['password_confirm']) ? 'border-red-400' : 'border-gray-300' ?> rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="••••••••"
                        required
                    >
                    <?php if(isset($errors['password_confirm'])): ?>
                        <p class="text-red-600 text-sm mt-1"><i class="fas fa-info-circle mr-1"></i><?= $errors['password_confirm'] ?></p>
                    <?php endif; ?>
                </div>

                <!-- Payment Proof -->
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                        <i class="fas fa-file-upload text-blue-600 mr-1"></i>Payment Proof (Image/PDF) *
                    </label>
                    <div class="border-2 border-dashed <?= isset($errors['payment_proof']) ? 'border-red-400' : 'border-gray-300' ?> rounded-lg p-6">
                        <input 
                            type="file" 
                            name="payment_proof" 
                            accept=".jpg,.jpeg,.png,.pdf"
                            id="payment_proof"
                            class="hidden"
                            required
                        >
                        <label for="payment_proof" class="cursor-pointer flex flex-col items-center gap-2">
                            <i class="fas fa-cloud-upload-alt text-3xl text-gray-400"></i>
                            <span class="font-semibold text-gray-700">Click to upload payment proof</span>
                            <span class="text-xs text-gray-600">JPG, PNG, or PDF (Max 5MB)</span>
                        </label>
                        <p id="file_name" class="text-sm text-gray-600 mt-2"></p>
                    </div>
                    <?php if(isset($errors['payment_proof'])): ?>
                        <p class="text-red-600 text-sm mt-1"><i class="fas fa-info-circle mr-1"></i><?= $errors['payment_proof'] ?></p>
                    <?php endif; ?>
                </div>

                <!-- Terms -->
                <div class="bg-blue-50 p-4 rounded-lg">
                    <label class="flex items-start gap-3">
                        <input type="checkbox" name="terms" required class="mt-1">
                        <span class="text-sm text-gray-700">
                            I agree to the <a href="#" class="text-blue-600 font-semibold hover:underline">Terms of Service</a> and 
                            <a href="#" class="text-blue-600 font-semibold hover:underline">Privacy Policy</a> *
                        </span>
                    </label>
                </div>

                <!-- Buttons -->
                <div class="flex gap-4 pt-6 border-t">
                    <button 
                        type="submit" 
                        class="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-lg transition"
                    >
                        <i class="fas fa-check-circle mr-2"></i>Complete Enrollment
                    </button>
                    <a 
                        href="../courses.php" 
                        class="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-3 rounded-lg text-center transition"
                    >
                        <i class="fas fa-arrow-left mr-2"></i>Back to Courses
                    </a>
                </div>
            </form>
        </div>

        <?php endif; ?>
    </div>

    <!-- File name display script -->
    <script>
        document.getElementById('payment_proof')?.addEventListener('change', function(e) {
            document.getElementById('file_name').textContent = e.target.files[0]?.name || '';
        });
    </script>
</body>
</html>
