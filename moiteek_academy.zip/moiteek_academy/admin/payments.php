<?php
/**
 * Admin Payment Management Page
 * Review and approve/reject student payment submissions
 */

require_once '../bootstrap.php';

// Check if user is admin
if (!Auth::isAdminLoggedIn()) {
    header('Location: ../auth/login.php');
    exit;
}

$admin_id = Auth::getCurrentUserId();
$message = '';
$message_type = 'info';

// Handle approval/rejection
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!CSRF::validateRequest()) {
        $message = 'Security validation failed.';
        $message_type = 'error';
    } else {
        $payment_id = $_POST['payment_id'] ?? null;
        $action = $_POST['action'] ?? null;
        
        if ($payment_id && $action) {
            try {
                // Get payment details
                $stmt = $pdo->prepare(
                    'SELECT p.*, s.email, s.fullname, c.title as course_title 
                     FROM payments p
                     JOIN students s ON p.student_id = s.id
                     JOIN courses c ON p.course_id = c.id
                     WHERE p.id = ?'
                );
                $stmt->execute([$payment_id]);
                $payment = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$payment) {
                    $message = 'Payment not found.';
                    $message_type = 'error';
                } elseif ($action === 'approve') {
                    // Approve payment
                    $approvalNotes = $_POST['approval_notes'] ?? '';
                    
                    // Update payment status
                    $updateStmt = $pdo->prepare(
                        'UPDATE payments SET status = ?, approval_notes = ?, approved_by = ?, 
                         approved_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
                         WHERE id = ?'
                    );
                    $updateStmt->execute(['approved', $approvalNotes, $admin_id, $payment_id]);
                    
                    // Create login credentials and send email
                    $credentials = Auth::createPaymentApprovalCredentials(
                        $payment['student_id'],
                        $payment['email'],
                        $payment['fullname']
                    );
                    
                    if ($credentials['success']) {
                        // Send approval email with credentials
                        Email::sendPaymentApprovalWithCredentials(
                            $payment['email'],
                            $payment['fullname'],
                            $payment['course_title'],
                            $credentials['username'],
                            $credentials['password'],
                            number_format($payment['amount'], 2)
                        );
                        
                        $message = 'Payment approved! Credentials sent to student.';
                        $message_type = 'success';
                    } else {
                        $message = 'Payment approved but error sending credentials: ' . $credentials['error'];
                        $message_type = 'warning';
                    }
                } elseif ($action === 'reject') {
                    // Reject payment
                    $rejectionReason = $_POST['rejection_reason'] ?? 'No reason provided';
                    
                    // Update payment status
                    $updateStmt = $pdo->prepare(
                        'UPDATE payments SET status = ?, rejection_reason = ?, approved_by = ?, 
                         approved_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
                         WHERE id = ?'
                    );
                    $updateStmt->execute(['rejected', $rejectionReason, $admin_id, $payment_id]);
                    
                    // Send rejection email
                    Email::sendPaymentRejection(
                        $payment['email'],
                        $payment['fullname'],
                        $payment['course_title'],
                        $rejectionReason
                    );
                    
                    $message = 'Payment rejected. Email sent to student.';
                    $message_type = 'success';
                }
            } catch (Exception $e) {
                $message = 'Error processing payment: ' . $e->getMessage();
                $message_type = 'error';
                error_log('Payment processing error: ' . $e->getMessage());
            }
        }
    }
}

// Get filter parameters
$filter_status = $_GET['status'] ?? 'pending';
$search_term = $_GET['search'] ?? '';

// Build query
$query = 'SELECT p.*, s.fullname as student_name, s.email as student_email, 
          c.title as course_title, c.price as course_price,
          a.fullname as approved_by_name
          FROM payments p
          JOIN students s ON p.student_id = s.id
          JOIN courses c ON p.course_id = c.id
          LEFT JOIN admins a ON p.approved_by = a.id
          WHERE 1=1';

$params = [];

// Add status filter
if ($filter_status && $filter_status !== 'all') {
    $query .= ' AND p.status = ?';
    $params[] = $filter_status;
}

// Add search filter
if ($search_term) {
    $query .= ' AND (s.fullname LIKE ? OR s.email LIKE ? OR p.reference_number LIKE ? OR c.title LIKE ?)';
    $searchPattern = '%' . $search_term . '%';
    $params = array_merge($params, [$searchPattern, $searchPattern, $searchPattern, $searchPattern]);
}

$query .= ' ORDER BY p.created_at DESC';

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$payments = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get statistics
$statsStmt = $pdo->prepare('
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = "pending" THEN 1 ELSE 0 END) as pending,
        SUM(CASE WHEN status = "approved" THEN 1 ELSE 0 END) as approved,
        SUM(CASE WHEN status = "rejected" THEN 1 ELSE 0 END) as rejected,
        SUM(CASE WHEN status = "approved" THEN amount ELSE 0 END) as total_approved
    FROM payments
');
$statsStmt->execute();
$stats = $statsStmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Management - Moiteek Academy</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50">
    <div class="min-h-screen">
        <!-- Header -->
        <div class="bg-white border-b shadow-sm">
            <div class="max-w-7xl mx-auto px-4 py-4">
                <div class="flex justify-between items-center">
                    <div class="flex items-center gap-3">
                        <i class="fas fa-graduation-cap text-blue-600 text-2xl"></i>
                        <div>
                            <h1 class="text-2xl font-bold text-gray-800">Moiteek Academy</h1>
                            <p class="text-sm text-gray-600">Admin Panel</p>
                        </div>
                    </div>
                    <div class="flex items-center gap-4">
                        <span class="text-gray-700">Welcome, <?php echo htmlspecialchars(Auth::getCurrentUserName()); ?></span>
                        <a href="dashboard.php" class="text-blue-600 hover:text-blue-800">
                            <i class="fas fa-arrow-left"></i> Dashboard
                        </a>
                        <a href="../auth/logout.php" class="text-red-600 hover:text-red-800">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="max-w-7xl mx-auto px-4 py-8">
            <!-- Messages -->
            <?php if ($message): ?>
                <div class="mb-6 p-4 rounded-lg border-l-4 
                    <?php
                    if ($message_type === 'success') echo 'bg-green-50 border-green-400 text-green-800';
                    elseif ($message_type === 'error') echo 'bg-red-50 border-red-400 text-red-800';
                    elseif ($message_type === 'warning') echo 'bg-yellow-50 border-yellow-400 text-yellow-800';
                    else echo 'bg-blue-50 border-blue-400 text-blue-800';
                    ?>">
                    <div class="flex gap-2">
                        <i class="fas fa-<?php
                        if ($message_type === 'success') echo 'check-circle';
                        elseif ($message_type === 'error') echo 'exclamation-circle';
                        elseif ($message_type === 'warning') echo 'info-circle';
                        else echo 'info-circle';
                        ?> mt-1"></i>
                        <div><?php echo htmlspecialchars($message); ?></div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Statistics Cards -->
            <div class="grid md:grid-cols-4 gap-4 mb-8">
                <div class="bg-white rounded-lg shadow p-6 border-t-4 border-yellow-400">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-gray-600 text-sm">Pending Review</p>
                            <p class="text-3xl font-bold text-yellow-600"><?php echo $stats['pending'] ?? 0; ?></p>
                        </div>
                        <i class="fas fa-hourglass-half text-4xl text-yellow-200"></i>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow p-6 border-t-4 border-green-400">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-gray-600 text-sm">Approved</p>
                            <p class="text-3xl font-bold text-green-600"><?php echo $stats['approved'] ?? 0; ?></p>
                        </div>
                        <i class="fas fa-check-circle text-4xl text-green-200"></i>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow p-6 border-t-4 border-red-400">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-gray-600 text-sm">Rejected</p>
                            <p class="text-3xl font-bold text-red-600"><?php echo $stats['rejected'] ?? 0; ?></p>
                        </div>
                        <i class="fas fa-times-circle text-4xl text-red-200"></i>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow p-6 border-t-4 border-blue-400">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-gray-600 text-sm">Total Approved</p>
                            <p class="text-3xl font-bold text-blue-600">$<?php echo number_format($stats['total_approved'] ?? 0, 2); ?></p>
                        </div>
                        <i class="fas fa-dollar-sign text-4xl text-blue-200"></i>
                    </div>
                </div>
            </div>

            <!-- Filters -->
            <div class="bg-white rounded-lg shadow-md p-6 mb-6">
                <div class="flex flex-col md:flex-row gap-4 items-end">
                    <div class="flex-1">
                        <label class="block text-sm font-semibold text-gray-700 mb-2">
                            <i class="fas fa-search mr-2"></i>Search
                        </label>
                        <form method="GET" class="flex gap-2">
                            <input type="text" name="search" placeholder="Search by name, email, reference..." 
                                   value="<?php echo htmlspecialchars($search_term); ?>"
                                   class="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                            <input type="hidden" name="status" value="<?php echo htmlspecialchars($filter_status); ?>">
                            <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg">
                                <i class="fas fa-search"></i>
                            </button>
                        </form>
                    </div>

                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Filter by Status</label>
                        <form method="GET" class="flex gap-2">
                            <select name="status" class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                    onchange="this.form.submit();">
                                <option value="all" <?php echo $filter_status === 'all' ? 'selected' : ''; ?>>All Payments</option>
                                <option value="pending" <?php echo $filter_status === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                <option value="approved" <?php echo $filter_status === 'approved' ? 'selected' : ''; ?>>Approved</option>
                                <option value="rejected" <?php echo $filter_status === 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                            </select>
                            <input type="hidden" name="search" value="<?php echo htmlspecialchars($search_term); ?>">
                        </form>
                    </div>
                </div>
            </div>

            <!-- Payments Table -->
            <div class="bg-white rounded-lg shadow-md overflow-hidden">
                <?php if ($payments): ?>
                    <div class="overflow-x-auto">
                        <table class="w-full">
                            <thead class="bg-gray-100 border-b">
                                <tr>
                                    <th class="px-6 py-4 text-left text-sm font-semibold text-gray-700">Student</th>
                                    <th class="px-6 py-4 text-left text-sm font-semibold text-gray-700">Course</th>
                                    <th class="px-6 py-4 text-left text-sm font-semibold text-gray-700">Method</th>
                                    <th class="px-6 py-4 text-right text-sm font-semibold text-gray-700">Amount</th>
                                    <th class="px-6 py-4 text-left text-sm font-semibold text-gray-700">Status</th>
                                    <th class="px-6 py-4 text-left text-sm font-semibold text-gray-700">Date</th>
                                    <th class="px-6 py-4 text-center text-sm font-semibold text-gray-700">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($payments as $payment): ?>
                                    <tr class="border-b hover:bg-gray-50 transition">
                                        <td class="px-6 py-4">
                                            <div>
                                                <p class="font-semibold text-gray-800"><?php echo htmlspecialchars($payment['student_name']); ?></p>
                                                <p class="text-sm text-gray-500"><?php echo htmlspecialchars($payment['student_email']); ?></p>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 text-gray-800"><?php echo htmlspecialchars(substr($payment['course_title'], 0, 30)); ?></td>
                                        <td class="px-6 py-4">
                                            <span class="px-2 py-1 text-xs font-semibold bg-blue-100 text-blue-800 rounded-full">
                                                <?php echo ucfirst(str_replace('_', ' ', $payment['payment_method'])); ?>
                                            </span>
                                        </td>
                                        <td class="px-6 py-4 text-right font-semibold text-gray-800">
                                            $<?php echo number_format($payment['amount'], 2); ?>
                                        </td>
                                        <td class="px-6 py-4">
                                            <span class="px-2 py-1 text-xs font-semibold rounded-full
                                                <?php
                                                if ($payment['status'] === 'approved') echo 'bg-green-100 text-green-800';
                                                elseif ($payment['status'] === 'rejected') echo 'bg-red-100 text-red-800';
                                                elseif ($payment['status'] === 'pending') echo 'bg-yellow-100 text-yellow-800';
                                                else echo 'bg-gray-100 text-gray-800';
                                                ?>">
                                                <?php echo ucfirst($payment['status']); ?>
                                            </span>
                                        </td>
                                        <td class="px-6 py-4 text-gray-600 text-sm">
                                            <?php echo date('M d, Y', strtotime($payment['created_at'])); ?>
                                        </td>
                                        <td class="px-6 py-4 text-center">
                                            <?php if ($payment['status'] === 'pending'): ?>
                                                <button onclick="openReviewModal(<?php echo $payment['id']; ?>, '<?php echo htmlspecialchars(addslashes($payment['student_name'])); ?>', '<?php echo htmlspecialchars(addslashes($payment['course_title'])); ?>', <?php echo $payment['amount']; ?>)"
                                                        class="text-blue-600 hover:text-blue-800 font-semibold text-sm">
                                                    <i class="fas fa-eye mr-1"></i>Review
                                                </button>
                                            <?php else: ?>
                                                <button onclick="openDetailsModal(<?php echo $payment['id']; ?>, '<?php echo htmlspecialchars(addslashes($payment['student_name'])); ?>', '<?php echo htmlspecialchars(addslashes($payment['student_email'])); ?>', '<?php echo htmlspecialchars(addslashes($payment['course_title'])); ?>', <?php echo $payment['amount']; ?>, '<?php echo $payment['payment_method']; ?>', '<?php echo $payment['status']; ?>', '<?php echo htmlspecialchars(addslashes($payment['approval_notes'] ?? $payment['rejection_reason'] ?? '')); ?>')"
                                                        class="text-gray-600 hover:text-gray-800 font-semibold text-sm">
                                                    <i class="fas fa-info-circle mr-1"></i>View
                                                </button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="p-12 text-center">
                        <i class="fas fa-inbox text-6xl text-gray-300 mb-4"></i>
                        <p class="text-gray-600 text-lg">No payments found</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Review/Approve Modal -->
    <div id="reviewModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div class="bg-white rounded-lg shadow-lg max-w-md w-full mx-4">
            <div class="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-6 py-4">
                <h2 class="text-xl font-bold">Review Payment</h2>
            </div>
            <div class="p-6">
                <div id="paymentDetails"></div>
                <form method="POST" class="space-y-4 mt-6">
                    <?php echo CSRF::generateTokenField(); ?>
                    <input type="hidden" id="reviewPaymentId" name="payment_id">
                    
                    <!-- Approve Section -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Approval Notes (Optional)</label>
                        <textarea name="approval_notes" rows="3" placeholder="Add any notes for the student..."
                                  class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"></textarea>
                    </div>

                    <div class="flex gap-3">
                        <button type="submit" name="action" value="approve"
                                class="flex-1 bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded-lg transition">
                            <i class="fas fa-check mr-2"></i>Approve
                        </button>
                        <button type="button" onclick="switchToReject()"
                                class="flex-1 bg-red-600 hover:bg-red-700 text-white font-semibold py-2 px-4 rounded-lg transition">
                            <i class="fas fa-times mr-2"></i>Reject
                        </button>
                    </div>

                    <button type="button" onclick="closeReviewModal()"
                            class="w-full bg-gray-300 hover:bg-gray-400 text-gray-800 font-semibold py-2 px-4 rounded-lg transition">
                        Cancel
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- Reject Modal -->
    <div id="rejectModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div class="bg-white rounded-lg shadow-lg max-w-md w-full mx-4">
            <div class="bg-gradient-to-r from-red-600 to-red-700 text-white px-6 py-4">
                <h2 class="text-xl font-bold">Reject Payment</h2>
            </div>
            <div class="p-6">
                <form method="POST" class="space-y-4">
                    <?php echo CSRF::generateTokenField(); ?>
                    <input type="hidden" id="rejectPaymentId" name="payment_id">
                    <input type="hidden" name="action" value="reject">
                    
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Rejection Reason</label>
                        <textarea name="rejection_reason" rows="4" required placeholder="Explain why payment is rejected..."
                                  class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500"></textarea>
                    </div>

                    <div class="flex gap-3">
                        <button type="submit"
                                class="flex-1 bg-red-600 hover:bg-red-700 text-white font-semibold py-2 px-4 rounded-lg transition">
                            <i class="fas fa-times mr-2"></i>Reject
                        </button>
                        <button type="button" onclick="switchToApprove()"
                                class="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition">
                            <i class="fas fa-arrow-left mr-2"></i>Back
                        </button>
                    </div>

                    <button type="button" onclick="closeRejectModal()"
                            class="w-full bg-gray-300 hover:bg-gray-400 text-gray-800 font-semibold py-2 px-4 rounded-lg transition">
                        Cancel
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- View Details Modal -->
    <div id="detailsModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div class="bg-white rounded-lg shadow-lg max-w-md w-full mx-4">
            <div class="bg-gradient-to-r from-gray-600 to-gray-700 text-white px-6 py-4">
                <h2 class="text-xl font-bold">Payment Details</h2>
            </div>
            <div class="p-6" id="detailsContent"></div>
            <div class="px-6 py-4 bg-gray-50 border-t flex gap-3">
                <button onclick="closeDetailsModal()"
                        class="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-800 font-semibold py-2 px-4 rounded-lg transition">
                    Close
                </button>
            </div>
        </div>
    </div>

    <script>
        function openReviewModal(paymentId, studentName, courseName, amount) {
            document.getElementById('reviewPaymentId').value = paymentId;
            document.getElementById('paymentDetails').innerHTML = `
                <div class="space-y-3">
                    <div class="bg-blue-50 p-3 rounded-lg">
                        <p class="text-sm text-gray-600">Student</p>
                        <p class="font-semibold text-gray-800">${studentName}</p>
                    </div>
                    <div class="bg-blue-50 p-3 rounded-lg">
                        <p class="text-sm text-gray-600">Course</p>
                        <p class="font-semibold text-gray-800">${courseName}</p>
                    </div>
                    <div class="bg-blue-50 p-3 rounded-lg">
                        <p class="text-sm text-gray-600">Amount</p>
                        <p class="font-semibold text-blue-600 text-lg">$${parseFloat(amount).toFixed(2)}</p>
                    </div>
                </div>
            `;
            document.getElementById('reviewModal').classList.remove('hidden');
        }

        function closeReviewModal() {
            document.getElementById('reviewModal').classList.add('hidden');
        }

        function switchToReject() {
            const paymentId = document.getElementById('reviewPaymentId').value;
            closeReviewModal();
            document.getElementById('rejectPaymentId').value = paymentId;
            document.getElementById('rejectModal').classList.remove('hidden');
        }

        function closeRejectModal() {
            document.getElementById('rejectModal').classList.add('hidden');
        }

        function switchToApprove() {
            closeRejectModal();
            const paymentId = document.getElementById('rejectPaymentId').value;
            location.reload();
        }

        function openDetailsModal(paymentId, studentName, studentEmail, courseName, amount, method, status, notes) {
            document.getElementById('detailsContent').innerHTML = `
                <div class="space-y-3">
                    <div>
                        <p class="text-sm text-gray-600">Student</p>
                        <p class="font-semibold text-gray-800">${studentName}</p>
                        <p class="text-sm text-gray-600">${studentEmail}</p>
                    </div>
                    <div>
                        <p class="text-sm text-gray-600">Course</p>
                        <p class="font-semibold text-gray-800">${courseName}</p>
                    </div>
                    <div class="flex justify-between">
                        <div>
                            <p class="text-sm text-gray-600">Amount</p>
                            <p class="font-semibold text-gray-800">$${parseFloat(amount).toFixed(2)}</p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-600">Method</p>
                            <p class="font-semibold text-gray-800">${method.replace('_', ' ')}</p>
                        </div>
                    </div>
                    <div>
                        <p class="text-sm text-gray-600">Status</p>
                        <span class="px-2 py-1 text-sm font-semibold rounded-full
                            ${status === 'approved' ? 'bg-green-100 text-green-800' : 
                              status === 'rejected' ? 'bg-red-100 text-red-800' :
                              'bg-yellow-100 text-yellow-800'}">${status}</span>
                    </div>
                    ${notes ? `
                    <div>
                        <p class="text-sm text-gray-600">Notes</p>
                        <p class="text-gray-800 text-sm bg-gray-50 p-2 rounded">${notes}</p>
                    </div>
                    ` : ''}
                </div>
            `;
            document.getElementById('detailsModal').classList.remove('hidden');
        }

        function closeDetailsModal() {
            document.getElementById('detailsModal').classList.add('hidden');
        }
    </script>
</body>
</html>