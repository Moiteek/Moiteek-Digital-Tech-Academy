<?php
require_once __DIR__ . '/../includes/bootstrap.php';
if (!isset($_SESSION['student_id'])) {
    header('Location: ../auth/login.php');
    exit;
}
$student_id = $_SESSION['student_id'];

// Fetch student info
$stmt = $pdo->prepare('SELECT name, email, phone, profile_pic FROM students WHERE id = ?');
$stmt->execute([$student_id]);
$student = $stmt->fetch();

// Handle profile update
$success = '';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    if ($name && $email && $phone) {
        $stmt = $pdo->prepare('UPDATE students SET name = ?, email = ?, phone = ? WHERE id = ?');
        $stmt->execute([$name, $email, $phone, $student_id]);
        $success = 'Profile updated successfully!';
        $student['name'] = $name;
        $student['email'] = $email;
        $student['phone'] = $phone;
    } else {
        $error = 'All fields are required.';
    }
}
// Handle profile picture upload
if (isset($_FILES['profile_pic']) && $_FILES['profile_pic']['error'] === UPLOAD_ERR_OK) {
    $tmp = $_FILES['profile_pic']['tmp_name'];
    $dest_dir = __DIR__ . '/../uploads/profile_pics/';
    if (!is_dir($dest_dir)) mkdir($dest_dir, 0777, true);
    $dest = $dest_dir . 'profile_' . $student_id . '.jpg';
    if (move_uploaded_file($tmp, $dest)) {
        $rel_path = 'uploads/profile_pics/profile_' . $student_id . '.jpg';
        $stmt = $pdo->prepare('UPDATE students SET profile_pic = ? WHERE id = ?');
        $stmt->execute([$rel_path, $student_id]);
        $success = 'Profile picture updated!';
        $student['profile_pic'] = $rel_path;
    } else {
        $error = 'Failed to upload image.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
<?php include __DIR__ . '/../includes/header.php'; ?>
<div class="container mx-auto px-4 py-10 max-w-lg">
    <h1 class="text-3xl font-bold text-blue-800 mb-8">My Profile</h1>
    <?php if ($success): ?><div class="mb-4 p-3 bg-green-100 text-green-800 rounded"> <?= htmlspecialchars($success) ?> </div><?php endif; ?>
    <?php if ($error): ?><div class="mb-4 p-3 bg-red-100 text-red-800 rounded"> <?= htmlspecialchars($error) ?> </div><?php endif; ?>
    <div class="mb-8 flex flex-col items-center">
        <img src="/<?= htmlspecialchars($student['profile_pic'] ?? 'uploads/profile_pics/default.jpg') ?>" alt="Profile Picture" class="w-32 h-32 rounded-full object-cover mb-2 border-2 border-blue-300">
        <form method="post" enctype="multipart/form-data" class="mt-2">
            <input type="file" name="profile_pic" accept="image/*" class="mb-2">
            <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Update Profile Picture</button>
        </form>
    </div>
    <form method="post" class="bg-white p-6 rounded shadow">
        <div class="mb-4">
            <label class="block mb-1 font-semibold">Full Name</label>
            <input type="text" name="name" value="<?= htmlspecialchars($student['name']) ?>" class="w-full px-3 py-2 border rounded" required>
        </div>
        <div class="mb-4">
            <label class="block mb-1 font-semibold">Email</label>
            <input type="email" name="email" value="<?= htmlspecialchars($student['email']) ?>" class="w-full px-3 py-2 border rounded" required>
        </div>
        <div class="mb-4">
            <label class="block mb-1 font-semibold">Phone</label>
            <input type="text" name="phone" value="<?= htmlspecialchars($student['phone']) ?>" class="w-full px-3 py-2 border rounded" required>
        </div>
        <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded">Update Profile</button>
    </form>
</div>
</body>
</html>
