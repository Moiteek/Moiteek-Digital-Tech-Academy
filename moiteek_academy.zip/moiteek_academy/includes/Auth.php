<?php
/**
 * Production-Grade Authentication Helper Class
 * 
 * Comprehensive security features:
 * - Bcrypt password hashing (cost 10)
 * - Login attempt rate limiting with account lockout
 * - Email verification workflow
 * - Admin approval requirement before student login
 * - Password reset functionality
 * - Strong password validation
 * - Session regeneration
 * - Activity logging
 * - Prepared statements everywhere
 */

class Auth {
    private static $pdo;
    
    // Security constants
    const MAX_LOGIN_ATTEMPTS = 5;
    const LOCKOUT_DURATION = 900;          // 15 minutes
    const PASSWORD_RESET_EXPIRY = 3600;    // 1 hour
    const EMAIL_VERIFICATION_EXPIRY = 86400; // 24 hours
    const MIN_PASSWORD_LENGTH = 8;

    public static function setPDO($pdo) {
        self::$pdo = $pdo;
    }

    /**
     * ==========================================
     * PASSWORD HASHING & VERIFICATION
     * ==========================================
     */

    /**
     * Hash password using bcrypt algorithm
     * 
     * @param string $password Plain text password
     * @return string Bcrypt hash
     */
    public static function hashPassword($password) {
        return password_hash($password, PASSWORD_BCRYPT, ['cost' => 10]);
    }

    /**
     * Verify password against hash
     * 
     * @param string $password Plain text password
     * @param string $hash Bcrypt hash
     * @return bool Password matches hash
     */
    public static function verifyPassword($password, $hash) {
        return password_verify($password, $hash);
    }

    /**
     * Check if password needs rehashing (in case cost changes)
     * 
     * @param string $hash Current hash
     * @return bool True if rehashing recommended
     */
    public static function passwordNeedsRehash($hash) {
        return password_needs_rehash($hash, PASSWORD_BCRYPT, ['cost' => 10]);
    }

    /**
     * ==========================================
     * PASSWORD VALIDATION
     * ==========================================
     */

    /**
     * Validate password strength
     * 
     * Requires:
     * - Minimum 8 characters
     * - At least 1 uppercase letter
     * - At least 1 lowercase letter
     * - At least 1 number
     * - At least 1 special character (@$!%*?&)
     * 
     * @param string $password Password to validate
     * @return array ['valid' => bool, 'errors' => array]
     */
    public static function validatePasswordStrength($password) {
        $errors = [];

        if (strlen($password) < self::MIN_PASSWORD_LENGTH) {
            $errors[] = "Password must be at least " . self::MIN_PASSWORD_LENGTH . " characters";
        }

        if (!preg_match('/[A-Z]/', $password)) {
            $errors[] = "Password must contain at least one uppercase letter";
        }

        if (!preg_match('/[a-z]/', $password)) {
            $errors[] = "Password must contain at least one lowercase letter";
        }

        if (!preg_match('/[0-9]/', $password)) {
            $errors[] = "Password must contain at least one number";
        }

        if (!preg_match('/[@$!%*?&]/', $password)) {
            $errors[] = "Password must contain at least one special character (@$!%*?&)";
        }

        return [
            'valid' => empty($errors),
            'errors' => $errors
        ];
    }

    /**
     * ==========================================
     * LOGIN ATTEMPT TRACKING & LOCKOUT
     * ==========================================
     */

    /**
     * Record failed login attempt
     * 
     * @param string $email User email
     * @param string $userType 'admin' or 'student'
     * @return int Failed attempts count
     */
    private static function recordFailedAttempt($email, $userType) {
        $key = $userType . '_' . strtolower($email);
        
        // Initialize counter if not exists
        if (!isset($_SESSION['login_attempts'])) {
            $_SESSION['login_attempts'] = [];
        }
        
        if (!isset($_SESSION['login_attempts'][$key])) {
            $_SESSION['login_attempts'][$key] = [
                'attempts' => 0,
                'first_attempt' => time()
            ];
        }
        
        $_SESSION['login_attempts'][$key]['attempts']++;
        
        error_log("Failed login attempt for $userType: $email (Attempt #" . 
                  $_SESSION['login_attempts'][$key]['attempts'] . ")");
        
        return $_SESSION['login_attempts'][$key]['attempts'];
    }

    /**
     * Check if account is locked due to failed attempts
     * 
     * @param string $email User email
     * @param string $userType 'admin' or 'student'
     * @return array ['locked' => bool, 'remaining_time' => int]
     */
    public static function isAccountLocked($email, $userType) {
        $key = $userType . '_' . strtolower($email);
        
        if (!isset($_SESSION['login_attempts'][$key])) {
            return ['locked' => false, 'remaining_time' => 0];
        }
        
        $data = $_SESSION['login_attempts'][$key];
        
        if ($data['attempts'] >= self::MAX_LOGIN_ATTEMPTS) {
            $timeElapsed = time() - $data['first_attempt'];
            
            if ($timeElapsed < self::LOCKOUT_DURATION) {
                $remainingTime = self::LOCKOUT_DURATION - $timeElapsed;
                return ['locked' => true, 'remaining_time' => $remainingTime];
            } else {
                // Lockout expired, reset attempts
                unset($_SESSION['login_attempts'][$key]);
                return ['locked' => false, 'remaining_time' => 0];
            }
        }
        
        return ['locked' => false, 'remaining_time' => 0];
    }

    /**
     * Clear login attempts after successful login
     * 
     * @param string $email User email
     * @param string $userType 'admin' or 'student'
     */
    private static function clearLoginAttempts($email, $userType) {
        $key = $userType . '_' . strtolower($email);
        if (isset($_SESSION['login_attempts'][$key])) {
            unset($_SESSION['login_attempts'][$key]);
        }
    }

    /**
     * ==========================================
     * ADMIN LOGIN
     * ==========================================
     */

    /**
     * Admin login with rate limiting and security checks
     * 
     * @param string $email Admin email
     * @param string $password Plain text password
     * @return array ['success' => bool, 'message' => string]
     */
    public static function loginAdmin($email, $password) {
        // Sanitize input
        $email = strtolower(trim($email));

        // Check account lockout
        $lockCheck = self::isAccountLocked($email, 'admin');
        if ($lockCheck['locked']) {
            $minutes = ceil($lockCheck['remaining_time'] / 60);
            Email::sendSecurityAlert($email, $email, 
                "Multiple failed login attempts. Account locked for $minutes minutes.");
            
            return [
                'success' => false, 
                'message' => "Account temporarily locked. Try again in $minutes minutes."
            ];
        }

        // Get admin with all security fields
        $stmt = self::$pdo->prepare("
            SELECT id, fullname, email, role, password, status
            FROM admins 
            WHERE email = ? AND status = 'active'
        ");
        $stmt->execute([$email]);
        $admin = $stmt->fetch();

        if (!$admin) {
            self::recordFailedAttempt($email, 'admin');
            return [
                'success' => false, 
                'message' => 'Invalid email or password'
            ];
        }

        // Verify password
        if (!self::verifyPassword($password, $admin['password'])) {
            $attempts = self::recordFailedAttempt($email, 'admin');
            
            if ($attempts >= self::MAX_LOGIN_ATTEMPTS) {
                Email::sendSecurityAlert($email, $admin['fullname'],
                    "Multiple failed login attempts detected. Your account is temporarily locked.");
            }
            
            return [
                'success' => false, 
                'message' => 'Invalid email or password'
            ];
        }

        // Check if password needs rehashing
        if (self::passwordNeedsRehash($admin['password'])) {
            $newHash = self::hashPassword($password);
            $stmt = self::$pdo->prepare("UPDATE admins SET password = ? WHERE id = ?");
            $stmt->execute([$newHash, $admin['id']]);
        }

        // Clear login attempts and set session
        self::clearLoginAttempts($email, 'admin');
        self::regenerateSession();
        self::setAdminSession($admin);

        // Update last login
        $stmt = self::$pdo->prepare("UPDATE admins SET last_login = NOW() WHERE id = ?");
        $stmt->execute([$admin['id']]);

        error_log("Admin login successful: " . $email);

        return ['success' => true, 'message' => 'Login successful'];
    }

    /**
     * ==========================================
     * STUDENT LOGIN
     * ==========================================
     */

    /**
     * Student login with email verification and admin approval checks
     * 
     * @param string $email Student email or username
     * @param string $password Plain text password
     * @return array ['success' => bool, 'message' => string]
     */
    public static function loginStudent($email, $password) {
        // Sanitize input
        $email = strtolower(trim($email));

        // Check account lockout
        $lockCheck = self::isAccountLocked($email, 'student');
        if ($lockCheck['locked']) {
            $minutes = ceil($lockCheck['remaining_time'] / 60);
            Email::sendSecurityAlert($email, $email,
                "Multiple failed login attempts. Account locked for $minutes minutes.");
            
            return [
                'success' => false, 
                'message' => "Account temporarily locked. Try again in $minutes minutes."
            ];
        }

        // Get student with all security fields
        $stmt = self::$pdo->prepare("
            SELECT id, fullname, email, username, password, status, email_verified, is_active
            FROM students 
            WHERE (email = ? OR username = ?)
        ");
        $stmt->execute([$email, $email]);
        $student = $stmt->fetch();

        if (!$student) {
            self::recordFailedAttempt($email, 'student');
            return [
                'success' => false, 
                'message' => 'Invalid email/username or password'
            ];
        }

        // Check if account is active
        if (!$student['is_active']) {
            return [
                'success' => false,
                'message' => 'Your account has been deactivated. Contact support.'
            ];
        }

        // Check email verification
        if (!$student['email_verified']) {
            return [
                'success' => false,
                'message' => 'Please verify your email before logging in. Check your inbox.'
            ];
        }

        // Check admin approval status (requirement before login)
        if ($student['status'] !== 'approved') {
            if ($student['status'] === 'pending') {
                return [
                    'success' => false,
                    'message' => 'Your account is pending admin approval. You will be notified once approved.'
                ];
            } elseif ($student['status'] === 'rejected') {
                return [
                    'success' => false,
                    'message' => 'Your account has been rejected. Contact support for more information.'
                ];
            } elseif ($student['status'] === 'suspended') {
                return [
                    'success' => false,
                    'message' => 'Your account has been suspended. Contact support immediately.'
                ];
            }
        }

        // Verify password
        if (!self::verifyPassword($password, $student['password'])) {
            $attempts = self::recordFailedAttempt($email, 'student');
            
            if ($attempts >= self::MAX_LOGIN_ATTEMPTS) {
                Email::sendSecurityAlert($email, $student['fullname'],
                    "Multiple failed login attempts detected on your account.");
            }
            
            return [
                'success' => false,
                'message' => 'Invalid email/username or password'
            ];
        }

        // Check if password needs rehashing
        if (self::passwordNeedsRehash($student['password'])) {
            $newHash = self::hashPassword($password);
            $stmt = self::$pdo->prepare("UPDATE students SET password = ? WHERE id = ?");
            $stmt->execute([$newHash, $student['id']]);
        }

        // Clear login attempts and set session
        self::clearLoginAttempts($email, 'student');
        self::regenerateSession();
        self::setStudentSession($student);

        // Update last login
        $stmt = self::$pdo->prepare("UPDATE students SET last_login = NOW() WHERE id = ?");
        $stmt->execute([$student['id']]);

        error_log("Student login successful: " . $email);

        return ['success' => true, 'message' => 'Login successful'];
    }

    /**
     * ==========================================
     * EMAIL VERIFICATION
     * ==========================================
     */

    /**
     * Generate email verification token
     * 
     * @param int $studentId Student ID
     * @param string $email Student email
     * @return string Verification token
     */
    public static function generateEmailVerificationToken($studentId, $email) {
        $token = bin2hex(random_bytes(32));
        $expiryTime = date('Y-m-d H:i:s', time() + self::EMAIL_VERIFICATION_EXPIRY);

        $stmt = self::$pdo->prepare("
            INSERT INTO email_verification_tokens (student_id, token, email, expires_at) 
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([$studentId, $token, $email, $expiryTime]);

        return $token;
    }

    /**
     * Verify email token and activate student
     * 
     * @param string $token Verification token
     * @return array ['success' => bool, 'message' => string]
     */
    public static function verifyEmailToken($token) {
        $stmt = self::$pdo->prepare("
            SELECT student_id, email, expires_at 
            FROM email_verification_tokens 
            WHERE token = ? AND expires_at > NOW()
        ");
        $stmt->execute([$token]);
        $verification = $stmt->fetch();

        if (!$verification) {
            return [
                'success' => false,
                'message' => 'Invalid or expired verification link'
            ];
        }

        // Mark student email as verified
        $stmt = self::$pdo->prepare("
            UPDATE students 
            SET email_verified = 1 
            WHERE id = ?
        ");
        $stmt->execute([$verification['student_id']]);

        // Delete used token
        $stmt = self::$pdo->prepare("DELETE FROM email_verification_tokens WHERE token = ?");
        $stmt->execute([$token]);

        error_log("Email verified for student ID: " . $verification['student_id']);

        return [
            'success' => true,
            'message' => 'Email verified successfully. You can now log in.'
        ];
    }

    /**
     * ==========================================
     * PASSWORD RESET
     * ==========================================
     */

    /**
     * Generate password reset token
     * 
     * @param string $email User email
     * @param string $userType 'admin' or 'student'
     * @return array ['success' => bool, 'token' => string, 'message' => string]
     */
    public static function generatePasswordResetToken($email, $userType) {
        $email = strtolower(trim($email));

        // Get user
        if ($userType === 'admin') {
            $stmt = self::$pdo->prepare("SELECT id, fullname FROM admins WHERE email = ?");
        } else {
            $stmt = self::$pdo->prepare("SELECT id, fullname FROM students WHERE email = ?");
        }

        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user) {
            // Don't reveal if email exists (security)
            return [
                'success' => true,
                'message' => 'If email exists, password reset link will be sent'
            ];
        }

        // Generate token
        $token = bin2hex(random_bytes(32));
        $expiryTime = date('Y-m-d H:i:s', time() + self::PASSWORD_RESET_EXPIRY);

        $stmt = self::$pdo->prepare("
            INSERT INTO password_reset_tokens (user_id, email, token, user_type, expires_at) 
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([$user['id'], $email, $token, $userType, $expiryTime]);

        error_log("Password reset token generated for $userType: $email");

        return [
            'success' => true,
            'token' => $token,
            'message' => 'Password reset token generated'
        ];
    }

    /**
     * Verify and use password reset token
     * 
     * @param string $token Reset token
     * @param string $newPassword New password
     * @return array ['success' => bool, 'message' => string]
     */
    public static function resetPasswordWithToken($token, $newPassword) {
        // Validate new password
        $validation = self::validatePasswordStrength($newPassword);
        if (!$validation['valid']) {
            return [
                'success' => false,
                'message' => implode('. ', $validation['errors'])
            ];
        }

        // Get valid reset token
        $stmt = self::$pdo->prepare("
            SELECT user_id, email, user_type 
            FROM password_reset_tokens 
            WHERE token = ? AND expires_at > NOW()
        ");
        $stmt->execute([$token]);
        $resetData = $stmt->fetch();

        if (!$resetData) {
            return [
                'success' => false,
                'message' => 'Invalid or expired password reset link'
            ];
        }

        $newHash = self::hashPassword($newPassword);

        // Update password
        if ($resetData['user_type'] === 'admin') {
            $stmt = self::$pdo->prepare("UPDATE admins SET password = ? WHERE id = ?");
        } else {
            $stmt = self::$pdo->prepare("UPDATE students SET password = ? WHERE id = ?");
        }

        $stmt->execute([$newHash, $resetData['user_id']]);

        // Delete used token
        $stmt = self::$pdo->prepare("DELETE FROM password_reset_tokens WHERE token = ?");
        $stmt->execute([$token]);

        // Invalidate all sessions for this user (force re-login)
        error_log("Password reset for " . $resetData['user_type'] . ": " . $resetData['email']);

        return [
            'success' => true,
            'message' => 'Password reset successfully. Please log in with your new password.'
        ];
    }

    /**
     * ==========================================
     * SESSION MANAGEMENT
     * ==========================================
     */

    /**
     * Regenerate session ID (security best practice)
     */
    private static function regenerateSession() {
        session_regenerate_id(true);
        $_SESSION['session_created'] = time();
    }

    /**
     * Set admin session variables
     */
    private static function setAdminSession($admin) {
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_email'] = $admin['email'];
        $_SESSION['admin_name'] = $admin['fullname'];
        $_SESSION['admin_role'] = $admin['role'];
        $_SESSION['user_type'] = 'admin';
        $_SESSION['login_time'] = time();
    }

    /**
     * Set student session variables
     */
    private static function setStudentSession($student) {
        $_SESSION['student_id'] = $student['id'];
        $_SESSION['student_email'] = $student['email'];
        $_SESSION['student_name'] = $student['fullname'];
        $_SESSION['user_type'] = 'student';
        $_SESSION['login_time'] = time();
    }

    /**
     * ==========================================
     * SESSION VERIFICATION
     * ==========================================
     */

    /**
     * Check if admin is logged in
     */
    public static function isAdminLoggedIn() {
        return isset($_SESSION['admin_id']) && $_SESSION['user_type'] === 'admin';
    }

    /**
     * Check if student is logged in
     */
    public static function isStudentLoggedIn() {
        return isset($_SESSION['student_id']) && $_SESSION['user_type'] === 'student';
    }

    /**
     * ==========================================
     * LOGOUT
     * ==========================================
     */

    /**
     * Logout user securely
     */
    public static function logout() {
        // Clear CSRF tokens
        if (class_exists('CSRF')) {
            CSRF::clearTokens();
        }

        // Clear login attempts
        if (isset($_SESSION['login_attempts'])) {
            unset($_SESSION['login_attempts']);
        }

        // Destroy session
        $_SESSION = [];
        session_destroy();
        
        error_log("User logged out successfully");

        return true;
    }

    /**
     * ==========================================
     * USER INFO
     * ==========================================
     */

    /**
     * Get current user ID
     */
    public static function getCurrentUserId() {
        if (self::isAdminLoggedIn()) return $_SESSION['admin_id'];
        if (self::isStudentLoggedIn()) return $_SESSION['student_id'];
        return null;
    }

    /**
     * Get current user type
     */
    public static function getCurrentUserType() {
        return $_SESSION['user_type'] ?? null;
    }

    /**
     * Get current user email
     */
    public static function getCurrentUserEmail() {
        if (self::isAdminLoggedIn()) return $_SESSION['admin_email'] ?? null;
        if (self::isStudentLoggedIn()) return $_SESSION['student_email'] ?? null;
        return null;
    }

    /**
     * Get current user name
     */
    public static function getCurrentUserName() {
        return $_SESSION['admin_name'] ?? $_SESSION['student_name'] ?? null;
    }

    /**
     * ==========================================
     * PAYMENT & CREDENTIAL GENERATION
     * ==========================================
     */

    /**
     * Generate random secure password
     * 
     * Creates a password that meets security requirements:
     * - 12 characters minimum
     * - Uppercase letters
     * - Lowercase letters
     * - Numbers
     * - Special characters
     * 
     * @param int $length Password length (default 12)
     * @return string Generated secure password
     */
    public static function generateSecurePassword($length = 12) {
        $uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $lowercase = 'abcdefghijklmnopqrstuvwxyz';
        $numbers = '0123456789';
        $special = '@$!%*?&';
        
        $all = $uppercase . $lowercase . $numbers . $special;
        $password = '';
        
        // Ensure at least one of each type
        $password .= $uppercase[random_int(0, strlen($uppercase) - 1)];
        $password .= $lowercase[random_int(0, strlen($lowercase) - 1)];
        $password .= $numbers[random_int(0, strlen($numbers) - 1)];
        $password .= $special[random_int(0, strlen($special) - 1)];
        
        // Fill remaining length with random characters
        for ($i = 4; $i < $length; $i++) {
            $password .= $all[random_int(0, strlen($all) - 1)];
        }
        
        // Shuffle password
        $password = str_shuffle($password);
        
        return $password;
    }

    /**
     * Generate username from student name
     * 
     * Creates a unique, URL-safe username:
     * - Converts to lowercase
     * - Replaces spaces with underscores
     * - Removes special characters
     * - Appends 4-digit random number if needed for uniqueness
     * 
     * @param string $fullName Student full name
     * @return string Generated username
     */
    public static function generateUsername($fullName) {
        global $pdo;
        
        // Convert to lowercase and remove extra spaces
        $name = strtolower(trim($fullName));
        
        // Remove or replace special characters
        $username = preg_replace('/[^a-z0-9\s]/', '', $name);
        
        // Replace spaces with underscores
        $username = preg_replace('/\s+/', '_', $username);
        
        // Remove leading/trailing underscores
        $username = trim($username, '_');
        
        // Check if username is empty after cleanup
        if (empty($username)) {
            $username = 'user_' . random_int(1000, 9999);
        }
        
        // Keep trying with random suffix until unique
        $baseUsername = $username;
        $attempt = 0;
        
        while (true) {
            // Check if username exists
            $stmt = $pdo->prepare('SELECT id FROM students WHERE username = ? LIMIT 1');
            $stmt->execute([$username]);
            
            if (!$stmt->fetch()) {
                // Username is unique
                return $username;
            }
            
            // Add random suffix and try again
            $attempt++;
            $username = $baseUsername . '_' . $attempt;
            
            if ($attempt > 100) {
                // Fallback to completely random
                $username = 'user_' . random_int(10000000, 99999999);
                break;
            }
        }
        
        return $username;
    }

    /**
     * Create payment approval credentials and send to student
     * 
     * Automatically generates and assigns:
     * - Username (from full name)
     * - Secure password
     * - Sends login credentials via email
     * 
     * @param int $student_id Student ID
     * @param string $email Student email
     * @param string $fullName Student full name
     * @return array ['username' => string, 'password' => string, 'success' => bool]
     */
    public static function createPaymentApprovalCredentials($student_id, $email, $fullName) {
        global $pdo;
        
        try {
            // Generate credentials
            $username = self::generateUsername($fullName);
            $password = self::generateSecurePassword(12);
            $hashedPassword = self::hashPassword($password);
            
            // Update student record
            $stmt = $pdo->prepare(
                'UPDATE students SET username = ?, password = ?, status = ?, 
                 email_verified = 1, is_active = 1, updated_at = CURRENT_TIMESTAMP 
                 WHERE id = ?'
            );
            $stmt->execute([$username, $hashedPassword, 'approved', $student_id]);
            
            // Only update username if it wasn't set before
            // Get current username
            $checkStmt = $pdo->prepare('SELECT username FROM students WHERE id = ?');
            $checkStmt->execute([$student_id]);
            $current = $checkStmt->fetch(PDO::FETCH_ASSOC);
            
            if (empty($current['username'])) {
                $stmt = $pdo->prepare('UPDATE students SET username = ? WHERE id = ?');
                $stmt->execute([$username, $student_id]);
            } else {
                $username = $current['username'];
            }
            
            // Always update password to the new one
            $stmt = $pdo->prepare('UPDATE students SET password = ?, email_verified = 1, is_active = 1 WHERE id = ?');
            $stmt->execute([$hashedPassword, $student_id]);
            
            // Mark status as approved if pending
            $statusStmt = $pdo->prepare('UPDATE students SET status = ? WHERE id = ? AND status = ?');
            $statusStmt->execute(['approved', $student_id, 'pending']);
            
            // Send credentials email
            Email::sendLoginCredentials($email, $username, $password, $fullName);
            
            return [
                'username' => $username,
                'password' => $password,
                'success' => true
            ];
        } catch (Exception $e) {
            error_log("Error creating payment approval credentials: " . $e->getMessage());
            return [
                'username' => '',
                'password' => '',
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
}
?>