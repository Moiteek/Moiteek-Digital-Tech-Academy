-- COURSE MODULES TABLE (add lesson ordering)
ALTER TABLE course_modules
  ADD COLUMN module_order INT DEFAULT 0 AFTER course_id;

-- LESSONS TABLE (new, supports video and resources)
CREATE TABLE IF NOT EXISTS lessons (
  id INT AUTO_INCREMENT PRIMARY KEY,
  course_id INT NOT NULL,
  module_id INT NOT NULL,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  video_type ENUM('youtube','vimeo','upload') NOT NULL,
  video_url VARCHAR(255),
  video_file VARCHAR(255),
  resource_links TEXT,
  lesson_order INT DEFAULT 0,
  is_published TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
  FOREIGN KEY (module_id) REFERENCES course_modules(id) ON DELETE CASCADE,
  INDEX idx_course_id (course_id),
  INDEX idx_module_id (module_id),
  INDEX idx_lesson_order (lesson_order)
);

-- COURSE COMPLETION LOGIC
ALTER TABLE enrollments
  ADD COLUMN completed_at TIMESTAMP NULL AFTER status;

-- Add indexes for lesson ordering and completion tracking.
