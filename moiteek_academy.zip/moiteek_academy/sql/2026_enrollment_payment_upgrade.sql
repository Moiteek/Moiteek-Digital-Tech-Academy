-- ENROLLMENTS TABLE (add status)
ALTER TABLE enrollments
  ADD COLUMN status ENUM('pending','approved','rejected','completed') DEFAULT 'pending' AFTER course_id;

-- PAYMENTS TABLE (add gateway, transaction log, webhook fields)
ALTER TABLE payments
  ADD COLUMN gateway ENUM('paystack','flutterwave','stripe','bank_transfer') DEFAULT 'bank_transfer' AFTER payment_method,
  ADD COLUMN webhook_payload JSON NULL AFTER external_api_response,
  ADD COLUMN webhook_verified TINYINT(1) DEFAULT 0 AFTER webhook_payload;

-- TRANSACTION LOGS TABLE
CREATE TABLE IF NOT EXISTS payment_transactions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  payment_id INT NOT NULL,
  gateway ENUM('paystack','flutterwave','stripe','bank_transfer') NOT NULL,
  transaction_ref VARCHAR(100) NOT NULL,
  status ENUM('initiated','pending','success','failed','cancelled') NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  currency VARCHAR(10) DEFAULT 'NGN',
  log_type ENUM('request','response','webhook','manual') NOT NULL,
  payload JSON,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (payment_id) REFERENCES payments(id) ON DELETE CASCADE,
  INDEX idx_payment_id (payment_id),
  INDEX idx_transaction_ref (transaction_ref)
);

-- ADMIN MANUAL OVERRIDE (add to payments)
ALTER TABLE payments
  ADD COLUMN manual_override TINYINT(1) DEFAULT 0 AFTER webhook_verified,
  ADD COLUMN override_reason VARCHAR(255) NULL AFTER manual_override;

-- BANK TRANSFER INFO (static, for display)
-- Bank: Zenith Bank, Account: 2413365482

-- Ensure all new columns are indexed where needed.
