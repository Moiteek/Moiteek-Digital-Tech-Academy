# VERIFICATION CHECKLIST - Moiteek Academy v1.0.0

Complete checklist to verify your Moiteek Academy installation is working correctly.

---

## ✅ **Installation Verification**

### **1. Directory Structure**
Run this command to verify all directories exist:

```bash
# Windows PowerShell or cmd
dir c:\xampp\htdocs\moiteek_academy\

# Expected result: All these folders should exist
# - config/
# - includes/
# - auth/
# - admin/
# - student/
# - assets/ (with css/ and js/ subdirectories)
# - sql/
# - uploads/ (with payments/ subdirectory)
```

**Checklist:**
- [ ] `/config/` exists with `db.php`
- [ ] `/includes/` exists with 5 PHP helper classes
- [ ] `/auth/` exists with login, register, logout
- [ ] `/admin/` exists with dashboard, students, payments, courses, enrollments
- [ ] `/student/` exists with dashboard and course
- [ ] `/assets/css/` exists with `custom.css`
- [ ] `/assets/js/` exists with `app.js`
- [ ] `/sql/` exists with `database.sql`
- [ ] `/uploads/payments/` directory writable (chmod 775)

---

## 🔌 **Database Verification**

### **2. Database Connection**

**Test connection:**
```bash
mysql -u root -p -e "SELECT 1;"
# If successful, shows: 1

mysql -u root -p -e "SHOW DATABASES LIKE 'moiteek_academy';"
# Should list: moiteek_academy
```

**Checklist:**
- [ ] MySQL server is running
- [ ] Database `moiteek_academy` exists
- [ ] Can connect with credentials from `config/db.php`

---

### **3. Database Tables**

**Verify all tables exist:**
```bash
mysql -u root -p moiteek_academy -e "SHOW TABLES;"
```

**Expected tables (10+):**
- [ ] `admins`
- [ ] `students`
- [ ] `courses`
- [ ] `enrollments`
- [ ] `payments`
- [ ] `progress`
- [ ] `course_modules`
- [ ] `course_content`
- [ ] `certificates`
- [ ] `notifications`

---

### **4. Sample Data Verification**

**Check if admin account exists:**
```sql
mysql -u root -p moiteek_academy -e "SELECT email, role FROM admins LIMIT 5;"

# Should show:
# admin@moiteek.com | super_admin
```

**Check if test student exists:**
```sql
mysql -u root -p moiteek_academy -e "SELECT email, username, status FROM students WHERE email='student@test.com';"

# Should show:
# student@test.com | student123 | approved
```

**Checklist:**
- [ ] Default admin account present (admin@moiteek.com)
- [ ] Test student account present (student@test.com)
- [ ] Sample courses exist (at least 3)

---

## 🌐 **Web Server Verification**

### **5. PHP Configuration**

**Verify PHP version and modules:**
```bash
php -v          # Should show PHP 7.4+
php -m          # Should show: PDO, pdo_mysql
```

**Checklist:**
- [ ] PHP 7.4+ installed
- [ ] PDO extension enabled
- [ ] pdo_mysql driver enabled
- [ ] GD library enabled (for images)

---

### **6. File Permissions**

**Check file permissions:**
```bash
# Linux/Mac
ls -la /var/www/html/moiteek_academy/
ls -la /var/www/html/moiteek_academy/uploads/payments/

# Should show: drwxr-xr-x (755) for folders, -rw-r--r-- (644) for files
```

**Windows:** 
- Right-click → Properties → Security
- Uploads/ should be writable by system/web server user

**Checklist:**
- [ ] `/uploads/payments/` is writable (can upload files)
- [ ] `/config/db.php` is readable but restricted (640 ideal)
- [ ] All PHP files are readable

---

## 🔐 **Security Verification**

### **7. Authentication Test**

**Test Admin Login:**
1. Visit: http://localhost/moiteek_academy/auth/login.php
2. Login with: admin@moiteek.com / Admin@123
3. Should redirect to: /admin/dashboard.php

**Check:**
- [ ] Login page loads
- [ ] Credentials accepted
- [ ] Redirects to admin dashboard
- [ ] Session variables set (check in page)

---

**Test Student Login:**
1. Logout from admin
2. Visit: http://localhost/moiteek_academy/auth/login.php
3. Login with: student@test.com / Student@123
4. Should redirect to: /student/dashboard.php

**Check:**
- [ ] Student login page loads
- [ ] Credentials accepted
- [ ] Redirects to student dashboard
- [ ] Session variables set

---

### **8. Password Hashing Verification**

**Verify bcrypt hashing:**
```bash
php -r "echo password_hash('test123', PASSWORD_BCRYPT, ['cost' => 10]);"
# Should output bcrypt hash like: $2y$10$...
```

**In database, passwords should be bcrypt hashes:**
```sql
SELECT email, password FROM admins LIMIT 1;
# Password column should show: $2y$10$... (not plain text, not MD5)
```

**Checklist:**
- [ ] Passwords are bcrypt hashes (not plain text)
- [ ] Hash starts with `$2y$10$`
- [ ] Hash length is 60 characters

---

### **9. Session Timeout Verification**

**Check session settings in `config/db.php`:**
```php
# Should have:
session_set_cookie_params([
    'lifetime' => 1800,          # 30 minutes
    'httponly' => true,           # Secure cookie
    'samesite' => 'Strict'        # CSRF protection
]);
```

**Checklist:**
- [ ] Session lifetime set to 1800 (30 minutes)
- [ ] HttpOnly flag is true
- [ ] SameSite is set to Strict

---

## 🎨 **UI/UX Verification**

### **10. Frontend Assets**

**Verify CSS is loaded:**
1. View page source (Ctrl+U)
2. Look for: `<link rel="stylesheet" href="https://cdn.tailwindcss.com">`
3. Look for: `<link rel="stylesheet" href="/moiteek_academy/assets/css/custom.css">`

**Verify JavaScript is loaded:**
1. View page source
2. Look for: `<script src="https://kit.fontawesome.com/..."></script>`
3. Look for: `<script src="/moiteek_academy/assets/js/app.js"></script>`

**Checklist:**
- [ ] Tailwind CSS CDN loaded
- [ ] Custom CSS loaded
- [ ] Font Awesome icons loaded
- [ ] JavaScript app.js loaded
- [ ] Page styling appears correct (colors, fonts, spacing)

---

### **11. Responsive Design**

**Test responsive design:**
1. Open any page
2. Press F12 (Developer Tools)
3. Click mobile device icon (or Ctrl+Shift+M)
4. Test various device sizes: iPhone, iPad, Desktop

**Expected behavior:**
- [ ] Mobile view (< 640px): 1 column layout
- [ ] Tablet view (640px-1024px): 2 columns
- [ ] Desktop view (> 1024px): 3+ columns
- [ ] Navigation adapts (hamburger on mobile)
- [ ] Buttons are clickable on mobile
- [ ] Text is readable

---

### **12. Animations & Interactions**

**Test smooth interactions:**

On homepage:
- [ ] Smooth scroll to sections
- [ ] Cards have hover effects
- [ ] Buttons show hover state
- [ ] Progress bars animate
- [ ] Testimonials display properly

On forms:
- [ ] Input fields show focus state
- [ ] Error messages appear in red
- [ ] Submit button shows loading state
- [ ] Success messages show (green)

---

## 📊 **Functionality Verification**

### **13. Course Browsing**

**Test course listing:**
1. Visit: http://localhost/moiteek_academy/courses.php
2. Should display course cards in a grid
3. Search box should function
4. Filters should work

**Check:**
- [ ] Course grid displays (at least 3 courses)
- [ ] Course cards show: image, title, price, level
- [ ] Search box is visible and functional
- [ ] Filter dropdowns exist (level, category)
- [ ] Course cards are clickable
- [ ] Clicking course goes to details page

---

### **14. Course Details**

**Test individual course page:**
1. Click on any course from courses.php
2. Should show detailed course information

**Check:**
- [ ] Course header displays (title, description)
- [ ] Course price visible
- [ ] "Enroll Now" button present
- [ ] Curriculum/modules listed
- [ ] Instructor information shown
- [ ] Requirements section visible
- [ ] Testimonials section present

---

### **15. Enrollment Workflow**

**Test student enrollment:**
1. Login as student (student@test.com)
2. Go to a course
3. Click "Enroll Now"
4. Complete enrollment form with payment proof

**Check:**
- [ ] Enrollment form appears
- [ ] Can select payment proof file
- [ ] File upload accepts images and PDF
- [ ] Form validation works (shows errors)
- [ ] Success message appears
- [ ] Enrollment appears in dashboard

---

### **16. Admin Dashboard**

**Test admin functions:**
1. Login as admin (admin@moiteek.com)
2. Go to admin dashboard

**Check:**
- [ ] Dashboard loads successfully
- [ ] Statistics cards display numbers
- [ ] Quick links to students/payments/courses visible
- [ ] Recent activity shows transactions
- [ ] Revenue summary displayed
- [ ] All buttons are functional

---

### **17. Student Management**

**Test student approval workflow:**
1. As admin, go to: /admin/students.php
2. Click on pending student

**Check:**
- [ ] Student list loads
- [ ] Can filter by status (pending/approved/rejected)
- [ ] Student detail page shows full info
- [ ] Approve/Reject buttons functional
- [ ] Status updates in database
- [ ] Changes reflect in student list

---

### **18. Payment Management**

**Test payment confirmation:**
1. As admin, go to: /admin/payments.php
2. See pending payments

**Check:**
- [ ] Payment list displays
- [ ] Can filter by status (pending/confirmed/failed)
- [ ] Can view payment proof/receipt
- [ ] Can confirm payment
- [ ] Status updates after confirmation
- [ ] Student sees updated enrollment status

---

### **19. Student Dashboard**

**Test student learning hub:**
1. Login as student (student@test.com)
2. Go to: /student/dashboard.php

**Check:**
- [ ] Dashboard loads successfully
- [ ] Statistics cards show correct numbers
- [ ] Enrolled courses display
- [ ] Progress bars visible
- [ ] Payment status shown (pending/confirmed)
- [ ] Quick action buttons work (enroll new, view certificates)

---

## 🔍 **Testing Verification**

### **20. Browser Console**

**Verify no JavaScript errors:**
1. Open any page
2. Press F12 (Developer Tools)
3. Go to Console tab
4. Look for red error messages

**Expected:** No red JavaScript errors

**Checklist:**
- [ ] No JavaScript errors in console
- [ ] No 404 errors for resources
- [ ] No CORS warnings
- [ ] Console is clean (warnings ok, errors not ok)

---

### **21. Network Tab**

**Verify all resources load:**
1. Open Developer Tools → Network tab
2. Reload page
3. Check all requests

**Expected:**
- [ ] No 404 errors (all resources found)
- [ ] CSS files load (status 200)
- [ ] JS files load (status 200)
- [ ] Images load (status 200)
- [ ] Page load time < 3 seconds

---

## 📝 **Documentation Verification**

### **22. Documentation Files**

**Verify all documentation exists:**
```bash
ls -la c:\xampp\htdocs\moiteek_academy\*.md
```

**Check:**
- [ ] README.md exists (3000+ words)
- [ ] QUICKSTART.md exists
- [ ] DEVELOPMENT.md exists
- [ ] DEPLOYMENT.md exists
- [ ] API.md exists (2000+ words)
- [ ] PROJECT_SUMMARY.md exists
- [ ] .env.example exists

**Checklist:**
- [ ] README.md has setup instructions
- [ ] QUICKSTART.md has 5-minute setup
- [ ] DEVELOPMENT.md has code standards
- [ ] DEPLOYMENT.md has production setup
- [ ] API.md has class reference
- [ ] All files are readable and complete

---

## 🧪 **Performance Testing**

### **23. Page Load Speed**

**Test page load times:**
1. Open Developer Tools → Performance tab
2. Click record, reload page, stop recording

**Expected:**
- [ ] Homepage loads in < 2-3 seconds
- [ ] Courses page loads in < 2 seconds  
- [ ] Dashboard loads in < 2-3 seconds
- [ ] All pages have acceptable load time

---

### **24. Database Performance**

**Check for slow queries:**
```bash
mysql -u root -p moiteek_academy -e "SELECT COUNT(*) as count FROM courses;"
```

**Expected:**
- [ ] Queries return quickly (< 100ms)
- [ ] Can handle 1000+ records efficiently
- [ ] Database has proper indexes

---

## ✅ **Final Verification Checklist**

### **Deployment Readiness**

```
INFRASTRUCTURE
□ Web server configured (Apache/Nginx)
□ PHP 7.4+ installed and configured
□ MySQL 5.7+ installed and running
□ All directories with correct permissions

DATABASE
□ Database created (moiteek_academy)
□ Schema imported successfully
□ Default admin account exists
□ Test student account exists
□ Sample courses loaded
□ All tables have data

SECURITY
□ Passwords are bcrypt hashed
□ PDO prepared statements used
□ Input validation implemented
□ Output sanitization implemented
□ Session timeout configured
□ CSRF protection enabled
□ File upload validation works

FRONTEND
□ Tailwind CSS loaded
□ Custom CSS loaded
□ Font Awesome icons loaded
□ JavaScript app.js loaded
□ Responsive design verified
□ Page animations smooth
□ Forms validate properly
□ Buttons and links functional

FUNCTIONALITY
□ Admin login works
□ Student login works
□ Course browsing works
□ Course details display
□ Enrollment workflow works
□ Payment upload works
□ Dashboard displays stats
□ Search and filter work

VERIFICATION
□ Browser console clean (no errors)
□ Network tab shows 200 status codes
□ Page load times acceptable
□ Mobile responsive tested
□ Database queries fast
□ Documentation complete

READY FOR PRODUCTION
□ All checklist items passed
□ Credentials updated
□ Error logging configured
□ Backups scheduled
□ SSL certificate ready
□ Monitoring configured
□ Support documentation reviewed
```

---

## 🚀 **If Everything Passes**

Congratulations! Your Moiteek Academy installation is:
- ✅ **Fully Functional** - All features working
- ✅ **Secure** - All security measures in place
- ✅ **Optimized** - Performance verified
- ✅ **Production Ready** - Ready to deploy
- ✅ **Well Documented** - Complete guides available

---

## ❌ **If Something Fails**

1. **Check Error Logs:**
   ```bash
   tail -50 /var/log/php_errors.log
   tail -50 /var/log/apache2/moiteek_error.log
   ```

2. **Review Documentation:**
   - QUICKSTART.md (setup issues)
   - DEVELOPMENT.md (code issues)
   - README.md (general help)

3. **Common Issues:**
   - Database connection → Check `config/db.php`
   - File upload fails → Check `/uploads/payments/` permissions
   - Login not working → Verify `admins` and `students` tables
   - Page showing blank → Enable error display temporarily
   - Styling missing → Check if CSS URLs are correct

4. **Verify Setup:**
   ```bash
   # Test database connection
   mysql -u root -p moiteek_academy -e "SHOW TABLES;" 
   
   # Test file permissions
   ls -la c:\xampp\htdocs\moiteek_academy\uploads\
   
   # Test PHP
   php -r "phpinfo();"
   ```

---

## 📞 **Getting Help**

1. Check the relevant documentation file
2. Review inline code comments
3. Check error messages in logs
4. Verify all prerequisites installed
5. Re-run setup steps from QUICKSTART.md

---

**Verification Complete! Your academy is ready to launch! 🎓✨**
