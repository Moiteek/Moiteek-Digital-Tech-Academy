<?php
// app/controllers/AssignmentController.php
class AssignmentController extends Controller {
    public function upload($lessonId, $studentId, $file) {
        // Validate file (type, size, extension)
        $filePath = FileManager::upload($file, 'assignments');
        Assignment::create([
            'lesson_id' => $lessonId,
            'student_id' => $studentId,
            'file_path' => $filePath,
            'file_type' => $file['type'],
        ]);
    }
    public function grade($assignmentId, $grade, $feedback, $adminId) {
        Assignment::grade($assignmentId, $grade, $feedback, $adminId);
    }
}

// app/controllers/QuizController.php
class QuizController extends Controller {
    public function attempt($quizId, $studentId, $answers) {
        $attemptId = QuizAttempt::create($quizId, $studentId);
        foreach ($answers as $qId => $answer) {
            $question = QuizQuestion::get($qId);
            $isCorrect = ($question['question_type'] === 'mcq' && $answer == $question['correct_answer']) ? 1 : 0;
            QuizAnswer::create($attemptId, $qId, $answer, $isCorrect);
        }
        $score = QuizAttempt::calculateScore($attemptId);
        QuizAttempt::updateScore($attemptId, $score);
    }
    public function gradeShortAnswer($answerId, $isCorrect, $feedback, $adminId) {
        QuizAnswer::grade($answerId, $isCorrect, $feedback, $adminId);
    }
}
