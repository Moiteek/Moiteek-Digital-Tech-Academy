<?php
/**
 * Student Course Learning Portal
 * Professional learning interface with lessons, videos, resources, and progress tracking
 */

require_once '../bootstrap.php';

// Check if student is logged in
if (!Auth::isStudentLoggedIn()) {
    header('Location: ../auth/login.php');
    exit;
}

$student_id = Auth::getCurrentUserId();
$course_id = $_GET['id'] ?? 0;

if (!$course_id || !is_numeric($course_id)) {
    header('Location: dashboard.php');
    exit;
}

// Get course details
$courseStmt = $pdo->prepare(
    'SELECT * FROM courses WHERE id = ? AND is_published = 1'
);
$courseStmt->execute([$course_id]);
$course = $courseStmt->fetch(PDO::FETCH_ASSOC);

if (!$course) {
    header('Location: dashboard.php');
    exit;
}

// Check if student is enrolled
$enrollStmt = $pdo->prepare(
    'SELECT e.*, p.progress_percentage, p.completed_modules, p.time_spent
     FROM enrollments e
     LEFT JOIN progress p ON e.student_id = p.student_id AND e.course_id = p.course_id
     WHERE e.student_id = ? AND e.course_id = ? AND e.payment_status = ?'
);
$enrollStmt->execute([$student_id, $course_id, 'approved']);
$enrollment = $enrollStmt->fetch(PDO::FETCH_ASSOC);

if (!$enrollment) {
    header('Location: dashboard.php');
    exit;
}

// Get course modules (lessons) ordered
$modulesStmt = $pdo->prepare(
    'SELECT m.*, 
            (SELECT COUNT(*) FROM module_progress mp WHERE mp.module_id = m.id AND mp.student_id = ? AND mp.is_completed = 1) as is_completed
     FROM course_modules m
     WHERE m.course_id = ? AND m.is_published = 1
     ORDER BY m.sequence_order ASC'
);
$modulesStmt->execute([$student_id, $course_id]);
$modules = $modulesStmt->fetchAll(PDO::FETCH_ASSOC);

// Get currently selected module (or first one)
$current_module_id = $_GET['module_id'] ?? ($modules[0]['id'] ?? null);

$currentModule = null;
$moduleIndex = 0;
foreach ($modules as $i => $module) {
    if ($module['id'] == $current_module_id) {
        $currentModule = $module;
        $moduleIndex = $i;
        break;
    }
}

if (!$currentModule && !empty($modules)) {
    $currentModule = $modules[0];
    $moduleIndex = 0;
}

// Get course resources for downloads
$resourcesStmt = $pdo->prepare(
    'SELECT * FROM course_resources 
     WHERE course_id = ? AND is_published = 1
     ORDER BY sequence_order ASC'
);
$resourcesStmt->execute([$course_id]);
$resources = $resourcesStmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate completion percentage
$completedModules = 0;
foreach ($modules as $module) {
    if ($module['is_completed']) {
        $completedModules++;
    }
}
$completionPercentage = !empty($modules) ? round(($completedModules / count($modules)) * 100) : 0;

// Extract YouTube video ID from URL
function extractYouTubeId($url) {
    if (empty($url)) return null;
    
    if (strpos($url, 'youtube.com/watch?v=') !== false) {
        parse_str(parse_url($url, PHP_URL_QUERY), $query);
        return $query['v'] ?? null;
    } elseif (strpos($url, 'youtu.be/') !== false) {
        return substr(parse_url($url, PHP_URL_PATH), 1);
    } elseif (preg_match('/^[a-zA-Z0-9_-]{11}$/', $url)) {
        return $url;
    }
    return null;
}

// Handle module completion toggle
if ($_METHOD === 'POST' && isset($_POST['action']) && $_POST['action'] === 'toggle_complete') {
    if (CSRF::validateRequest()) {
        $module_id = $_POST['module_id'] ?? null;
        
        if ($module_id) {
            $checkStmt = $pdo->prepare(
                'SELECT id FROM module_progress WHERE student_id = ? AND module_id = ?'
            );
            $checkStmt->execute([$student_id, $module_id]);
            
            if ($checkStmt->fetch()) {
                $updateStmt = $pdo->prepare(
                    'UPDATE module_progress SET is_completed = 1, completed_at = CURRENT_TIMESTAMP 
                     WHERE student_id = ? AND module_id = ?'
                );
            } else {
                $insertStmt = $pdo->prepare(
                    'INSERT INTO module_progress (student_id, module_id, course_id, is_completed, completed_at)
                     VALUES (?, ?, ?, 1, CURRENT_TIMESTAMP)'
                );
                $insertStmt->execute([$student_id, $module_id, $course_id]);
            }
            
            header('Location: course.php?id=' . $course_id . '&module_id=' . $module_id);
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($course['title']); ?> - Learning Portal</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .lesson-item {
            transition: all 0.3s ease;
        }
        .lesson-item:hover {
            transform: translateX(5px);
        }
        .lesson-item.active {
            background: linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%);
            color: white;
        }
        .progress-fill {
            transition: width 0.5s ease;
        }
    </style>
</head>
<body class="bg-gray-900">
    <!-- Header -->
    <header class="bg-gray-800 border-b border-gray-700 sticky top-0 z-50">
        <div class="max-w-7xl mx-auto flex items-center justify-between p-4">
            <div class="flex items-center gap-4">
                <a href="dashboard.php" class="text-gray-300 hover:text-white transition">
                    <i class="fas fa-arrow-left text-xl"></i>
                </a>
                <div>
                    <h1 class="text-white font-bold"><?php echo htmlspecialchars($course['title']); ?></h1>
                    <p class="text-gray-400 text-sm"><?php echo htmlspecialchars($course['instructor_name'] ?? 'Instructor'); ?></p>
                </div>
            </div>
            <div class="flex items-center gap-4">
                <div class="text-right">
                    <div class="text-white font-bold"><?php echo $completionPercentage; ?>%</div>
                    <div class="text-gray-400 text-sm">Complete</div>
                </div>
                <a href="../auth/logout.php" class="text-gray-300 hover:text-red-400 transition">
                    <i class="fas fa-sign-out-alt text-xl"></i>
                </a>
            </div>
        </div>
    </header>

    <div class="max-w-7xl mx-auto">
        <div class="grid grid-cols-1 lg:grid-cols-4 gap-6 p-4">
            <!-- Main Content -->
            <div class="lg:col-span-3">
                <!-- Video Player Container -->
                <div class="bg-black rounded-lg overflow-hidden mb-6 shadow-2xl">
                    <?php if ($currentModule && $youtubeId = extractYouTubeId($currentModule['video_url'])): ?>
                        <div class="aspect-video bg-black">
                            <iframe 
                                width="100%" 
                                height="100%" 
                                src="https://www.youtube.com/embed/<?php echo htmlspecialchars($youtubeId); ?>?rel=0&modestbranding=1" 
                                frameborder="0" 
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                                allowfullscreen>
                            </iframe>
                        </div>
                    <?php else: ?>
                        <div class="aspect-video bg-gradient-to-br from-gray-700 to-gray-800 flex items-center justify-center">
                            <div class="text-center">
                                <i class="fas fa-video text-6xl text-gray-500 mb-4"></i>
                                <p class="text-gray-400">No video available for this lesson</p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Lesson Details -->
                <div class="bg-gray-800 rounded-lg p-6 mb-6">
                    <div class="flex items-start justify-between mb-4">
                        <div>
                            <h2 class="text-2xl font-bold text-white"><?php echo htmlspecialchars($currentModule['title'] ?? 'Select a Lesson'); ?></h2>
                            <?php if ($currentModule && $currentModule['duration']): ?>
                                <p class="text-gray-400 text-sm mt-2">
                                    <i class="fas fa-clock mr-2"></i>Duration: <?php echo $currentModule['duration']; ?> minutes
                                </p>
                            <?php endif; ?>
                        </div>
                        <?php if ($currentModule): ?>
                            <form method="POST" class="flex gap-2">
                                <?php echo CSRF::generateTokenField(); ?>
                                <input type="hidden" name="action" value="toggle_complete">
                                <input type="hidden" name="module_id" value="<?php echo $currentModule['id']; ?>">
                                <button type="submit" class="<?php echo $currentModule['is_completed'] ? 'bg-green-600 hover:bg-green-700' : 'bg-blue-600 hover:bg-blue-700'; ?> text-white px-4 py-2 rounded-lg transition font-semibold">
                                    <i class="fas fa-<?php echo $currentModule['is_completed'] ? 'check' : 'play'; ?> mr-2"></i>
                                    <?php echo $currentModule['is_completed'] ? 'Completed' : 'Mark Complete'; ?>
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>

                    <!-- Lesson Description -->
                    <?php if ($currentModule && $currentModule['description']): ?>
                        <div class="border-t border-gray-700 pt-6">
                            <h3 class="text-lg font-semibold text-white mb-3">Lesson Overview</h3>
                            <p class="text-gray-300 leading-relaxed"><?php echo nl2br(htmlspecialchars($currentModule['description'])); ?></p>
                        </div>
                    <?php endif; ?>

                    <!-- Lesson Content -->
                    <?php if ($currentModule && $currentModule['content']): ?>
                        <div class="border-t border-gray-700 pt-6 mt-6">
                            <h3 class="text-lg font-semibold text-white mb-3">Content</h3>
                            <div class="text-gray-300 prose prose-invert max-w-none">
                                <?php echo nl2br(htmlspecialchars($currentModule['content'])); ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Navigation Buttons -->
                <?php if (count($modules) > 1): ?>
                    <div class="flex gap-4 justify-between">
                        <?php if ($moduleIndex > 0): ?>
                            <a href="course.php?id=<?php echo $course_id; ?>&module_id=<?php echo $modules[$moduleIndex - 1]['id']; ?>" 
                               class="flex-1 bg-gray-700 hover:bg-gray-600 text-white px-6 py-3 rounded-lg transition font-semibold text-center">
                                <i class="fas fa-chevron-left mr-2"></i>Previous Lesson
                            </a>
                        <?php else: ?>
                            <div class="flex-1"></div>
                        <?php endif; ?>

                        <?php if ($moduleIndex < count($modules) - 1): ?>
                            <a href="course.php?id=<?php echo $course_id; ?>&module_id=<?php echo $modules[$moduleIndex + 1]['id']; ?>" 
                               class="flex-1 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg transition font-semibold text-center">
                                Next Lesson<i class="fas fa-chevron-right ml-2"></i>
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Sidebar -->
            <div class="lg:col-span-1">
                <!-- Progress Card -->
                <div class="bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg p-6 mb-6 text-white">
                    <h3 class="text-lg font-bold mb-4">Course Progress</h3>
                    <div class="mb-4">
                        <div class="flex justify-between items-center mb-2">
                            <span class="text-sm font-semibold"><?php echo $completedModules; ?>/<?php echo count($modules); ?> lessons</span>
                            <span class="text-2xl font-bold"><?php echo $completionPercentage; ?>%</span>
                        </div>
                        <div class="w-full bg-white/20 rounded-full h-3 overflow-hidden">
                            <div class="bg-white h-3 progress-fill" style="width: <?php echo $completionPercentage; ?>%"></div>
                        </div>
                    </div>
                    <?php if ($completionPercentage === 100): ?>
                        <div class="bg-green-500/30 border border-green-400 rounded-lg p-3 text-sm text-center">
                            <i class="fas fa-crown mr-2"></i>Course Completed!
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Lessons List -->
                <div class="bg-gray-800 rounded-lg overflow-hidden">
                    <div class="bg-gray-700 px-6 py-4 border-b border-gray-600">
                        <h3 class="text-white font-bold">
                            <i class="fas fa-list mr-2"></i>Lessons (<?php echo count($modules); ?>)
                        </h3>
                    </div>
                    <div class="max-h-96 overflow-y-auto">
                        <?php foreach ($modules as $i => $module): ?>
                            <a href="course.php?id=<?php echo $course_id; ?>&module_id=<?php echo $module['id']; ?>"
                               class="lesson-item block px-6 py-4 border-b border-gray-700 last:border-0 <?php echo ($module['id'] == $currentModule['id']) ? 'active' : 'hover:bg-gray-700'; ?>">
                                <div class="flex items-start gap-3">
                                    <div class="flex-shrink-0 mt-1">
                                        <?php if ($module['is_completed']): ?>
                                            <i class="fas fa-check-circle text-green-400"></i>
                                        <?php else: ?>
                                            <i class="fas fa-play-circle text-gray-400"></i>
                                        <?php endif; ?>
                                    </div>
                                    <div class="flex-1 min-w-0">
                                        <p class="text-sm font-semibold <?php echo ($module['id'] == $currentModule['id']) ? 'text-white' : 'text-gray-300'; ?>">
                                            <?php echo str_pad($i + 1, 2, '0', STR_PAD_LEFT); ?>. <?php echo htmlspecialchars(substr($module['title'], 0, 25)); ?>
                                        </p>
                                        <?php if ($module['duration']): ?>
                                            <p class="text-xs <?php echo ($module['id'] == $currentModule['id']) ? 'text-blue-100' : 'text-gray-500'; ?>">
                                                <?php echo $module['duration']; ?> min
                                            </p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Resources Section -->
                <?php if (!empty($resources)): ?>
                    <div class="mt-6 bg-gray-800 rounded-lg overflow-hidden">
                        <div class="bg-gray-700 px-6 py-4 border-b border-gray-600">
                            <h3 class="text-white font-bold">
                                <i class="fas fa-download mr-2"></i>Resources
                            </h3>
                        </div>
                        <div class="max-h-64 overflow-y-auto p-4 space-y-2">
                            <?php foreach ($resources as $resource): ?>
                                <a href="<?php echo htmlspecialchars($resource['is_external'] ? $resource['file_url'] : '../uploads/resources/' . $resource['file_path']); ?>"
                                   target="<?php echo $resource['is_external'] ? '_blank' : '_self'; ?>"
                                   class="flex items-center gap-3 p-3 bg-gray-700 hover:bg-gray-600 rounded-lg transition group">
                                    <i class="fas fa-<?php echo 
                                        ($resource['resource_type'] === 'pdf') ? 'file-pdf' :
                                        ($resource['resource_type'] === 'book') ? 'book' :
                                        ($resource['resource_type'] === 'code') ? 'code' :
                                        ($resource['resource_type'] === 'template') ? 'file' :
                                        'download';
                                    ?> text-gray-300 group-hover:text-white transition"></i>
                                    <div class="flex-1 min-w-0">
                                        <p class="text-sm font-semibold text-gray-300 group-hover:text-white truncate">
                                            <?php echo htmlspecialchars(substr($resource['title'], 0, 20)); ?>
                                        </p>
                                        <p class="text-xs text-gray-500">
                                            <?php echo strtoupper($resource['resource_type']); ?>
                                        </p>
                                    </div>
                                    <i class="fas fa-external-link-alt text-gray-500 group-hover:text-white transition text-xs"></i>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>
                                    <div class="flex-1">
                                        <p class="font-bold text-gray-900">Module <?= $i ?>: Course Content</p>
                                        <p class="text-sm text-gray-600"><?= rand(30, 120) ?> minutes</p>
                                    </div>
                                    <i class="fas fa-chevron-right text-gray-400"></i>
                                </div>
                            </div>
                        <?php endfor; ?>
                    </div>
                </div>
            </div>

            <!-- Sidebar -->
            <div class="space-y-6">
                <!-- Course Info Card -->
                <div class="bg-white rounded-xl shadow-md p-6">
                    <h3 class="text-lg font-bold text-gray-900 mb-4">Course Info</h3>
                    <div class="space-y-4">
                        <div>
                            <p class="text-xs text-gray-600 font-semibold">INSTRUCTOR</p>
                            <p class="font-semibold text-gray-900"><?= htmlspecialchars($course['instructor_name']) ?></p>
                        </div>
                        <div>
                            <p class="text-xs text-gray-600 font-semibold">DURATION</p>
                            <p class="font-semibold text-gray-900"><?= htmlspecialchars($course['duration']) ?></p>
                        </div>
                        <div>
                            <p class="text-xs text-gray-600 font-semibold">MODULES</p>
                            <p class="font-semibold text-gray-900"><?= $course['total_modules'] ?> modules</p>
                        </div>
                        <div>
                            <p class="text-xs text-gray-600 font-semibold">LEVEL</p>
                            <p class="font-semibold text-gray-900"><?= ucfirst($course['level']) ?></p>
                        </div>
                    </div>
                </div>

                <!-- Enrolled Status -->
                <div class="bg-green-50 border border-green-200 rounded-xl p-6">
                    <div class="flex items-center gap-3 mb-4">
                        <i class="fas fa-check-circle text-2xl text-green-600"></i>
                        <span class="text-sm font-bold text-green-700">Enrolled</span>
                    </div>
                    <p class="text-sm text-green-700">
                        <i class="fas fa-calendar mr-1"></i>
                        Enrolled on <?= Helper::formatDate($enrollment['enrollment_date']) ?>
                    </p>
                </div>

                <!-- Resources -->
                <div class="bg-white rounded-xl shadow-md p-6">
                    <h3 class="text-lg font-bold text-gray-900 mb-4">Resources</h3>
                    <div class="space-y-2">
                        <a href="#" class="flex items-center gap-2 p-3 rounded-lg hover:bg-gray-100 transition text-gray-700 font-semibold">
                            <i class="fas fa-download text-blue-600"></i>Course Materials
                        </a>
                        <a href="#" class="flex items-center gap-2 p-3 rounded-lg hover:bg-gray-100 transition text-gray-700 font-semibold">
                            <i class="fas fa-file-pdf text-red-600"></i>Course PDF
                        </a>
                        <a href="#" class="flex items-center gap-2 p-3 rounded-lg hover:bg-gray-100 transition text-gray-700 font-semibold">
                            <i class="fas fa-comments text-purple-600"></i>Discussion
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>