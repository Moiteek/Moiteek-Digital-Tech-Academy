# MVC-like Modular Structure Proposal for PHP LMS

## /app
- /controllers
  - AuthController.php
  - CourseController.php
  - StudentController.php
  - AdminController.php
  - InstructorController.php (optional)
  - PaymentController.php
  - AssignmentController.php
  - QuizController.php
- /models
  - User.php
  - Student.php
  - Admin.php
  - Instructor.php (optional)
  - Course.php
  - Enrollment.php
  - Payment.php
  - Assignment.php
  - Quiz.php
  - Certificate.php
- /views
  - /auth
  - /admin
  - /student
  - /instructor (optional)
  - /partials (header, footer, nav, modals)

## /public
- index.php (front controller)
- /assets (css, js, images)
- .htaccess (security, routing)

## /config
- db.php
- app.php
- routes.php
- .env

## /core
- App.php (router/dispatcher)
- Controller.php (base)
- Model.php (base)
- View.php (base)
- Session.php
- CSRF.php
- Auth.php
- Validator.php
- Response.php
- Email.php
- FileManager.php

## /sql
- database.sql

---

- All requests routed through public/index.php
- Controllers handle logic, call Models, and render Views
- Models use prepared statements only
- Views are pure HTML/Tailwind/JS, no logic
- Core contains reusable classes/utilities
- Config holds environment and DB settings

> This structure is scalable, secure, and maintainable for a modern PHP LMS.
