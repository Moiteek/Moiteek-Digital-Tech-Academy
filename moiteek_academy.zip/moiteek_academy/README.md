# 🎓 Moiteek Academy - Production-Ready Online Learning Platform

A complete, modern online academy platform built with PHP 7.4+, MySQL, Tailwind CSS, and JavaScript. Features student enrollment, course management, payment processing, and an intuitive admin dashboard.

---

## ✨ **Key Features**

### 👥 **User Management**
- **Student Registration** with email verification and file upload
- **Admin & Student Authentication** with bcrypt password hashing
- **Student Approval Workflow** with admin review
- **Role-Based Access Control** (Admin/Super Admin/Student)
- **Session Management** with 30-minute timeout

### 📚 **Course Management**
- **Comprehensive Course Catalog** with search and filtering
- **Course Details Page** with curriculum, instructor info, and requirements
- **Module Management** with video content and resources
- **Progress Tracking** per student per course
- **Course Statistics** and enrollment metrics

### 💰 **Payment System**
- **Manual Payment Confirmation** workflow
- **Payment Proof Upload** with file validation
- **Payment Status Tracking** (Pending/Confirmed/Failed)
- **Revenue Dashboard** with total earnings
- **Payment History** with detailed records

### 📊 **Admin Dashboard**
- **Real-time Statistics** on students, courses, enrollments
- **Student Management** with approval workflow
- **Payment Confirmation Interface** with filtering
- **Enrollment Tracking** and monitoring
- **Quick Actions** for common tasks

### 🎓 **Student Dashboard**
- **Enrolled Courses Display** with progress bars
- **Course Status Tracking** (In Progress/Completed)
- **Quick Actions** (Enroll New, View Certificates)
- **Learning Statistics** (Total Enrolled, Completed, etc.)
- **Certificate Management**

### 🎨 **Premium UI/UX**
- **Tailwind CSS 3** for modern, responsive design
- **Udemy-like Interface** with professional styling
- **Smooth Animations** and transitions
- **Mobile Responsive** design (mobile-first approach)
- **Accessibility Compliant** with semantic HTML
- **Dark Mode Ready** CSS variables

### ⚡ **JavaScript Interactivity**
- **Real-time Search & Filtering** with debouncing
- **Form Validation** with error messaging
- **Smooth Scroll Navigation**
- **Notification System** (success/error/info)
- **Confirmation Dialogs** for critical actions
- **Progress Bar Animations**

---

## 🏗️ **Architecture Overview**

```
moiteek_academy/
├── config/
│   └── db.php                    # Database configuration & PDO setup
├── includes/
│   ├── Auth.php                  # Authentication system (bcrypt)
│   ├── Validator.php             # Input validation & sanitization
│   ├── Response.php              # Standardized response handling
│   ├── Database.php              # Database helper functions
│   └── FileManager.php           # File upload & management
├── auth/
│   ├── login.php                 # Student/Admin login
│   ├── register.php              # Student registration
│   └── logout.php                # Logout handler
├── admin/
│   ├── dashboard.php             # Admin home page
│   ├── students.php              # Student management
│   ├── student_detail.php        # Individual student info
│   ├── payments.php              # Payment confirmation
│   ├── payment_detail.php        # Payment details
│   ├── courses.php               # Course management
│   └── enrollments.php           # Enrollment tracking
├── student/
│   ├── dashboard.php             # Student home page
│   ├── course.php                # Course learning interface
│   └── profile.php               # (Coming Soon) Profile settings
├── assets/
│   ├── css/custom.css            # Custom styles & animations
│   └── js/app.js                 # Frontend utilities & interactivity
├── sql/
│   └── database.sql              # Complete database schema
├── uploads/
│   └── payments/                 # Payment proof storage
├── bootstrap.php                 # Application initialization
├── index.php                     # Homepage
├── courses.php                   # Course listing
├── course_details.php            # Course details page
└── README.md                     # This file
```

---

## 🚀 **Getting Started**

### **Prerequisites**
- PHP 7.4 or higher
- MySQL 5.7+
- Git (optional)
- Web server (Apache/Nginx)

### **Installation**

1. **Clone or Extract the Project**
   ```bash
   # Navigate to your web root
   cd c:\xampp\htdocs
   # Or for Linux/Mac: /var/www/html
   
   # Extract the zip file or clone the repository
   ```

2. **Create Database**
   ```bash
   # Open phpMyAdmin (http://localhost/phpmyadmin)
   # Create a new database: moiteek_academy
   # Import the SQL file: sql/database.sql
   ```

   Or via command line (MySQL):
   ```bash
   mysql -u root -p moiteek_academy < sql/database.sql
   ```

3. **Configure Database Connection**
   Edit `config/db.php` and update credentials:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_USER', 'root');
   define('DB_PASS', 'your_password');
   define('DB_NAME', 'moiteek_academy');
   ```

4. **Create Uploads Directory**
   ```bash
   # Create payment uploads folder
   mkdir -p uploads/payments
   chmod 755 uploads/payments
   ```

5. **Start Your Server**
   ```bash
   # XAMPP: Start Apache & MySQL from XAMPP Control Panel
   # Or access: http://localhost/moiteek_academy
   ```

---

## 👤 **Default Credentials**

### **Admin Login**
- **Email**: admin@moiteek.com
- **Password**: Admin@123
- **URL**: http://localhost/moiteek_academy/auth/login.php

### **Test Student**
- **Email**: student@test.com
- **Username**: student123
- **Password**: Student@123
- **Status**: Approved (ready to enroll)

---

## 🔐 **Security Features**

### **Authentication**
- ✅ **Bcrypt Password Hashing** (PASSWORD_BCRYPT, cost 10)
- ✅ **PDO Prepared Statements** for SQL injection prevention
- ✅ **Session Timeout** (30 minutes inactivity)
- ✅ **Secure Cookies** (httponly, samesite=Strict)
- ✅ **CSRF Protection** headers (X-Frame-Options, CSP)

### **Validation**
- ✅ **Server-side Input Validation** for all forms
- ✅ **Email Uniqueness** checking
- ✅ **File Type & Size Validation** (5MB limit)
- ✅ **Sanitization** of user inputs
- ✅ **Password Strength** requirements

### **Data Protection**
- ✅ **Foreign Key Constraints** for referential integrity
- ✅ **Automatic Timestamps** (created_at, updated_at)
- ✅ **Soft Deletes** support in schema
- ✅ **Database Backups** recommended

---

## 📖 **Usage Guide**

### **Student Workflow**

1. **Register**
   - Go to: `auth/register.php`
   - Fill form: Name, Email, Phone, Username, Password
   - Upload payment proof (JPG/PNG/PDF)
   - Submit and wait for admin approval

2. **Login**
   - Go to: `auth/login.php`
   - Enter email/username and password
   - Access dashboard after approval

3. **Browse Courses**
   - View all courses at: `courses.php`
   - Search by title or filter by level/category
   - Click course to view details

4. **Enroll in Course**
   - View course details page
   - Click "Enroll Now" button
   - Enrollment created (payment confirmation pending)

5. **Learn**
   - Access enrolled courses from dashboard
   - View course lessons and resources
   - Track progress

### **Admin Workflow**

1. **Login**
   - Go to: `auth/login.php`
   - Use admin credentials
   - Access admin dashboard

2. **Approve Students**
   - Navigate: Admin Dashboard → Students
   - View pending student registrations
   - Approve or reject with notes

3. **Confirm Payments**
   - Navigate: Admin Dashboard → Payments
   - Review payment proofs
   - Confirm or reject payments

4. **Manage Courses**
   - Navigate: Admin Dashboard → Courses
   - View course list with stats
   - (Coming Soon) Create/Edit/Delete courses

5. **View Analytics**
   - Dashboard shows: Total students, courses, enrollments
   - Revenue tracking and summaries
   - Recent activity timeline

---

## 🗄️ **Database Schema**

### **Core Tables**

#### **admins**
```sql
- id (Primary Key)
- fullname, email (unique), password (bcrypt)
- phone, role (super_admin/admin), status
- last_login, created_at
```

#### **students**
```sql
- id (Primary Key)
- fullname, email (unique), username (unique)
- password (bcrypt), profile_picture
- status (pending/approved/rejected/suspended)
- is_active, created_at
```

#### **courses**
```sql
- id (Primary Key)
- title (unique), slug, description, price
- thumbnail, level, category
- total_modules, total_lessons
- is_published, created_at
```

#### **enrollments**
```sql
- id (Primary Key)
- student_id (FK), course_id (FK)
- payment_status (pending/confirmed/failed)
- payment_proof, enrollment_date
```

#### **payments**
```sql
- id (Primary Key)
- enrollment_id (FK), amount, payment_status
- confirmed_by, payment_date, created_at
```

#### **progress**
```sql
- id (Primary Key)
- student_id (FK), course_id (FK)
- progress_percentage, time_spent
- completed_modules, last_accessed
```

#### **course_modules** & **certificates** & **course_content tables** also included

---

## 🎨 **Customization**

### **Change Colors**
Edit `assets/css/custom.css` CSS variables:
```css
:root {
    --primary-color: #3b82f6;      /* Blue */
    --secondary-color: #a855f7;    /* Purple */
    --success-color: #10b981;      /* Green */
    --danger-color: #ef4444;       /* Red */
    ...
}
```

### **Modify Styling**
- **Tailwind Classes**: Used extensively (responsive, utility-first)
- **Custom CSS**: `assets/css/custom.css` for animations & utilities
- **Bootstrap**: No bootstrap dependency (lightweight)

### **Add New Features**
1. Create new PHP file in appropriate folder
2. Include `bootstrap.php` for initialization
3. Use helper classes (Auth, Validator, Database, etc.)
4. Follow existing code patterns for consistency

---

## 🔧 **API Endpoints (Future Mobile App)**

Ready for API transformation with these endpoints planned:

```
POST   /api/auth/login              - Student login
POST   /api/auth/register           - Student registration
POST   /api/auth/logout             - Logout

GET    /api/courses                 - List courses
GET    /api/courses/{id}            - Course details
POST   /api/enrollments             - Enroll in course
GET    /api/enrollments             - User enrollments

GET    /api/progress/{courseId}     - Course progress
PUT    /api/progress/{courseId}     - Update progress

GET    /api/payments                - Payment history
POST   /api/payments/confirm        - Confirm payment

GET    /api/admin/students          - List students
GET    /api/admin/payments          - List payments
POST   /api/admin/payments/{id}/approve - Approve payment
```

To implement: Create `api/` folder with endpoint files, return JSON responses via `Response::json()`.

---

## 📋 **Configuration**

### **Session Settings** (`config/db.php`)
```php
session_set_cookie_params([
    'lifetime' => 1800,              // 30 minutes
    'httponly' => true,
    'samesite' => 'Strict'
]);
```

### **File Upload Settings** (`includes/FileManager.php`)
```php
const MAX_FILE_SIZE = 5242880;       // 5MB
const ALLOWED_TYPES = ['jpg', 'jpeg', 'png', 'pdf'];
const UPLOAD_DIR = 'uploads/payments/';
```

### **Password Requirements** (`includes/Validator.php`)
```
- Minimum 8 characters
- At least 1 uppercase letter
- At least 1 lowercase letter
- At least 1 number
- At least 1 special character (@$!%*?&)
```

---

## 🐛 **Troubleshooting**

| Issue | Solution |
|-------|----------|
| **"Database connection failed"** | Check DB credentials in `config/db.php`, ensure MySQL is running |
| **"Permission denied" (uploads)** | Run: `chmod 755 uploads/payments` |
| **"Blank page"** | Enable PHP error reporting, check Apache error logs |
| **"Login not working"** | Ensure database is imported properly, check `admins` table |
| **"Session timeout too quick"** | Increase `'lifetime'` in `config/db.php` |
| **"File upload fails"** | Check file size < 5MB and type is jpg/jpeg/png/pdf |

---

## 📚 **Code Examples**

### **Using Auth Class**
```php
require 'bootstrap.php';

// Login student
$email = $_POST['email'];
$password = $_POST['password'];

if (Auth::loginStudent($email, $password)) {
    Response::redirect('/student/dashboard.php');
} else {
    Response::error('Invalid credentials');
}
```

### **Using Validator**
```php
$validator = new Validator();

$validator->validateEmail($email);
$validator->validatePassword($password);
$validator->validateFullName($name);

if ($validator->getErrors()) {
    Response::error($validator->getErrors());
}
```

### **Using Database Helper**
```php
$database = new Database();
$database->setPDO($pdo);

// Get all courses
$courses = $database->getCourses();

// Get user enrollments
$enrollments = $database->getStudentEnrollments($studentId);
```

### **Using FileManager**
```php
$fileManager = new FileManager();

try {
    $filename = $fileManager->uploadFile($_FILES['proof']);
    // Insert into database
} catch (Exception $e) {
    Response::error($e->getMessage());
}
```

---

## 🚢 **Deployment Checklist**

- [ ] Change default admin password
- [ ] Update database credentials
- [ ] Enable error logging (disable display)
- [ ] Set up HTTPS/SSL certificate
- [ ] Configure email notifications (optional)
- [ ] Test all workflows (registration, login, enrollment, payment)
- [ ] Back up database
- [ ] Set file permissions correctly
- [ ] Monitor server logs
- [ ] Set up automated backups

---

## 📈 **Future Enhancements**

### **Phase 2 - Upcoming Features**
- [ ] Email notification system
- [ ] Video content streaming
- [ ] Certificate PDF generation
- [ ] Discussion forum per course
- [ ] Instructor dashboard
- [ ] Advanced analytics & reports
- [ ] Mobile app (using REST API)
- [ ] Stripe/PayPal integration
- [ ] Two-factor authentication
- [ ] Student referral system

### **Phase 3 - Enterprise Features**
- [ ] Bulk student import (CSV)
- [ ] Course templates
- [ ] Subscription model
- [ ] White-label options
- [ ] Advanced reporting & BI
- [ ] Corporate training mode
- [ ] LMS standards (SCORM/xAPI)

---

## 📞 **Support & Contact**

For issues or feature requests:
- **Email**: support@moiteek.com
- **Website**: https://moiteek.com
- **Documentation**: See this README and inline code comments

---

## 📄 **License**

This project is proprietary to Moiteek Digital Tech Academy. All rights reserved.

---

## ✅ **Verification Checklist**

After setup, verify:

- [ ] Homepage loads at `http://localhost/moiteek_academy/`
- [ ] Can log in with admin credentials
- [ ] Can log in with test student credentials
- [ ] Student registration works and file uploads successfully
- [ ] Can view courses list and search functionality works
- [ ] Can view course details and enrollment card
- [ ] Admin dashboard shows statistics
- [ ] Payment confirmation interface works
- [ ] Student dashboard displays enrolled courses
- [ ] Mobile responsive on all pages
- [ ] No PHP errors in logs
- [ ] Database queries execute successfully

---

## 🎉 **Congratulations!**

You now have a **production-ready Online Academy Platform**. Start by:
1. Logging in as admin
2. Reviewing student approvals
3. Managing courses
4. Confirming payments
5. Monitoring student progress

**Happy Teaching! 📚✨**

---

*Last Updated: 2024*  
*Version: 1.0.0 - Production Ready*
