# DEVELOPER_GUIDE.md - Using Security Features

Quick reference guide for developers working with Moiteek Academy security features.

---

## 🔐 **Authentication & Password Hashing**

### **Hash a Password (During Registration)**

```php
<?php
require_once 'bootstrap.php';

// Get user password from form
$password = $_POST['password'];

// Validate password strength FIRST
$validation = Validator::validatePassword($password);
if (!$validation['valid']) {
    // Show error: $validation['errors'] contains any issues
    $errors = implode('<br>', $validation['errors']);
    echo "Password requirements not met: $errors";
}

// Hash using bcrypt (cost 10)
$hashed = Auth::hashPassword($password);

// Store $hashed in database (NOT the original password)
// e.g., $pdo->prepare('INSERT INTO admins (password) VALUES (?)')->execute([$hashed]);
?>
```

---

### **Verify a Password (During Login)**

```php
<?php
require_once 'bootstrap.php';

$email = $_POST['email'];
$password = $_POST['password'];

// Get user from database
$stmt = $pdo->prepare('SELECT id, password FROM students WHERE email = ?');
$stmt->execute([$email]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

if ($student && Auth::verifyPassword($password, $student['password'])) {
    // Password is correct
    
    // Check if need to rehash (bcrypt cost increased)
    if (Auth::passwordNeedsRehash($student['password'])) {
        $newHash = Auth::hashPassword($password);
        $updateStmt = $pdo->prepare('UPDATE students SET password = ? WHERE id = ?');
        $updateStmt->execute([$newHash, $student['id']]);
    }
} else {
    // Password is wrong
    echo "Invalid credentials";
}
?>
```

---

### **Validate Password Strength**

```php
<?php
require_once 'bootstrap.php';

$password = $_POST['password'];

$validation = Validator::validatePassword($password);

if (!$validation['valid']) {
    echo "Errors: " . implode('<br>', $validation['errors']);
    // Will show things like:
    // - Password must be at least 8 characters long
    // - Password must contain uppercase letters
    // - Password must contain lowercase letters
    // - Password must contain numbers
    // - Password must contain special characters (@$!%*?&)
} else {
    echo "Password is strong!";
    $hashed = Auth::hashPassword($password);
}
?>
```

---

## 🔑 **CSRF Token Protection**

### **In HTML Forms**

```html
<!-- Login Form with CSRF Protection -->
<form method="POST" action="login.php">
    <input type="email" name="email" required>
    <input type="password" name="password" required>
    
    <!-- Add CSRF token field -->
    <?php echo Auth::CSRF::generateTokenField(); ?>
    
    <button type="submit">Login</button>
</form>
```

---

### **Validate CSRF Token (PHP)**

```php
<?php
require_once 'bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate CSRF token
    if (!CSRF::validateRequest()) {
        http_response_code(403);
        die('Security token invalid. Please try again.');
    }
    
    // Token is valid, process form
    // ... your code ...
}
?>
```

---

### **During AJAX Requests**

```javascript
// Get CSRF token from page
const token = document.querySelector('input[name="csrf_token"]').value;

// Include in AJAX request
fetch('/api/update.php', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': token
    },
    body: JSON.stringify({
        // Your data
    })
})
.then(response => response.json())
.then(data => console.log(data));
```

**PHP will validate:**
```php
if (!CSRF::validateRequest()) {
    http_response_code(403);
    echo json_encode(['error' => 'Invalid CSRF token']);
    exit;
}
```

---

## 📧 **Email Verification**

### **Generate Verification Token**

```php
<?php
require_once 'bootstrap.php';

// After user registers
$student_id = 123;
$email = 'user@example.com';

// Generate 24-hour token
$token = Auth::generateEmailVerificationToken($student_id, $email);

// Send verification email
Email::sendEmailVerification($email, $student_id, $token);

// Redirect to "Check your email" message
header('Location: check_email.php');
?>
```

---

### **Handle Email Verification Link**

Create `auth/verify-email.php`:

```php
<?php
require_once '../bootstrap.php';

if (!isset($_GET['token'])) {
    die('No verification token provided');
}

$token = $_GET['token'];

// Verify token and activate student
$result = Auth::verifyEmailToken($token);

if ($result) {
    echo "✓ Email verified successfully! <a href='login.php'>Login now</a>";
} else {
    echo "✗ Verification failed. Token may have expired. <a href='resend_verification.php'>Request new link</a>";
}
?>
```

---

## 🔄 **Password Reset**

### **Request Password Reset**

Create `auth/forgot-password.php`:

```php
<?php
require_once '../bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!CSRF::validateRequest()) {
        die('Invalid CSRF token');
    }
    
    $email = $_POST['email'];
    
    // Check if user exists
    $stmt = $pdo->prepare(
        'SELECT id, email FROM students WHERE email = ? UNION 
         SELECT id, email FROM admins WHERE email = ?'
    );
    $stmt->execute([$email, $email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user) {
        // Generate reset token (1-hour expiry)
        $token = Auth::generatePasswordResetToken(
            $user['id'], 
            $user['email'],
            'student'  // or 'admin'
        );
        
        // Send reset email
        Email::sendPasswordReset($user['email'], $token);
        
        echo "Check your email for password reset link";
    } else {
        echo "Email not found";
    }
}
?>

<form method="POST">
    <input type="email" name="email" placeholder="Enter your email" required>
    <?php echo CSRF::generateTokenField(); ?>
    <button type="submit">Reset Password</button>
</form>
```

---

### **Handle Reset Password Link**

Create `auth/reset-password.php`:

```php
<?php
require_once '../bootstrap.php';

if (!isset($_GET['token'])) {
    die('Invalid reset link');
}

$token = $_GET['token'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!CSRF::validateRequest()) {
        die('Invalid CSRF token');
    }
    
    $new_password = $_POST['password'];
    $confirm_password = $_POST['password_confirm'];
    
    // Validate passwords match
    if ($new_password !== $confirm_password) {
        echo "Passwords don't match";
        exit;
    }
    
    // Validate password strength
    $validation = Validator::validatePassword($new_password);
    if (!$validation['valid']) {
        echo "Password too weak: " . implode(', ', $validation['errors']);
        exit;
    }
    
    // Reset password
    if (Auth::resetPasswordWithToken($token, $new_password)) {
        echo "Password updated! <a href='login.php'>Login now</a>";
    } else {
        echo "Reset link expired or invalid";
    }
}
?>

<form method="POST">
    <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
    <input type="password" name="password" placeholder="New password" required>
    <input type="password" name="password_confirm" placeholder="Confirm password" required>
    <?php echo CSRF::generateTokenField(); ?>
    <button type="submit">Reset Password</button>
</form>
```

---

## 🔒 **Login Process**

### **Admin Login with Rate Limiting**

```php
<?php
require_once 'bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!CSRF::validateRequest()) {
        die('Invalid CSRF token');
    }
    
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    try {
        if (Auth::loginAdmin($email, $password)) {
            // Login successful
            header('Location: /moiteek_academy/admin/dashboard.php');
        } else {
            // Login failed - check why
            $locked = Auth::isAccountLocked($email, 'admin');
            if ($locked) {
                echo "Account locked. Try again in 15 minutes.";
            } else {
                echo "Invalid credentials";
            }
        }
    } catch (Exception $e) {
        echo "Login error: " . $e->getMessage();
    }
}
?>
```

### **Student Login with Verification Check**

```php
<?php
require_once 'bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!CSRF::validateRequest()) {
        die('Invalid CSRF token');
    }
    
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    try {
        if (Auth::loginStudent($email, $password)) {
            // Login successful
            header('Location: /moiteek_academy/student/dashboard.php');
        } else {
            // Login failed - provide helpful message
            $stmt = $pdo->prepare('SELECT * FROM students WHERE email = ?');
            $stmt->execute([$email]);
            $student = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$student) {
                echo "No account found";
            } elseif (!$student['email_verified']) {
                echo "Please verify your email first";
            } elseif ($student['approved'] !== 'yes') {
                echo "Waiting for admin approval";
            } elseif ($student['status'] === 'suspended') {
                echo "Account suspended";
            } else {
                echo "Invalid password";
            }
        }
    } catch (Exception $e) {
        echo "Login error: " . $e->getMessage();
    }
}
?>
```

---

## 🔐 **Sessions Management**

### **Check if User is Logged In**

```php
<?php
require_once 'bootstrap.php';

if (!Auth::isLoggedIn()) {
    header('Location: /moiteek_academy/auth/login.php');
    exit;
}

// Get current user info
$user_id = Auth::getCurrentUserId();      // User ID
$user_type = Auth::getCurrentUserType();  // 'admin' or 'student'
$user_email = Auth::getCurrentUserEmail(); // user@example.com
$user_name = Auth::getCurrentUserName();  // Full name

echo "Welcome, " . htmlspecialchars($user_name) . "!";
?>
```

---

### **Session Regeneration (Automatic)**

Sessions are regenerated every 5 minutes:

```php
<?php
// config/db.php handles this automatically
// No code needed - it happens in the background
// Just make sure to include bootstrap.php early
require_once 'bootstrap.php';

// Your code...
// Sessions will be regenerated transparently
?>
```

---

### **Logout Properly**

```php
<?php
require_once 'bootstrap.php';

// Logout (clears session, CSRF tokens, etc.)
Auth::logout();

// Redirect to login
header('Location: login.php');
?>
```

---

## 📨 **Email Notifications**

### **Send Verification Email**

```php
<?php
require_once 'bootstrap.php';

Email::sendEmailVerification($email, $student_id, $token);
// Sends HTML email with verification link
?>
```

---

### **Send Password Reset Email**

```php
<?php
Email::sendPasswordReset($email, $token);
// Sends HTML email with reset link
?>
```

---

### **Send Approval Notification**

```php
<?php
Email::sendApprovalNotification($email, $student_name);
// Sends HTML email: Account approved, ready to use
?>
```

---

### **Send Rejection Notification**

```php
<?php
Email::sendRejectionNotification($email, $student_name, 'No reason provided');
// Sends HTML email: Account rejected, optional reason, contact support
?>
```

---

### **Send Security Alert**

```php
<?php
Email::sendSecurityAlert($email, 'Multiple failed login attempts detected');
// Sends urgent HTML email with security warning
?>
```

---

## 📊 **Activity Logging**

### **Activity Logged Automatically For:**

- ✅ Every login attempt (success/fail)
- ✅ Account lockouts
- ✅ Failed rate-limit attempts
- ✅ Password resets

**View Activity Log:**

```php
<?php
require_once 'bootstrap.php';

// Get recent login activity for a student
$stmt = $pdo->prepare(
    'SELECT * FROM login_activity 
     WHERE user_id = ? AND user_type = ? 
     ORDER BY created_at DESC LIMIT 20'
);
$stmt->execute([$student_id, 'student']);
$activity = $stmt->fetchAll();

foreach ($activity as $log) {
    echo "Date: " . $log['created_at'] . " - ";
    echo "Status: " . $log['login_status'] . " - ";
    echo "IP: " . $log['ip_address'];
}
?>
```

---

## 🛡️ **Security Best Practices**

### **DO ✅**

```php
// ✅ Use prepared statements
$stmt = $pdo->prepare('SELECT * FROM users WHERE email = ?');
$stmt->execute([$email]);

// ✅ Use htmlspecialchars for output
echo htmlspecialchars($user_input);

// ✅ Use CSRF tokens
echo CSRF::generateTokenField();

// ✅ Check CSRF on POST
if (!CSRF::validateRequest()) { die('Invalid token'); }

// ✅ Use Auth::hashPassword()
$hash = Auth::hashPassword($password);

// ✅ Use Auth::verifyPassword()
if (Auth::verifyPassword($input, $hash)) { /* valid */ }

// ✅ Include bootstrap.php early
require_once 'bootstrap.php';
```

### **DON'T ❌**

```php
// ❌ Never use MD5 for passwords
$hash = md5($password);

// ❌ Never use plain passwords in database
INSERT INTO users (password) VALUES ('password123');

// ❌ Never trust user input
echo $_POST['name'];  // Vulnerable!

// ❌ Never build queries with concatenation
$query = "SELECT * FROM users WHERE email = '$email'";  // SQL injection!

// ❌ Never use simple hashes
$hash = sha1($password);

// ❌ Never skip CSRF validation
// Always validate on POST/PUT/DELETE
```

---

## 🧪 **Testing Your Implementation**

### **Test Email Verification**

```bash
# 1. Register new account
# 2. Check if email_verified = 0
SELECT email_verified FROM students WHERE email = 'test@example.com';
# Should return: 0

# 3. Click verification link
# 4. Check again
SELECT email_verified FROM students WHERE email = 'test@example.com';
# Should return: 1

# 5. Try to login before verification (should fail)
# Then verify and try again (should work)
```

---

### **Test Rate Limiting**

```bash
# 1. Try to login 5 times with wrong password
# 2. Check 6th attempt
# Should see: "Account locked. Try again in 15 minutes"

# 3. Check database
SELECT * FROM login_activity WHERE email = 'test@example.com' ORDER BY created_at DESC LIMIT 10;

# 4. Wait 15 minutes or:
DELETE FROM login_activity WHERE email = 'test@example.com' AND login_status = 'failed';
```

---

### **Test CSRF Protection**

```javascript
// Open browser console

// 1. Generate token
const token = document.querySelector('input[name="csrf_token"]').value;
console.log('Token:', token);

// 2. Use it once
// 3. Try to use same token again
// Should get: "Invalid token"
```

---

## 📝 **Code Examples - Complete Flows**

### **Complete Registration → Verification → Login Flow**

**Step 1: Register** (`auth/register.php`)
```php
<?php
require_once '../bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!CSRF::validateRequest()) die('Invalid token');
    
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    // Validate password strength
    $validation = Validator::validatePassword($password);
    if (!$validation['valid']) {
        die("Password: " . implode(', ', $validation['errors']));
    }
    
    // Hash password
    $hash = Auth::hashPassword($password);
    
    // Insert student
    $stmt = $pdo->prepare(
        'INSERT INTO students (name, email, password, email_verified, approved) 
         VALUES (?, ?, ?, 0, 0)'
    );
    $stmt->execute([$name, $email, $hash]);
    $student_id = $pdo->lastInsertId();
    
    // Generate verification token
    $token = Auth::generateEmailVerificationToken($student_id, $email);
    
    // Send verification email
    Email::sendEmailVerification($email, $student_id, $token);
    
    $_SESSION['message'] = 'Please check your email to verify your account';
    header('Location: check_email.php');
}
?>
```

**Step 2: Verify Email** (`auth/verify-email.php`)
```php
<?php
require_once '../bootstrap.php';

if (isset($_GET['token'])) {
    if (Auth::verifyEmailToken($_GET['token'])) {
        echo "✓ Email verified! Waiting for admin approval...";
    } else {
        echo "✗ Verification failed";
    }
}
?>
```

**Step 3: Admin Approves** (`admin/students.php`)
```php
<?php
require_once '../bootstrap.php';

if (Auth::getCurrentUserType() !== 'admin') {
    die('Admin only');
}

// When admin clicks approve
if (isset($_GET['approve_id'])) {
    $id = $_GET['approve_id'];
    
    $stmt = $pdo->prepare('UPDATE students SET approved = ? WHERE id = ?');
    $stmt->execute(['yes', $id]);
    
    // Get student email
    $stmt = $pdo->prepare('SELECT email, name FROM students WHERE id = ?');
    $stmt->execute([$id]);
    $student = $stmt->fetch();
    
    // Send approval email
    Email::sendApprovalNotification($student['email'], $student['name']);
    
    echo "✓ Student approved!";
}
?>
```

**Step 4: Student Logs In** (`auth/login.php`)
```php
<?php
require_once '../bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!CSRF::validateRequest()) die('Invalid token');
    
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    if (Auth::loginStudent($email, $password)) {
        header('Location: ../student/dashboard.php');
    } else {
        // Helpful error messages
        $stmt = $pdo->prepare('SELECT * FROM students WHERE email = ?');
        $stmt->execute([$email]);
        $student = $stmt->fetch();
        
        if (!$student) {
            echo "No account found";
        } elseif (!$student['email_verified']) {
            echo "Email not verified. Check your inbox.";
        } elseif ($student['approved'] !== 'yes') {
            echo "Waiting for admin approval";
        } else {
            echo "Invalid password";
        }
    }
}
?>
```

---

**Questions? Check [SECURITY.md](SECURITY.md) for detailed documentation!**
