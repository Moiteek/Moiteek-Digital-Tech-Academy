<?php
require_once '../bootstrap.php';

if(!Auth::isAdminLoggedIn()) {
    Response::redirect('../admin/login.php', 'Please login', 'error');
}

// Get enrollments with filters
$sql = "
    SELECT e.*, s.fullname, s.email, c.title, c.price
    FROM enrollments e
    JOIN students s ON e.student_id = s.id
    JOIN courses c ON e.course_id = c.id
    ORDER BY e.enrollment_date DESC
";

$enrollments = $pdo->query($sql)->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enrollments Management - <?= APP_NAME ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <nav class="bg-white shadow-lg sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <a href="dashboard.php" class="text-blue-600 hover:text-blue-700">
                    <i class="fas fa-arrow-left"></i>
                </a>
                <h1 class="text-lg font-bold">Enrollments Management</h1>
            </div>
            <a href="../auth/logout.php" class="p-2 text-gray-600 hover:bg-red-50 rounded-lg">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto p-8">
        <h2 class="text-2xl font-bold text-gray-800 mb-6">All Enrollments</h2>

        <div class="bg-white rounded-lg shadow overflow-hidden">
            <table class="w-full">
                <thead class="bg-gray-50 border-b">
                    <tr>
                        <th class="px-6 py-4 text-left text-sm font-semibold text-gray-700">Student</th>
                        <th class="px-6 py-4 text-left text-sm font-semibold text-gray-700">Course</th>
                        <th class="px-6 py-4 text-left text-sm font-semibold text-gray-700">Price</th>
                        <th class="px-6 py-4 text-left text-sm font-semibold text-gray-700">Payment Status</th>
                        <th class="px-6 py-4 text-left text-sm font-semibold text-gray-700">Enrollment Status</th>
                        <th class="px-6 py-4 text-left text-sm font-semibold text-gray-700">Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($enrollments as $enrollment): ?>
                        <tr class="border-b hover:bg-gray-50">
                            <td class="px-6 py-4">
                                <p class="font-semibold text-gray-800"><?= htmlspecialchars($enrollment['fullname']) ?></p>
                                <p class="text-sm text-gray-600"><?= htmlspecialchars($enrollment['email']) ?></p>
                            </td>
                            <td class="px-6 py-4 text-gray-800"><?= htmlspecialchars($enrollment['title']) ?></td>
                            <td class="px-6 py-4 font-bold text-gray-800"><?= Helper::formatCurrency($enrollment['price']) ?></td>
                            <td class="px-6 py-4">
                                <span class="px-3 py-1 rounded-full text-xs font-semibold bg-<?= $enrollment['payment_status'] === 'confirmed' ? 'green' : ($enrollment['payment_status'] === 'pending' ? 'yellow' : 'red') ?>-100 text-<?= $enrollment['payment_status'] === 'confirmed' ? 'green' : ($enrollment['payment_status'] === 'pending' ? 'yellow' : 'red') ?>-800">
                                    <?= ucfirst($enrollment['payment_status']) ?>
                                </span>
                            </td>
                            <td class="px-6 py-4">
                                <span class="px-3 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-800">
                                    <?= ucfirst($enrollment['status']) ?>
                                </span>
                            </td>
                            <td class="px-6 py-4 text-sm text-gray-600"><?= Helper::formatDate($enrollment['enrollment_date']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>