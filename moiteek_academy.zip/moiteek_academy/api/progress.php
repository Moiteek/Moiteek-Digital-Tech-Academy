<?php
/**
 * AJAX Progress API Endpoint
 * Handles module completion and progress tracking
 */

header('Content-Type: application/json');

require_once '../bootstrap.php';

// Check if student is logged in
if (!Auth::isStudentLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Validate CSRF token
if (!CSRF::validateRequest()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Invalid token']);
    exit;
}

$student_id = Auth::getCurrentUserId();
$action = $_POST['action'] ?? '';
$module_id = $_POST['module_id'] ?? 0;
$course_id = $_POST['course_id'] ?? 0;

if (!$module_id || !$course_id || !is_numeric($module_id) || !is_numeric($course_id)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Missing required parameters']);
    exit;
}

// Verify enrollment
$enrollStmt = $pdo->prepare(
    'SELECT id FROM enrollments WHERE student_id = ? AND course_id = ? AND payment_status = ?'
);
$enrollStmt->execute([$student_id, $course_id, 'approved']);

if (!$enrollStmt->fetch()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Not enrolled in this course']);
    exit;
}

try {
    switch ($action) {
        case 'complete_module':
            completeModule($student_id, $module_id, $course_id);
            break;
        
        case 'mark_incomplete':
            markIncomplete($student_id, $module_id, $course_id);
            break;
        
        case 'update_watched_time':
            updateWatchedTime($student_id, $module_id, $_POST['duration'] ?? 0);
            break;
        
        case 'get_progress':
            getProgress($student_id, $course_id);
            break;
        
        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Invalid action']);
            exit;
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error']);
    exit;
}

/**
 * Mark module as complete
 */
function completeModule($student_id, $module_id, $course_id) {
    global $pdo;
    
    // Check if record exists
    $stmt = $pdo->prepare(
        'SELECT id FROM module_progress WHERE student_id = ? AND module_id = ?'
    );
    $stmt->execute([$student_id, $module_id]);
    $exists = $stmt->fetch();
    
    if ($exists) {
        // Update existing record
        $stmt = $pdo->prepare(
            'UPDATE module_progress 
             SET is_completed = 1, completed_at = CURRENT_TIMESTAMP 
             WHERE student_id = ? AND module_id = ?'
        );
        $stmt->execute([$student_id, $module_id]);
    } else {
        // Create new record
        $stmt = $pdo->prepare(
            'INSERT INTO module_progress (student_id, module_id, course_id, is_completed, completed_at)
             VALUES (?, ?, ?, 1, CURRENT_TIMESTAMP)'
        );
        $stmt->execute([$student_id, $module_id, $course_id]);
    }
    
    // Update overall progress
    updateCourseProgress($student_id, $course_id);
    
    // Get updated progress
    getProgress($student_id, $course_id);
}

/**
 * Mark module as incomplete
 */
function markIncomplete($student_id, $module_id, $course_id) {
    global $pdo;
    
    $stmt = $pdo->prepare(
        'UPDATE module_progress 
         SET is_completed = 0, completed_at = NULL
         WHERE student_id = ? AND module_id = ?'
    );
    $stmt->execute([$student_id, $module_id]);
    
    // Update overall progress
    updateCourseProgress($student_id, $course_id);
    
    // Get updated progress
    getProgress($student_id, $course_id);
}

/**
 * Update watched duration for a module
 */
function updateWatchedTime($student_id, $module_id, $duration) {
    global $pdo;
    
    $stmt = $pdo->prepare(
        'UPDATE module_progress 
         SET watched_duration = ?, updated_at = CURRENT_TIMESTAMP
         WHERE student_id = ? AND module_id = ?'
    );
    $stmt->execute([$duration, $student_id, $module_id]);
    
    echo json_encode(['success' => true, 'message' => 'Watch time updated']);
}

/**
 * Get current progress
 */
function getProgress($student_id, $course_id) {
    global $pdo;
    
    // Get total modules
    $stmt = $pdo->prepare(
        'SELECT COUNT(*) as total FROM course_modules WHERE course_id = ? AND is_published = 1'
    );
    $stmt->execute([$course_id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $totalModules = $result['total'];
    
    // Get completed modules
    $stmt = $pdo->prepare(
        'SELECT COUNT(*) as completed 
         FROM module_progress 
         WHERE student_id = ? AND course_id = ? AND is_completed = 1'
    );
    $stmt->execute([$student_id, $course_id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $completedModules = $result['completed'];
    
    // Calculate percentage
    $percentage = $totalModules > 0 ? round(($completedModules / $totalModules) * 100) : 0;
    
    // Update or insert progress record
    $stmt = $pdo->prepare(
        'SELECT id FROM progress WHERE student_id = ? AND course_id = ?'
    );
    $stmt->execute([$student_id, $course_id]);
    $exists = $stmt->fetch();
    
    if ($exists) {
        $stmt = $pdo->prepare(
            'UPDATE progress 
             SET progress_percentage = ?, completed_modules = ?, updated_at = CURRENT_TIMESTAMP
             WHERE student_id = ? AND course_id = ?'
        );
        $stmt->execute([$percentage, $completedModules, $student_id, $course_id]);
    } else {
        $stmt = $pdo->prepare(
            'INSERT INTO progress (student_id, course_id, progress_percentage, completed_modules)
             VALUES (?, ?, ?, ?)'
        );
        $stmt->execute([$student_id, $course_id, $percentage, $completedModules]);
    }
    
    // Get detailed module progress
    $stmt = $pdo->prepare(
        'SELECT module_id, is_completed 
         FROM module_progress 
         WHERE student_id = ? AND course_id = ?
         ORDER BY updated_at DESC'
    );
    $stmt->execute([$student_id, $course_id]);
    $moduleProgress = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'progress' => [
            'percentage' => $percentage,
            'completed_modules' => $completedModules,
            'total_modules' => $totalModules,
            'modules' => $moduleProgress,
            'is_completed' => $percentage === 100
        ]
    ]);
}

/**
 * Update course progress in progress table
 */
function updateCourseProgress($student_id, $course_id) {
    global $pdo;
    
    // Get total modules
    $stmt = $pdo->prepare(
        'SELECT COUNT(*) as total FROM course_modules WHERE course_id = ? AND is_published = 1'
    );
    $stmt->execute([$course_id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $totalModules = $result['total'];
    
    // Get completed modules
    $stmt = $pdo->prepare(
        'SELECT COUNT(*) as completed 
         FROM module_progress 
         WHERE student_id = ? AND course_id = ? AND is_completed = 1'
    );
    $stmt->execute([$student_id, $course_id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $completedModules = $result['completed'];
    
    // Calculate percentage
    $percentage = $totalModules > 0 ? round(($completedModules / $totalModules) * 100) : 0;
    
    // Update or insert progress record
    $stmt = $pdo->prepare(
        'SELECT id FROM progress WHERE student_id = ? AND course_id = ?'
    );
    $stmt->execute([$student_id, $course_id]);
    $exists = $stmt->fetch();
    
    if ($exists) {
        $stmt = $pdo->prepare(
            'UPDATE progress 
             SET progress_percentage = ?, completed_modules = ?, updated_at = CURRENT_TIMESTAMP
             WHERE student_id = ? AND course_id = ?'
        );
        $stmt->execute([$percentage, $completedModules, $student_id, $course_id]);
    } else {
        $stmt = $pdo->prepare(
            'INSERT INTO progress (student_id, course_id, progress_percentage, completed_modules)
             VALUES (?, ?, ?, ?)'
        );
        $stmt->execute([$student_id, $course_id, $percentage, $completedModules]);
    }
}
