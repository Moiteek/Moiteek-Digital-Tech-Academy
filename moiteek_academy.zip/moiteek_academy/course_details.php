<?php
require_once __DIR__ . '/includes/bootstrap.php';

$slug = $_GET['slug'] ?? '';
if (!$slug) {
    header('Location: index.php');
    exit;
}

$stmt = $pdo->prepare('SELECT id, title, description, price FROM courses WHERE slug = ? LIMIT 1');
$stmt->execute([$slug]);
$course = $stmt->fetch();
if (!$course) {
    header('HTTP/1.0 404 Not Found');
    echo '<h1>Course not found</h1>';
    exit;
}

$isStudent = isset($_SESSION['student_id']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($course['title']) ?> - Course Details</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-50" style="padding-top:72px;">
    <?php include __DIR__ . '/includes/header.php'; ?>
    <div class="container mx-auto px-4 py-10 max-w-2xl">
        <h1 class="text-3xl font-bold text-blue-800 mb-4"><?= htmlspecialchars($course['title']) ?></h1>
        <div class="mb-6 text-lg text-gray-700">
            <?= nl2br(htmlspecialchars($course['description'])) ?>
        </div>
        <div class="mb-8 text-2xl font-bold text-green-700">
            $<?= number_format($course['price'], 2) ?>
        </div>
        <?php if (!$isStudent): ?>
            <a href="auth/login.php" class="bg-blue-600 text-white px-6 py-3 rounded hover:bg-blue-700 text-lg">Login to Enroll</a>
        <?php else: ?>
            <form method="post" action="payments/initialize.php">
                <input type="hidden" name="course_id" value="<?= (int)$course['id'] ?>">
                <button type="submit" class="bg-green-600 text-white px-6 py-3 rounded hover:bg-green-700 text-lg">Buy Now</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>
<?php 
require_once 'bootstrap.php';
require_once 'includes/seo_helper.php';

$id = Validator::sanitizeInput($_GET['id'] ?? '');
if(!$id || !is_numeric($id)) {
    Response::redirect('courses.php', 'Invalid course', 'error');
}

$course = Database::getCourseById($id);
if(!$course) {
    Response::redirect('courses.php', 'Course not found', 'error');
}

$flash = Response::getFlashMessage();
$title = $course['title'] ?? 'Course Details';
$desc = $course['description'] ?? 'Explore this course at Moiteek Academy.';
$image = $course['image_url'] ?? '/assets/logo.png';
echo generateMetaTags($title, $desc, $image);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($course['title']) ?> - <?= APP_NAME ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .course-hero {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%);
        }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-md sticky top-0 z-40">
        <div class="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
            <a href="/" class="flex items-center gap-2">
                <i class="fas fa-graduation-cap text-3xl text-blue-600"></i>
                <span class="font-bold text-xl text-gray-900"><?= APP_NAME ?></span>
            </a>
            <div class="flex items-center gap-3">
                <a href="courses.php" class="text-gray-700 hover:text-blue-600 font-semibold">
                    <i class="fas fa-arrow-left mr-1"></i>Back to Courses
                </a>
            </div>
        </div>
    </nav>

    <!-- Flash Message -->
    <?php if($flash): ?>
        <div class="max-w-7xl mx-auto mt-4 px-4">
            <div class="p-4 rounded-lg bg-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-50 border border-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-200 flex items-center gap-3">
                <i class="fas fa-<?= $flash['type'] === 'error' ? 'exclamation-circle' : 'check-circle' ?> text-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-600"></i>
                <p class="text-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-700"><?= htmlspecialchars($flash['message']) ?></p>
            </div>
        </div>
    <?php endif; ?>

    <!-- Hero Section -->
    <div class="course-hero text-white py-12">
        <div class="max-w-7xl mx-auto px-4">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8 items-start">
                <div class="md:col-span-2">
                    <div class="mb-4 flex items-center gap-3">
                        <span class="bg-white/20 px-4 py-1 rounded-full text-xs font-semibold">
                            <?= ucfirst($course['level']) ?>
                        </span>
                        <span class="bg-white/20 px-4 py-1 rounded-full text-xs font-semibold">
                            <?= htmlspecialchars($course['category']) ?>
                        </span>
                    </div>
                    <h1 class="text-4xl md:text-5xl font-bold mb-4 leading-tight">
                        <?= htmlspecialchars($course['title']) ?>
                    </h1>
                    <p class="text-lg text-gray-100 mb-6">
                        <?= htmlspecialchars($course['description']) ?>
                    </p>
                    <div class="flex items-center gap-6 text-sm">
                        <div class="flex items-center gap-2">
                            <i class="fas fa-star text-yellow-300"></i>
                            <span>4.8 (1,234 reviews)</span>
                        </div>
                        <div class="flex items-center gap-2">
                            <i class="fas fa-users"></i>
                            <span>12K+ students</span>
                        </div>
                    </div>
                </div>

                <!-- Enrollment Card -->
                <div class="bg-white rounded-xl shadow-2xl p-8 text-gray-900 sticky top-24">
                    <!-- Thumbnail -->
                    <div class="h-40 bg-gradient-to-br from-blue-400 to-purple-500 rounded-lg flex items-center justify-center mb-6">
                        <i class="fas fa-book text-5xl text-white opacity-80"></i>
                    </div>

                    <!-- Price -->
                    <div class="mb-6">
                        <p class="text-4xl font-bold text-blue-600 mb-2">
                            <?= Helper::formatCurrency($course['price']) ?>
                        </p>
                        <?php if($course['price'] > 0): ?>
                            <p class="text-sm text-gray-600"><i class="fas fa-tag mr-1"></i>Limited time offer</p>
                        <?php else: ?>
                            <p class="text-sm text-green-600 font-semibold"><i class="fas fa-check-circle mr-1"></i>Completely Free</p>
                        <?php endif; ?>
                    </div>

                    <!-- Features -->
                    <div class="space-y-3 mb-6 pb-6 border-b border-gray-200">
                        <div class="flex items-center gap-3">
                            <i class="fas fa-film text-blue-600 w-5"></i>
                            <span class="text-sm"><?= $course['total_modules'] ?> Modules & <?= intval($course['total_modules'] * 3) ?> Hours</span>
                        </div>
                        <div class="flex items-center gap-3">
                            <i class="fas fa-clock text-blue-600 w-5"></i>
                            <span class="text-sm"><?= htmlspecialchars($course['duration']) ?> Duration</span>
                        </div>
                        <div class="flex items-center gap-3">
                            <i class="fas fa-certificate text-blue-600 w-5"></i>
                            <span class="text-sm">Certificate of Completion</span>
                        </div>
                        <div class="flex items-center gap-3">
                            <i class="fas fa-mobile-alt text-blue-600 w-5"></i>
                            <span class="text-sm">Mobile Friendly</span>
                        </div>
                    </div>

                    <!-- Instructor -->
                    <div class="flex items-center gap-3 mb-6 pb-6 border-b border-gray-200">
                        <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-user text-blue-600"></i>
                        </div>
                        <div>
                            <p class="text-xs text-gray-600">Instructor</p>
                            <p class="font-semibold text-gray-900">
                                <?= htmlspecialchars($course['instructor_name']) ?>
                            </p>
                        </div>
                    </div>

                    <!-- Enroll Button -->
                    <a href="auth/register.php?course=<?= $course['id'] ?>" class="w-full block text-center bg-gradient-to-r from-blue-600 to-purple-600 hover:shadow-lg text-white py-4 rounded-lg font-bold text-lg mb-3 transition">
                        <i class="fas fa-play-circle mr-2"></i>Enroll Now
                    </a>
                    <p class="text-xs text-gray-600 text-center">30-day money-back guarantee</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="max-w-7xl mx-auto px-4 py-12">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-12">
            <!-- Left Content -->
            <div class="lg:col-span-2">
                <!-- What You'll Learn -->
                <section class="bg-white rounded-xl shadow-md p-8 mb-8">
                    <h2 class="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                        <i class="fas fa-lightbulb text-yellow-500"></i>What You'll Learn
                    </h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div class="flex items-start gap-3">
                            <i class="fas fa-check-circle text-green-600 mt-1 flex-shrink-0"></i>
                            <span class="text-gray-700">Master core concepts and fundamentals</span>
                        </div>
                        <div class="flex items-start gap-3">
                            <i class="fas fa-check-circle text-green-600 mt-1 flex-shrink-0"></i>
                            <span class="text-gray-700">Build real-world projects</span>
                        </div>
                        <div class="flex items-start gap-3">
                            <i class="fas fa-check-circle text-green-600 mt-1 flex-shrink-0"></i>
                            <span class="text-gray-700">Get industry-ready skills</span>
                        </div>
                        <div class="flex items-start gap-3">
                            <i class="fas fa-check-circle text-green-600 mt-1 flex-shrink-0"></i>
                            <span class="text-gray-700">Practice with hands-on exercises</span>
                        </div>
                    </div>
                </section>

                <!-- Course Description -->
                <section class="bg-white rounded-xl shadow-md p-8 mb-8">
                    <h2 class="text-2xl font-bold text-gray-900 mb-6">About this Course</h2>
                    <p class="text-gray-700 leading-relaxed mb-6">
                        <?= htmlspecialchars($course['detailed_description'] ?? $course['description']) ?>
                    </p>
                </section>

                <!-- Course Curriculum -->
                <section class="bg-white rounded-xl shadow-md p-8">
                    <h2 class="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                        <i class="fas fa-list-check text-blue-600"></i>Course Curriculum
                    </h2>
                    <div class="space-y-3">
                        <?php for($i = 1; $i <= $course['total_modules']; $i++): ?>
                            <div class="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition cursor-pointer">
                                <div class="flex items-center justify-between">
                                    <div class="flex items-center gap-3">
                                        <i class="fas fa-play-circle text-blue-600"></i>
                                        <div>
                                            <p class="font-semibold text-gray-900">Module <?= $i ?>: Course Content</p>
                                            <p class="text-sm text-gray-600"><?= rand(30, 120) ?> minutes</p>
                                        </div>
                                    </div>
                                    <i class="fas fa-lock text-gray-400"></i>
                                </div>
                            </div>
                        <?php endfor; ?>
                    </div>
                </section>
            </div>

            <!-- Sidebar -->
            <div class="lg:col-span-1 space-y-8">
                <!-- Instructor Profile -->
                <div class="bg-white rounded-xl shadow-md p-6">
                    <h3 class="text-lg font-bold text-gray-900 mb-4">About the Instructor</h3>
                    <div class="flex items-center gap-4 mb-4">
                        <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-user text-2xl text-blue-600"></i>
                        </div>
                        <div>
                            <p class="font-bold text-gray-900"><?= htmlspecialchars($course['instructor_name']) ?></p>
                            <p class="text-sm text-gray-600">Expert Instructor</p>
                        </div>
                    </div>
                    <p class="text-gray-700 text-sm">
                        Passionate about teaching with 10+ years of industry experience. Dedicated to helping students succeed.
                    </p>
                </div>

                <!-- Requirements -->
                <div class="bg-white rounded-xl shadow-md p-6">
                    <h3 class="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                        <i class="fas fa-exclamation-circle text-yellow-600"></i>Requirements
                    </h3>
                    <ul class="space-y-2 text-sm text-gray-700">
                        <li class="flex items-start gap-2">
                            <i class="fas fa-circle-small text-gray-400 mt-1"></i>
                            Basic computer knowledge
                        </li>
                        <li class="flex items-start gap-2">
                            <i class="fas fa-circle-small text-gray-400 mt-1"></i>
                            Internet connection
                        </li>
                        <li class="flex items-start gap-2">
                            <i class="fas fa-circle-small text-gray-400 mt-1"></i>
                            Text editor or IDE
                        </li>
                    </ul>
                </div>

                <!-- Who Should Enroll -->
                <div class="bg-white rounded-xl shadow-md p-6">
                    <h3 class="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                        <i class="fas fa-users text-purple-600"></i>Who Should Enroll?
                    </h3>
                    <ul class="space-y-2 text-sm text-gray-700">
                        <li class="flex items-start gap-2">
                            <i class="fas fa-check text-green-600 mt-1"></i>
                            Beginners wanting to learn <?= htmlspecialchars($course['category']) ?>
                        </li>
                        <li class="flex items-start gap-2">
                            <i class="fas fa-check text-green-600 mt-1"></i>
                            Career changers
                        </li>
                        <li class="flex items-start gap-2">
                            <i class="fas fa-check text-green-600 mt-1"></i>
                            Experienced professionals
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <!-- CTA Section -->
    <section class="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-12 my-8">
        <div class="max-w-4xl mx-auto px-4 text-center">
            <h2 class="text-3xl font-bold mb-4">Ready to Get Started?</h2>
            <p class="text-lg text-gray-100 mb-8">Join thousands of students learning <?= htmlspecialchars($course['title']) ?></p>
            <a href="auth/register.php?course=<?= $course['id'] ?>" class="inline-block bg-white text-blue-600 hover:bg-gray-100 px-10 py-4 rounded-lg font-bold text-lg transition shadow-lg">
                <i class="fas fa-calendar-check mr-2"></i>Enroll Now - <?= Helper::formatCurrency($course['price']) ?>
            </a>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-gray-900 text-gray-400 py-8">
        <div class="max-w-7xl mx-auto px-4 text-center text-sm">
            <p>&copy; 2026 <?= APP_NAME ?>. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
