# QUICKSTART.md - Get Up and Running in 5 Minutes

Quick setup guide to get Moiteek Academy running locally on your machine.

---

## ⚡ **Quick Setup (5 minutes)**

### **1. Prerequisites** (2 min)
Ensure you have:
- PHP 7.4+ installed
- MySQL 5.7+ installed  
- A web server (Apache/Nginx) or use PHP built-in server

**Test your setup:**
```bash
php -v          # Should show PHP 7.4+
mysql -V        # Should show MySQL 5.7+
```

---

### **2. Extract Project** (1 min)
```bash
# Extract ZIP file to your web root
# Windows (XAMPP): c:\xampp\htdocs\moiteek_academy
# Linux/Mac: /var/www/html/moiteek_academy
```

---

### **3. Create Database** (1 min)

**Option A: Using phpMyAdmin (GUI)**
1. Open http://localhost/phpmyadmin
2. Click "New" → Create database: `moiteek_academy`
3. Select database → "Import" tab
4. Choose `sql/database.sql` → Execute

**Option B: Using Command Line**
```bash
# Navigate to project
cd c:\xampp\htdocs\moiteek_academy

# Create database and import
mysql -u root -p -e "CREATE DATABASE moiteek_academy;"
mysql -u root -p moiteek_academy < sql/database.sql

# Verify (should show 10 tables)
mysql -u root -p moiteek_academy -e "SHOW TABLES;"
```

---

### **4. Configure Database** (1 min)

Edit `config/db.php`:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');              // Your MySQL password (usually empty for local)
define('DB_NAME', 'moiteek_academy');
```

---

### **5. Run Application** (1 min)

**Using XAMPP:**
1. Start Apache & MySQL from XAMPP Control Panel
2. Visit: http://localhost/moiteek_academy

**Using PHP Built-in Server:**
```bash
cd c:\xampp\htdocs\moiteek_academy
php -S localhost:8000
# Visit: http://localhost:8000
```

---

## ✅ **Verify Installation**

Visit these URLs to confirm everything works:

| Page | URL | Status |
|------|-----|--------|
| **Homepage** | http://localhost/moiteek_academy/ | Should load with hero section |
| **Courses** | http://localhost/moiteek_academy/courses.php | Shows course grid |
| **Admin Login** | http://localhost/moiteek_academy/auth/login.php | Login form appears |

---

## 🔓 **Default Test Accounts**

### **Admin Account**
- Email: `admin@moiteek.com`
- Password: `Admin@123`

### **Test Student (Already Approved)**
- Email: `student@test.com`
- Username: `student123`
- Password: `Student@123`

**These are created by `sql/database.sql` - use them to test the platform!**

---

## 🧭 **First Steps**

### **As Admin:**
1. Login at `/auth/login.php` with admin credentials
2. Go to Admin Dashboard
3. Check pending students for approval
4. Check pending payments
5. View course listing

### **As Student:**
1. Login at `/auth/login.php` with student credentials  
2. View available courses at `/courses.php`
3. Browse course details
4. Register for a course
5. View your dashboard

---

## 📁 **Key Files Reference**

| File | Purpose |
|------|---------|
| `index.php` | Homepage landing page |
| `courses.php` | Courses listing and search |
| `course_details.php` | Individual course details |
| `auth/login.php` | Login form (for admin/student) |
| `auth/register.php` | Student registration |
| `admin/dashboard.php` | Admin control panel home |
| `student/dashboard.php` | Student learning hub |
| `bootstrap.php` | App initialization (included by all pages) |
| `includes/` | Helper classes (Auth, Database, etc.) |
| `sql/database.sql` | Database schema and seed data |

---

## 🎨 **Customize Platform**

### **Change Site Name**
Edit in multiple places (search for "Moiteek"):
- Pages: `index.php`, navbar sections
- Database: Run: `UPDATE courses SET description = 'Your desc' WHERE id = 1;`

### **Change Colors**
Edit `assets/css/custom.css`:
```css
:root {
    --primary-color: #3b82f6;      /* Blue - change this */
    --secondary-color: #a855f7;    /* Purple */
    ...
}
```

### **Change Logo/Images**
- Replace images in pages with your own
- Update thumbnail paths in database
- Upload new images to `assets/images/` folder

---

## 🚀 **Next Steps**

1. ✅ Run the platform locally
2. ✅ Test both admin and student workflows
3. ✅ Create your own courses/admin account
4. ✅ Customize colors and branding
5. ✅ Review code in `includes/` helper classes
6. ✅ Read `DEVELOPMENT.md` for code standards
7. ✅ Check `DEPLOYMENT.md` when ready for production

---

## ❓ **Common Issues**

| Issue | Fix |
|-------|-----|
| **"Database connection failed"** | Check DB credentials in `config/db.php` |
| **"Blank white page"** | Enable PHP error reporting, check browser console (F12) |
| **"404 Not Found"** | Check file paths, ensure XAMPP Apache is running |
| **"Login redirects to login again"** | Check session permissions, PHP session save path |
| **"Uploads not working"** | Create `uploads/payments/` folder, `chmod 775` it |

---

## 📞 **Getting Help**

1. Check error messages in browser console (F12)
2. Check PHP errors: `config/db.php` error_log setting
3. Review `DEVELOPMENT.md` for code guidelines
4. Check database exists: `mysql -u root -e "SHOW DATABASES;"`
5. Verify PHP extensions: `php -m` should show PDO, MySQLi

---

## 📖 **Full Documentation**

- **Setup & Features**: See `README.md`
- **Development Guide**: See `DEVELOPMENT.md`
- **Production Deployment**: See `DEPLOYMENT.md`
- **API Documentation**: See `API.md` (when created)

---

**You're all set! Start building your online academy! 🎓✨**

Questions? Review the relevant documentation file above, or check the inline code comments in `/includes/` and page files.
