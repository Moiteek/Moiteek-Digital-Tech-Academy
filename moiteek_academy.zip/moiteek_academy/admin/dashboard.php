
<?php
require_once ROOT_PATH . 'includes/bootstrap.php';
require_once __DIR__ . '/../includes/Database.php';

// Check admin credentials
if(!Auth::isAdminLoggedIn()) {
    Response::redirect('../admin/login.php', 'Please login to access admin panel', 'error');
}

// Get dashboard statistics
$total_students = Database::getTotalStudents();
$approved_students = Database::getTotalStudents('approved');
$pending_students = Database::getTotalStudents('pending');
$total_courses = Database::getTotalCourses();
$total_enrollments = Database::getTotalEnrollments();
$revenue = Database::getRevenueSummary();

// Get recent enrollments
$stmt = $pdo->prepare("
    SELECT e.*, s.fullname, c.title 
    FROM enrollments e 
    JOIN students s ON e.student_id = s.id 
    JOIN courses c ON e.course_id = c.id 
    ORDER BY e.enrollment_date DESC 
    LIMIT 5
");
$stmt->execute();
$recent_enrollments = $stmt->fetchAll();

// Get pending payments
$pending_payments = Database::getPendingEnrollments();

$flash = Response::getFlashMessage();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - <?= APP_NAME ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <i class="fas fa-graduation-cap text-2xl text-blue-600"></i>
                <span class="font-bold text-lg text-gray-800"><?= APP_NAME ?></span>
                <span class="bg-blue-100 text-blue-800 text-xs px-3 py-1 rounded-full font-semibold">Admin</span>
            </div>
            <div class="flex items-center gap-4">
                <div class="flex items-center gap-2 text-gray-700">
                    <i class="fas fa-user-circle text-2xl"></i>
                    <div>
                        <p class="text-sm font-semibold"><?= htmlspecialchars($_SESSION['admin_name']) ?></p>
                        <p class="text-xs text-gray-600"><?= htmlspecialchars($_SESSION['admin_role']) ?></p>
                    </div>
                </div>
                <a href="../auth/logout.php" class="p-2 text-gray-600 hover:bg-red-50 hover:text-red-600 rounded-lg transition">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </div>
    </nav>

    <div class="flex">
        <!-- Sidebar -->
        <aside class="w-64 bg-white shadow-lg min-h-screen">
            <div class="p-4 space-y-2">
                <a href="dashboard.php" class="block px-4 py-3 rounded-lg bg-blue-600 text-white font-semibold">
                    <i class="fas fa-chart-line mr-2"></i>Dashboard
                </a>
                <a href="students.php" class="block px-4 py-3 rounded-lg hover:bg-gray-100">
                    <i class="fas fa-users mr-2"></i>Students
                </a>
                <a href="courses.php" class="block px-4 py-3 rounded-lg hover:bg-gray-100">
                    <i class="fas fa-book mr-2"></i>Courses
                </a>
                <a href="payments.php" class="block px-4 py-3 rounded-lg hover:bg-gray-100">
                    <i class="fas fa-credit-card mr-2"></i>Payments
                </a>
                <a href="enrollments.php" class="block px-4 py-3 rounded-lg hover:bg-gray-100">
                    <i class="fas fa-clipboard-list mr-2"></i>Enrollments
                </a>
                <a href="analytics.php" class="block px-4 py-3 rounded-lg hover:bg-gray-100">
                    <i class="fas fa-chart-bar mr-2"></i>Analytics
                </a>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="flex-1 p-8 space-y-8">
            <!-- Flash Message -->
            <?php if($flash): ?>
                <div class="p-4 rounded-lg bg-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-50 border border-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-200 flex items-center gap-3">
                    <i class="fas fa-<?= $flash['type'] === 'error' ? 'exclamation-circle' : 'check-circle' ?> text-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-600"></i>
                    <p class="text-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-700"><?= htmlspecialchars($flash['message']) ?></p>
                </div>
            <?php endif; ?>

            <!-- Page Header -->
            <div>
                <h1 class="text-3xl font-bold text-gray-800 flex items-center gap-2">
                    <i class="fas fa-chart-line text-blue-600"></i>Dashboard Overview
                </h1>
                <p class="text-gray-600 text-sm mt-1">Welcome back! Here's your academy performance at a glance.</p>
            </div>

            <!-- Statistics Cards -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <!-- Total Students -->
                <div class="bg-white rounded-lg shadow p-6 border-l-4 border-blue-600">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-gray-600 text-sm font-semibold">Total Students</p>
                            <p class="text-3xl font-bold text-gray-800 mt-2"><?= $total_students ?></p>
                            <p class="text-xs text-gray-500 mt-1"><span class="text-green-600"><?= $approved_students ?></span> Approved</p>
                        </div>
                        <i class="fas fa-users text-4xl text-blue-100"></i>
                    </div>
                </div>

                <!-- Pending Students -->
                <div class="bg-white rounded-lg shadow p-6 border-l-4 border-yellow-600">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-gray-600 text-sm font-semibold">Pending Approvals</p>
                            <p class="text-3xl font-bold text-gray-800 mt-2"><?= $pending_students ?></p>
                            <a href="students.php?status=pending" class="text-xs text-yellow-600 hover:underline mt-1">Review now</a>
                        </div>
                        <i class="fas fa-user-clock text-4xl text-yellow-100"></i>
                    </div>
                </div>

                <!-- Total Courses -->
                <div class="bg-white rounded-lg shadow p-6 border-l-4 border-green-600">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-gray-600 text-sm font-semibold">Active Courses</p>
                            <p class="text-3xl font-bold text-gray-800 mt-2"><?= $total_courses ?></p>
                            <a href="courses.php" class="text-xs text-green-600 hover:underline mt-1">Manage courses</a>
                        </div>
                        <i class="fas fa-book text-4xl text-green-100"></i>
                    </div>
                </div>

                <!-- Total Enrollments -->
                <div class="bg-white rounded-lg shadow p-6 border-l-4 border-purple-600">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-gray-600 text-sm font-semibold">Total Enrollments</p>
                            <p class="text-3xl font-bold text-gray-800 mt-2"><?= $total_enrollments ?></p>
                            <p class="text-xs text-gray-500 mt-1">All time</p>
                        </div>
                        <i class="fas fa-user-graduate text-4xl text-purple-100"></i>
                    </div>
                </div>
            </div>

            <!-- Revenue & Analytics Section -->
            <div class="grid grid-cols-1 lg:grid-cols-4 gap-6">
                <!-- Revenue Summary -->
                <div class="bg-gradient-to-br from-green-500 to-green-600 rounded-lg shadow p-6 text-white">
                    <p class="text-green-100 text-sm font-semibold flex items-center gap-2">
                        <i class="fas fa-money-bill-wave"></i>Total Revenue
                    </p>
                    <p class="text-4xl font-bold mt-3"><?= Helper::formatCurrency($revenue['total_revenue'] ?? 0) ?></p>
                    <p class="text-green-100 text-xs mt-2">All time earnings</p>
                </div>

                <!-- Confirmed Revenue -->
                <div class="bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg shadow p-6 text-white">
                    <p class="text-blue-100 text-sm font-semibold flex items-center gap-2">
                        <i class="fas fa-check-circle"></i>Confirmed Payments
                    </p>
                    <p class="text-4xl font-bold mt-3"><?= Helper::formatCurrency($revenue['confirmed_revenue'] ?? 0) ?></p>
                    <p class="text-blue-100 text-xs mt-2"><?= $revenue['confirmed_count'] ?? 0 ?> transactions</p>
                </div>

                <!-- Pending Amount -->
                <div class="bg-gradient-to-br from-yellow-500 to-yellow-600 rounded-lg shadow p-6 text-white">
                    <p class="text-yellow-100 text-sm font-semibold flex items-center gap-2">
                        <i class="fas fa-hourglass-half"></i>Pending Payments
                    </p>
                    <p class="text-4xl font-bold mt-3"><?= $revenue['pending_count'] ?? 0 ?></p>
                    <p class="text-yellow-100 text-xs mt-2">Awaiting verification</p>
                </div>

                <!-- Completion Rate -->
                <?php
                $completion_rate = $total_enrollments > 0 ? round((($total_enrollments - $pending_students) / $total_enrollments) * 100) : 0;
                ?>
                <div class="bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg shadow p-6 text-white">
                    <p class="text-purple-100 text-sm font-semibold flex items-center gap-2">
                        <i class="fas fa-chart-pie"></i>Completion Rate
                    </p>
                    <p class="text-4xl font-bold mt-3"><?= $completion_rate ?>%</p>
                    <p class="text-purple-100 text-xs mt-2">Course progress</p>
                </div>
            </div>

            <!-- Quick Actions & Top Performers -->
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <!-- Quick Actions -->
                <div class="bg-white rounded-lg shadow p-6">
                    <h2 class="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
                        <i class="fas fa-lightning-bolt text-yellow-600"></i>Quick Actions
                    </h2>
                    <div class="space-y-3">
                        <a href="students.php?status=pending" class="block p-3 rounded-lg bg-blue-50 hover:bg-blue-100 text-center font-semibold text-blue-600 transition">
                            <i class="fas fa-check-circle mr-1"></i>Approve Students
                        </a>
                        <a href="payments.php?status=pending" class="block p-3 rounded-lg bg-green-50 hover:bg-green-100 text-center font-semibold text-green-600 transition">
                            <i class="fas fa-dollar-sign mr-1"></i>Verify Payments
                        </a>
                        <a href="courses.php" class="block p-3 rounded-lg bg-purple-50 hover:bg-purple-100 text-center font-semibold text-purple-600 transition">
                            <i class="fas fa-plus-circle mr-1"></i>Manage Courses
                        </a>
                        <a href="analytics.php" class="block p-3 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-center font-semibold text-indigo-600 transition">
                            <i class="fas fa-chart-line mr-1"></i>View Analytics
                        </a>
                    </div>
                </div>

                <!-- Top Courses -->
                <?php
                $top_courses = $pdo->prepare("
                    SELECT c.id, c.title, COUNT(e.id) as enrollments 
                    FROM courses c 
                    LEFT JOIN enrollments e ON c.id = e.course_id 
                    GROUP BY c.id 
                    ORDER BY enrollments DESC 
                    LIMIT 5
                ");
                $top_courses->execute();
                $courses_data = $top_courses->fetchAll();
                ?>
                <div class="bg-white rounded-lg shadow p-6">
                    <h2 class="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
                        <i class="fas fa-star text-yellow-600"></i>Top Courses
                    </h2>
                    <div class="space-y-3">
                        <?php foreach($courses_data as $course): ?>
                            <div class="flex items-center justify-between p-2 bg-gray-50 rounded">
                                <span class="text-sm text-gray-700"><?= htmlspecialchars(substr($course['title'], 0, 20)) ?></span>
                                <span class="px-3 py-1 bg-blue-100 text-blue-700 text-xs font-bold rounded-full"><?= $course['enrollments'] ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- System Status -->
                <div class="bg-white rounded-lg shadow p-6">
                    <h2 class="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
                        <i class="fas fa-heartbeat text-red-600"></i>System Status
                    </h2>
                    <div class="space-y-3">
                        <div class="flex items-center justify-between p-2 bg-gray-50 rounded">
                            <span class="text-sm text-gray-700">Database</span>
                            <span class="px-2 py-1 bg-green-100 text-green-700 text-xs font-bold rounded">Online</span>
                        </div>
                        <div class="flex items-center justify-between p-2 bg-gray-50 rounded">
                            <span class="text-sm text-gray-700">API</span>
                            <span class="px-2 py-1 bg-green-100 text-green-700 text-xs font-bold rounded">Running</span>
                        </div>
                        <div class="flex items-center justify-between p-2 bg-gray-50 rounded">
                            <span class="text-sm text-gray-700">Server Load</span>
                            <span class="px-2 py-1 bg-green-100 text-green-700 text-xs font-bold rounded">Normal</span>
                        </div>
                        <p class="text-xs text-gray-500 pt-2">Last update: <?= date('H:i:s') ?></p>
                    </div>
                </div>
            </div>

            <!-- Recent Enrollments -->
            <div class="bg-white rounded-lg shadow p-6">
                <h2 class="text-xl font-bold text-gray-800 mb-6 flex items-center gap-2">
                    <i class="fas fa-history text-blue-600"></i>Recent Enrollments
                </h2>
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead class="bg-gray-50 border-b">
                            <tr>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-700">Student</th>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-700">Course</th>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-700">Payment Status</th>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-700">Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($recent_enrollments as $enrollment): ?>
                                <tr class="border-b hover:bg-gray-50">
                                    <td class="px-6 py-3 text-gray-800"><?= htmlspecialchars($enrollment['fullname']) ?></td>
                                    <td class="px-6 py-3 text-gray-800"><?= htmlspecialchars($enrollment['title']) ?></td>
                                    <td class="px-6 py-3">
                                        <span class="px-3 py-1 rounded-full text-xs font-semibold bg-<?= $enrollment['payment_status'] === 'confirmed' ? 'green' : ($enrollment['payment_status'] === 'pending' ? 'yellow' : 'red') ?>-100 text-<?= $enrollment['payment_status'] === 'confirmed' ? 'green' : ($enrollment['payment_status'] === 'pending' ? 'yellow' : 'red') ?>-800">
                                            <?= ucfirst($enrollment['payment_status']) ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-3 text-gray-600 text-sm"><?= Helper::formatDate($enrollment['enrollment_date']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
