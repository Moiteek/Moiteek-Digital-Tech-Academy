# PAYMENT_SYSTEM.md - Payment Verification & Credential Generation System

Complete guide to the payment verification system for Moiteek Academy.

---

## 📋 **System Overview**

The payment system allows students to:
1. Upload payment proofs (screenshots, receipts, invoices)
2. Track payment status
3. Receive automatic login credentials upon approval

Admins can:
1. Review payment submissions
2. Approve or reject payments
3. Automatically generate and send credentials
4. Track payment history and revenue

---

## 🏗️ **Database Structure**

### **payments Table**

Stores all payment submissions from students:

```sql
CREATE TABLE payments(
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'USD',
    payment_method ENUM('bank_transfer', 'mobile_money', 'paystack', 'flutterwave', 'other'),
    reference_number VARCHAR(100) UNIQUE,
    proof_file_path VARCHAR(255),              -- Path to uploaded proof file
    proof_file_type VARCHAR(50),               -- MIME type (image/jpeg, etc.)
    payment_date_submitted TIMESTAMP NOT NULL, -- When student made the payment
    status ENUM('pending', 'approved', 'rejected', 'cancellation_requested'),
    approval_notes TEXT,                       -- Admin notes on approval
    rejection_reason TEXT,                     -- Why payment was rejected
    approved_by INT,                           -- Admin user ID who approved
    approved_at TIMESTAMP,                     -- When admin took action
    transaction_id VARCHAR(255),               -- For future API integration
    external_api_response LONGTEXT,            -- For future API integration
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    FOREIGN KEY (approved_by) REFERENCES admins(id) ON SET NULL
);
```

---

### **payment_integrations Table**

Stores API configuration for payment gateways (Paystack, Flutterwave, etc.):

```sql
CREATE TABLE payment_integrations(
    id INT AUTO_INCREMENT PRIMARY KEY,
    provider_name ENUM('paystack', 'flutterwave', 'stripe', 'square'),
    is_active TINYINT(1) DEFAULT 0,            -- Enable/disable provider
    api_key VARCHAR(255),                      -- API Public Key
    api_secret VARCHAR(255),                   -- API Secret Key
    webhook_secret VARCHAR(255),               -- Webhook authentication
    test_mode TINYINT(1) DEFAULT 1,            -- Testing vs Production
    webhook_url VARCHAR(255),                  -- For webhooks
    configuration LONGTEXT,                    -- JSON extra config
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_provider (provider_name)
);
```

---

### **payment_transactions Table**

Records automatic transactions from integrated APIs:

```sql
CREATE TABLE payment_transactions(
    id INT AUTO_INCREMENT PRIMARY KEY,
    payment_id INT,                            -- Links to payments table
    transaction_reference VARCHAR(100) UNIQUE,
    provider VARCHAR(50),                      -- 'paystack', 'flutterwave', etc.
    student_id INT NOT NULL,
    amount DECIMAL(10, 2),
    status ENUM('pending', 'success', 'failed', 'abandoned'),
    response_code VARCHAR(50),                 -- API response code
    response_message TEXT,                     -- API response message
    customer_code VARCHAR(100),                -- Paystack customer ref
    authorization_url VARCHAR(500),            -- Payment page URL
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (payment_id) REFERENCES payments(id) ON SET NULL,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);
```

---

## 🎯 **User Workflows**

### **Student: Upload Payment Proof**

**Access:** `/student/upload-payment.php?course_id=123`

**Steps:**
1. Student selects course from dashboard
2. Clicks "Upload Payment Proof"
3. Fills in payment details:
   - Payment date (when they made the payment)
   - Payment method (bank transfer, mobile money, etc.)
   - Amount paid
   - Upload proof file (JPG, PNG, GIF, PDF - max 5MB)
4. System submits form with CSRF token
5. Server validates and stores file
6. Creates payment record with `status = 'pending'`
7. Shows confirmation: "Admin will review shortly"

**File Upload:**
- Files stored in: `uploads/payment_proofs/`
- Naming: `payment_{student_id}_{course_id}_{timestamp}.{ext}`
- Validation: Only images and PDF allowed
- Max size: 5MB

**Database Entry:**
```php
INSERT INTO payments (
    student_id, course_id, amount, currency, 
    payment_method, reference_number, proof_file_path, 
    proof_file_type, payment_date_submitted, status
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')
```

---

### **Student: View Payment Status**

**Access:** `/student/upload-payment.php` (payment history sidebar)

Shows all payments with:
- Course name
- Amount paid
- Reference number
- Current status (pending/approved/rejected)
- Rejection reason (if rejected)

---

### **Admin: Review Payments**

**Access:** `/admin/payments.php`

**Dashboard shows:**
- Statistics: Pending, Approved, Rejected, Total Revenue
- Search functionality (by name, email, reference, course)
- Status filters

**Review Process:**
1. Admin views pending payments
2. Clicks "Review" button on payment
3. Modal shows:
   - Student name
   - Course name
   - Amount
4. Admin can:
   - **Approve:** Optionally add approval notes
   - **Reject:** Must provide rejection reason

---

### **Approval Workflow**

**When Admin Clicks "Approve":**

1. **Update Payment Record:**
   ```php
   UPDATE payments SET 
       status = 'approved',
       approval_notes = ?,
       approved_by = ?,
       approved_at = NOW()
   WHERE id = ?
   ```

2. **Auto-Generate Credentials:**
   ```php
   Auth::createPaymentApprovalCredentials($student_id, $email, $fullname)
   ```
   - Generates unique username from student name
   - Generates 12-character secure password
   - Updates student record with credentials

3. **Send Credentials Email:**
   ```php
   Email::sendPaymentApprovalWithCredentials(
       $email,
       $student_name,
       $course_name,
       $username,
       $password,
       $amount
   )
   ```

4. **Student receives email with:**
   - Payment approval confirmation
   - Course information
   - Login credentials (username & password)
   - Security reminder to change password
   - Link to login page

---

### **Rejection Workflow**

**When Admin Clicks "Reject":**

1. **Update Payment Record:**
   ```php
   UPDATE payments SET 
       status = 'rejected',
       rejection_reason = ?,
       approved_by = ?,
       approved_at = NOW()
   WHERE id = ?
   ```

2. **Send Rejection Email:**
   ```php
   Email::sendPaymentRejection(
       $email,
       $student_name,
       $course_name,
       $rejection_reason
   )
   ```

3. **Student receives email with:**
   - Course and rejection status
   - Reason for rejection
   - Instructions to upload new proof
   - Tips on proper payment evidence
   - Support contact information

---

## 🔐 **Security Features**

### **File Upload Security**

- **File Type Validation:** Only JPG, PNG, GIF, PDF allowed
- **MIME Type Check:** Validates actual file type (not just extension)
- **Size Limit:** Maximum 5MB per file
- **Unique Naming:** Files renamed to prevent conflicts and directory traversal
- **Separate Directory:** Stored outside web root in `uploads/`

### **CSRF Protection**

- All forms include CSRF token (`CSRF::generateTokenField()`)
- Token validated on submission (`CSRF::validateRequest()`)
- Tokens are single-use and expire after 1 hour

### **Access Control**

- Students can only view/upload for own payments
- Admins require login verification (`Auth::isAdminLoggedIn()`)
- Role-based access enforced at page entry

### **Data Validation**

- Amount must match course price or be confirmed
- Reference number must be unique
- Status values are ENUMs (no invalid states)
- Student ID must exist in database

---

## 📧 **Email Templates**

### **1. Payment Approval Email**

Sent when admin approves payment.

**Subject:** Payment Approved! Your Credentials - Moiteek Academy

**Contains:**
- Course information
- Payment amount
- Login username (in code box)
- Login password (in code box)
- Security reminder to change password
- Link to login page
- Next steps guide

**Method:** `Email::sendPaymentApprovalWithCredentials()`

---

### **2. Payment Rejection Email**

Sent when admin rejects payment.

**Subject:** Payment Status Update - Moiteek Academy

**Contains:**
- Course information
- Rejection status
- Reason for rejection
- What student can do next
- Tips on proving payment correctly
- Support contact information
- Link to re-submit proof

**Method:** `Email::sendPaymentRejection()`

---

## 🔄 **Username & Password Generation**

### **Username Generation**

```php
Auth::generateUsername($fullName)
// Example: "John Doe" → "john_doe" or "john_doe_1" if taken
```

**Logic:**
- Converts to lowercase
- Removes special characters
- Replaces spaces with underscores
- Appends numbers if not unique
- Maximum 100 characters

---

### **Password Generation**

```php
Auth::generateSecurePassword($length = 12)
// Returns: e.g. "K9@xL2pQm4$R"
```

**Requirements Met:**
- Minimum 12 characters
- Contains uppercase letters (A-Z)
- Contains lowercase letters (a-z)
- Contains numbers (0-9)
- Contains special characters (@$!%*?&)
- Cryptographically random
- Not predictable

**Security:** Uses `random_int()` for cryptographic randomness

---

## 🛠️ **Admin Functions**

### **Create Payment Approval Credentials**

```php
$result = Auth::createPaymentApprovalCredentials($student_id, $email, $fullName);

// Returns:
[
    'username' => 'john_doe',
    'password' => 'K9@xL2pQm4$R',
    'success' => true
]
```

**What It Does:**
1. Generates unique username
2. Generates secure password
3. Hashes password with bcrypt
4. Updates student record
5. Sends email with credentials
6. Returns generated credentials

---

### **Credential Storage**

Credentials stored in `students` table:

```sql
ALTER TABLE students ADD COLUMN username VARCHAR(100) UNIQUE;
ALTER TABLE students ADD COLUMN password VARCHAR(255);
ALTER TABLE students ADD COLUMN approved INT DEFAULT 0;
ALTER TABLE students ADD COLUMN email_verified TINYINT(1) DEFAULT 0;
```

- **username:** Unique, human-readable identifier
- **password:** Bcrypt hashed (cost 10)
- **approved:** Set to 1 when payment approved
- **email_verified:** Set to 1 when payment approved

---

## 📊 **API Preparation (Future)**

The system is structured to easily add Paystack/Flutterwave integration:

### **Step 1: Add API Configuration**

```php
// In payment_integrations table
INSERT INTO payment_integrations (provider_name, is_active, api_key, api_secret)
VALUES ('paystack', 1, 'pk_live_xxxxx', 'sk_live_xxxxx');
```

### **Step 2: Create Payment with API**

```php
// Paystack Integration (ready to implement)
class PaymentGateway {
    public static function initializePaystack($email, $amount, $reference) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://api.paystack.co/transaction/initialize');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
            'email' => $email,
            'amount' => $amount * 100,  // In kobo (cents)
            'reference' => $reference
        ]));
        // ... execute
    }
}
```

### **Step 3: Handle Webhook**

```php
// POST /webhook/payment.php
$event = json_decode(file_get_contents('php://input'));

if ($event->event === 'charge.success') {
    $payment_id = // extract from reference
    // Update payment status to 'approved'
    // Generate credentials
    // Send email
}
```

### **Existing Database Support:**

- `payment_integrations` table ready for API keys
- `payment_transactions` table ready for API responses
- `payment.transaction_id` and `external_api_response` fields ready
- Structure supports multiple providers (Paystack, Flutterwave, Stripe, Square)

---

## ✅ **Implementation Checklist**

**Database:**
- [ ] `payments` table created
- [ ] `payment_integrations` table created
- [ ] `payment_transactions` table created
- [ ] All indexes added
- [ ] Foreign keys configured

**PHP Code:**
- [ ] Auth methods added (generateUsername, generateSecurePassword, createPaymentApprovalCredentials)
- [ ] Email methods added (sendPaymentApprovalWithCredentials, sendPaymentRejection)
- [ ] File upload directory created (`uploads/payment_proofs/`)

**Pages:**
- [ ] `/student/upload-payment.php` created
- [ ] `/admin/payments.php` updated
- [ ] Course enrollment links payment page

**Configuration:**
- [ ] File upload directory permissions (755)
- [ ] Maximum upload size in php.ini (5MB)
- [ ] Email configuration (SMTP or mail function)

---

## 🧪 **Testing Payment Workflow**

### **Test as Student:**

1. Register as new student
2. Browse courses
3. Click "Enroll" → "Upload Payment Proof"
4. Fill in form:
   - Payment date: Yesterday
   - Method: Bank Transfer
   - Amount: Course price
   - Proof: Any JPG/PNG image
5. Submit
6. See confirmation message
7. Check payment history

### **Test as Admin:**

1. Go to admin dashboard
2. Click "Payments"
3. See pending payment
4. Click "Review"
5. Modal appears with details
6. Click "Approve" (or "Reject")
7. Student gets email
8. Student can login with generated credentials

### **Test Credentials:**

Generated username and password should:
- [ ] Allow immediate login
- [ ] Require password change on first login
- [ ] Persist in session
- [ ] Work across page navigation

---

## 🚀 **Deployment Notes**

### **Before Going Live:**

1. **Configure Email:**
   - Set SMTP credentials in `config/db.php`
   - Test email sending with test account

2. **Setup File Uploads:**
   ```bash
   mkdir -p /var/www/moiteek/uploads/payment_proofs/
   chmod 755 /var/www/moiteek/uploads/payment_proofs/
   ```

3. **Security:**
   - Set HTTPS in `config/db.php`
   - Enable secure cookies
   - Configure CORS for payment APIs

4. **Testing:**
   - Test file upload with max size files
   - Test email delivery
   - Test credential generation
   - Test edge cases (duplicate usernames, etc.)

---

## 📞 **Support**

**For developers:**
- Check `DEVELOPER_GUIDE.md` for code examples
- See `SECURITY.md` for security best practices
- Review `DATABASE_MIGRATION.md` for schema updates

**For users:**
- Payment proof tips and guidelines
- Troubleshooting upload issues
- Credential recovery procedures

---

## 📌 **Future Enhancements**

- [ ] **Direct API integration:** Paystack, Flutterwave, Stripe
- [ ] **Automated webhook processing:**Process payments automatically
- [ ] **Payment receipts:** Generate and send PDF receipts
- [ ] **Refund management:** Track and process refunds
- [ ] **Analytics dashboard:** Track revenue trends
- [ ] **Tax reporting:** Generate tax reports
- [ ] **Payment reminders:** Auto-remind pending students
- [ ] **Subscription support:** Recurring payments
- [ ] **Multi-currency:** Support for different currencies
- [ ] **Partial payments:** Allow installment plans

---

**Last Updated:** February 2026
**Status:** Production Ready ✅
