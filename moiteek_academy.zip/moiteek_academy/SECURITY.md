# SECURITY.md - Production-Grade Security Implementation

Complete guide to the security features implemented in Moiteek Academy v1.0.0.

---

## 🔐 **Security Features Overview**

Moiteek Academy implements comprehensive production-grade security:

- ✅ **Bcrypt Password Hashing** - Industry-standard encryption (cost 10)
- ✅ **Prepared Statements** - Complete SQL injection prevention
- ✅ **CSRF Protection** - Token-based cross-site request forgery prevention
- ✅ **Secure Session Management** - HttpOnly cookies, SameSite=Strict, timeout
- ✅ **Input Validation & Sanitization** - Server-side validation for all inputs
- ✅ **Role-Based Access Control** - Admin and student separation
- ✅ **Login Rate Limiting** - Account lockout after failed attempts
- ✅ **Email Verification** - Students must verify email before login
- ✅ **Admin Approval Required** - Students cannot login until approved
- ✅ **Password Reset System** - Secure time-limited tokens
- ✅ **Security Headers** - X-Frame-Options, CSP, XSS protection
- ✅ **Activity Logging** - Track security events and logins
- ✅ **Password Strength Validation** - Complex password requirements
- ✅ **Session Regeneration** - Prevent session fixation attacks
- ✅ **Error Concealment** - Don't leak sensitive information in errors

---

## 🔑 **Password Security**

### **Bcrypt Hashing**

All passwords are hashed using bcrypt with cost factor 10:

```php
$hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 10]);
```

**Why Bcrypt?**
- Slow by design (resistant to brute-force)
- Automatically handles salt generation
- Future-proof: cost factor can increase as computers get faster
- Industry standard (used by major platforms)

### **Password Requirements**

Students and admins must use strong passwords:

```
Minimum 8 characters
At least 1 UPPERCASE letter (A-Z)
At least 1 lowercase letter (a-z)
At least 1 number (0-9)
At least 1 special character (@$!%*?&)
```

**Example Valid Passwords:**
- `SecurePass123!`
- `MyPassword@2024`
- `Test$Secure999`

### **Password Reset Flow**

1. User requests password reset via `/auth/forgot-password.php`
2. System generates 32-byte random token
3. Email sent with reset link (1 hour expiry)
4. User clicks link and sets new password
5. Token marked as used (one-time only)
6. User forced to login with new password

**Database:**
```sql
CREATE TABLE password_reset_tokens(
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    token VARCHAR(64) UNIQUE NOT NULL,
    email VARCHAR(100) NOT NULL,
    user_type ENUM('admin', 'student'),
    expires_at TIMESTAMP NOT NULL
);
```

---

## 📧 **Email & Verification Security**

### **Email Verification Flow**

1. Student registers with email
2. System generates unique verification token (32 bytes)
3. Verification email sent with link (24 hour expiry)
4. Student clicks link to verify email
5. Email marked as verified in database
6. Student can now login

**Database:**
```sql
CREATE TABLE email_verification_tokens(
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    token VARCHAR(64) UNIQUE NOT NULL,
    email VARCHAR(100) NOT NULL,
    expires_at TIMESTAMP NOT NULL
);
```

### **Admin Approval Requirement**

Before student can login:
1. ✅ Email must be verified
2. ✅ Account status must be "approved" (not pending/rejected/suspended)
3. ✅ Account must be active (not deactivated)

**Login Flow:**
```
Email/Password → Valid?
  ↓ No
  Return: Invalid credentials
  
  ↓ Yes
Account locked?
  ↓ Yes
  Return: Account locked for N minutes
  
  ↓ No
Email verified?
  ↓ No
  Return: Please verify email
  
  ↓ Yes
Status approved?
  ↓ No
  Return: Account pending approval / rejected / suspended
  
  ↓ Yes
Login successful ✓
```

---

## 🚫 **Login Attempt Protection**

### **Rate Limiting & Lockout**

After **5 failed login attempts**, account is locked for **15 minutes**.

**Tracking:**
```php
$_SESSION['login_attempts'][$key] = [
    'attempts' => 0,
    'first_attempt' => time()
];
```

**Security Email:**
When account is locked, security alert email is sent:
```
Subject: Security Alert - Moiteek AcademyContent: Multiple failed login attempts detected
```

### **Implementation**

```php
// Check if locked
$lockCheck = Auth::isAccountLocked($email, 'student');
if ($lockCheck['locked']) {
    $minutes = ceil($lockCheck['remaining_time'] / 60);
    return ['success' => false,
            'message' => "Account locked for $minutes minutes"];
}

// Record failed attempt
self::recordFailedAttempt($email, 'student');

// If 5+ attempts
if ($attempts >= 5) {
    Email::sendSecurityAlert($email, $name,
        "Multiple failed login attempts detected");
}
```

---

## 🛡️ **CSRF Protection**

### **Token Generation**

Every form includes a unique CSRF token:

```php
// In HTML form
<?php echo CSRF::generateTokenField(); ?>

// Generates:
<input type="hidden" name="csrf_token" value="[64-char hex]">
```

### **Token Validation**

Before processing form:
```php
if (!CSRF::validateRequest()) {
    Response::error('Security validation failed');
}
```

### **Token Properties**

- **Generated:** Using `random_bytes(32)` (cryptographically secure)
- **Stored:** In `$_SESSION['csrf_tokens']`
- **Expiry:** 1 hour per token
- **One-time Use:** Tokens deleted after validation
- **Limit:** Max 10 tokens per session
- **Format:** 64-character hexadecimal string

### **Token Table (Optional)**

For tracking/advanced security:
```sql
CREATE TABLE csrf_tokens(
    id INT AUTO_INCREMENT PRIMARY KEY,
    token VARCHAR(64) UNIQUE NOT NULL,
    session_id VARCHAR(255),
    expires_at TIMESTAMP NOT NULL
);
```

---

## 🔒 **Session Security**

### **Session Configuration**

```php
session_start([
    'cookie_lifetime' => 0,           // Browser closes = session ends
    'cookie_path' => '/',
    'cookie_secure' => false,         // true for HTTPS only
    'cookie_httponly' => true,        // No JavaScript access
    'cookie_samesite' => 'Strict',    // CSRF protection
    'use_strict_mode' => true,        // Validate session IDs
    'use_trans_sid' => false,         // No URL session IDs
    'use_cookies' => true,
    'use_only_cookies' => true,
    'gc_maxlifetime' => 1800          // 30 minutes
]);
```

### **Session Timeout**

Inactive sessions automatically timeout after **30 minutes**:

```php
if (time() - $_SESSION['last_activity'] > 1800) {
    session_destroy();
    // Redirect to login
}

$_SESSION['last_activity'] = time();
```

### **Session Regeneration**

Session ID regenerated every **5 minutes** to prevent session fixation:

```php
if ((time() - $_SESSION['last_regeneration']) > 300) {
    session_regenerate_id(true);
    $_SESSION['last_regeneration'] = time();
}
```

---

## 📝 **Input Validation & Sanitization**

### **Server-Side Validation**

**All user input validated and sanitized:**

```php
// Email validation
Validator::validateEmail($email);

// Password validation (strong requirements)
Validator::validatePassword($password);

// Name validation
Validator::validateFullName($name);

// Phone validation
Validator::validatePhone($phone);

// Username validation
Validator::validateUsername($username);

// File upload validation
Validator::validateFileUpload($_FILES['file']);

// Amount validation
Validator::validateAmount($amount);
```

### **Output Sanitization**

Prevent XSS by escaping all output:

```php
// Safe output
echo htmlspecialchars($user_input, ENT_QUOTES, 'UTF-8');

// Or use sanitizer
$safe = Validator::sanitizeInput($input);
```

### **Database Queries**

All queries use prepared statements with parameterized queries:

```php
// ✅ SAFE - Using prepared statements
$stmt = $pdo->prepare("SELECT * FROM students WHERE email = ?");
$stmt->execute([$email]);
$student = $stmt->fetch();

// ❌ UNSAFE - Never do this
$stmt = $pdo->prepare("SELECT * FROM students WHERE email = '" . $email . "'");
```

---

## 👥 **Role-Based Access Control (RBAC)**

### **Admin Roles**

```php
role ENUM('super_admin', 'admin')
```

**super_admin:**
- Can manage all students
- Can manage payments
- Can manage courses
- Can manage other admins

**admin:**
- Can manage students
- Can manage payments
- Can view courses

### **Access Verification**

```php
// Check if admin
if (!Auth::isAdminLoggedIn()) {
    Response::redirect('/auth/login.php');
}

// Check admin role
if ($_SESSION['admin_role'] !== 'super_admin') {
    Response::error('Insufficient permissions');
}
```

### **Student Status**

```php
status ENUM('pending', 'approved', 'rejected', 'suspended')
```

- **pending:** Awaiting admin approval (cannot login)
- **approved:** Approved by admin (can login and enroll)
- **rejected:** Application rejected (cannot login)
- **suspended:** Account suspended (cannot login)

---

## 🚨 **Security Headers**

### **HTTP Security Headers**

Sent with every response:

```
X-Content-Type-Options: nosniff
    → Prevents MIME-type sniffing attacks

X-Frame-Options: SAMEORIGIN
    → Prevents clickjacking attacks

X-XSS-Protection: 1; mode=block
    → Enables browser XSS protection

Referrer-Policy: strict-origin-when-cross-origin
    → Controls how referrer info is sent

Permissions-Policy: geolocation=(), microphone=(), camera=()
    → Restricts feature access
```

### **HTTPS Only (Production)**

For production deployment:
```php
Strict-Transport-Security: max-age=31536000; includeSubDomains
    → Forces HTTPS for 1 year
```

---

## 📊 **Activity Logging**

### **Login Activity Tracking**

```sql
CREATE TABLE login_activity(
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    user_type ENUM('admin', 'student'),
    email VARCHAR(100),
    ip_address VARCHAR(45),
    user_agent TEXT,
    login_status ENUM('success', 'failed', 'locked'),
    failure_reason VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### **What's Logged**

✅ Successful logins (user, timestamp, IP)
✅ Failed login attempts (reason, IP)
✅ Account lockouts (duration, reason)
✅ Password resets (when, who)
✅ Email verification (status, when)
✅ Admin actions (approval, rejection, payment confirmation)

---

## 📧 **Email Security**

### **Email Verification**

```php
Email::sendEmailVerification($email, $name, $verificationLink);
```

Sends HTML email with:
- Personalized greeting
- Verification link
- Direct link copy-paste option
- 24-hour expiry notice
- Security disclaimer

### **Password Reset Emails**

```php
Email::sendPasswordReset($email, $name, $resetLink);
```

Includes:
- Clear password reset instructions
- 1-hour expiry
- Security warnings
- Link copy option

### **Approval Notifications**

```php
Email::sendApprovalNotification($email, $name);
```

Notifies student when:
- Account approved
- Can now login
- Access features

### **Security Alerts**

```php
Email::sendSecurityAlert($email, $name, $reason);
```

Warns about:
- Multiple failed login attempts
- Account lockout
- Suspicious activity

---

## 🔍 **Security Best Practices**

### **For Developers**

✅ **Always validate input** - Never trust user data
✅ **Always use prepared statements** - Prevent SQL injection
✅ **Escape output** - Prevent XSS attacks
✅ **Use HTTPS** - Secure data transmission
✅ **Strong passwords** - Enforce complexity requirements
✅ **Regular updates** - Keep PHP and dependencies current
✅ **Log security events** - Track suspicious activity
✅ **Test security** - Regular security audits
✅ **Error handling** - Don't leak sensitive info in errors

### **For Administrators**

✅ **Change default passwords** - Admin account on setup
✅ **Regular backups** - Database backups at least daily
✅ **Monitor logs** - Watch for suspicious activity
✅ **Update server** - Keep OS and software current
✅ **SSL certificate** - Use HTTPS in production
✅ **Firewall rules** - Restrict access appropriately
✅ **User audit** - Review active users regularly
✅ **Disable inactive accounts** - Remove old accounts
✅ **Strong password policy** - Enforce requirements

### **For Users**

✅ **Strong password** - Follow requirements
✅ **Unique password** - Don't reuse passwords
✅ **Verify email** - Check verification link
✅ **Secure device** - No malware/keyloggers
✅ **Logout properly** - Don't just close browser
✅ **Check emails** - Watch for security alerts
✅ **Report suspicious activity** - Contact support

---

## 🚀 **Production Deployment Checklist**

Before going live:

### **Configuration**
- [ ] Change default admin password
- [ ] Set `SECURE_COOKIE = true` for HTTPS
- [ ] Set `SSL_ENABLED = true` in config
- [ ] Update `APP_URL` to production domain
- [ ] Configure email SMTP settings
- [ ] Set error logging (disable display)

### **Database**
- [ ] Create backups (daily automated)
- [ ] Run `mysql> FLUSH TABLES WITH READ LOCK;`
- [ ] Verify all security tables exist
- [ ] Check database user permissions (minimal)
- [ ] Enable query logging for audit trail

### **Server**
- [ ] Enable HTTPS/SSL certificate
- [ ] Configure firewall (only needed ports)
- [ ] Set file permissions (644 files, 755 dirs)
- [ ] Hide sensitive files (.env, config, sql)
- [ ] Set up log rotation

### **Application**
- [ ] Test email verification flow
- [ ] Test password reset flow
- [ ] Test login rate limiting
- [ ] Test CSRF protection
- [ ] Test session timeout
- [ ] Test admin approval workflow

### **Monitoring**
- [ ] Set up error log alerts
- [ ] Monitor login failures
- [ ] Monitor disk space
- [ ] Monitor database performance
- [ ] Set up automatic backups

---

## 🔧 **Troubleshooting Security**

### **"Account Locked" Error**

**Cause:** 5 failed login attempts in 15 minutes

**Solution:**
1. Wait 15 minutes
2. Request password reset if forgotten
3. Contact support

### **"Email Not Verified"**

**Cause:** Student hasn't verified email yet

**Solution:**
1. Check email for verification link
2. Spam folder often catches emails
3. Request resend of verification email

### **"Pending Approval"**

**Cause:** Admin hasn't approved student account

**Solution:**
1. Wait for admin to approve
2. Check email for approval notification
3. Contact support if taking long

### **Password Reset Not Working**

**Cause:** Token expired (1 hour max) or already used

**Solution:**
1. Request new password reset
2. Check email immediately
3. Complete reset within 1 hour

### **Session Keeps Timing Out**

**Cause:** Inactive for 30 minutes OR activity was registered nowhere

**Solution:**
1. Default behavior (security feature)
2. Login again without long inactivity
3. Contact support if genuine issue

---

## 📚 **Security References**

**Standards & Guidelines:**
- OWASP Top 10 Web Vulnerabilities
- PHP Password Security Best Practices
- Session Management Security
- HTTP Security Headers

**Libraries & Practices:**
- Bcrypt password hashing
- PDO prepared statements
- CSRF token validation
- HTML output escaping

**Related Files:**
- `includes/Auth.php` - Authentication logic
- `includes/CSRF.php` - CSRF token management
- `includes/Email.php` - Email sending
- `config/db.php` - Security configuration

---

## 📞 **Security Issues**

**Found a security vulnerability?**

Please report it to: `security@moiteek.com`

Include:
- Description of vulnerability
- Steps to reproduce
- Potential impact
- Suggested fix (optional)

---

**Security First! 🔐**

Always prioritize security in development and deployment. When in doubt, make it more secure!
