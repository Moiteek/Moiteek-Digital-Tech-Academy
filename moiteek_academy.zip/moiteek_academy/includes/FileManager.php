<?php
/**
 * Utilities/Helper Functions
 * Common utility functions used throughout the app
 */

class FileManager {
    const UPLOAD_DIR = __DIR__ . '/../uploads/';
    const ALLOWED_EXTENSIONS = ['jpg', 'jpeg', 'png', 'pdf'];
    const MAX_FILE_SIZE = 5242880; // 5MB

    /**
     * Upload file with validation
     */
    public static function uploadFile($file, $destination = 'payments/') {
        // Create upload directory if it doesn't exist
        $upload_path = self::UPLOAD_DIR . $destination;
        if(!is_dir($upload_path)) {
            mkdir($upload_path, 0755, true);
        }

        // Validate file
        if($file['error'] != UPLOAD_ERR_OK) {
            return ['success' => false, 'message' => 'File upload error'];
        }

        if($file['size'] > self::MAX_FILE_SIZE) {
            return ['success' => false, 'message' => 'File size too large'];
        }

        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if(!in_array($ext, self::ALLOWED_EXTENSIONS)) {
            return ['success' => false, 'message' => 'Invalid file type'];
        }

        // Generate unique filename
        $filename = uniqid() . '_' . time() . '.' . $ext;
        $filepath = $upload_path . $filename;

        if(move_uploaded_file($file['tmp_name'], $filepath)) {
            return ['success' => true, 'filename' => $destination . $filename];
        }

        return ['success' => false, 'message' => 'Failed to save file'];
    }

    /**
     * Delete file
     */
    public static function deleteFile($filename) {
        $filepath = self::UPLOAD_DIR . $filename;
        if(file_exists($filepath)) {
            unlink($filepath);
            return true;
        }
        return false;
    }
}

class Helper {
    /**
     * Format currency
     */
    public static function formatCurrency($amount, $currency = 'USD') {
        return '$' . number_format($amount, 2);
    }

    /**
     * Format date
     */
    public static function formatDate($date, $format = 'M d, Y') {
        return date($format, strtotime($date));
    }

    /**
     * Format time ago (e.g., "2 hours ago")
     */
    public static function timeAgo($datetime) {
        $time = strtotime($datetime);
        $now = time();
        $ago = $now - $time;

        $day = 86400;
        $hour = 3600;
        $minute = 60;

        if($ago > $day) return $ago / $day . ' days ago';
        if($ago > $hour) return floor($ago / $hour) . ' hours ago';
        if($ago > $minute) return floor($ago / $minute) . ' minutes ago';
        return 'just now';
    }

    /**
     * Generate unique ID/reference
     */
    public static function generateReference($prefix = 'REF') {
        return $prefix . '-' . strtoupper(substr(md5(uniqid()), 0, 8));
    }

    /**
     * Slugify string
     */
    public static function slugify($text) {
        $text = preg_replace('~[^\pL\d]+~u', '-', $text);
        $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);
        $text = preg_replace('~[^-\w]+~', '', $text);
        $text = preg_replace('~-+~', '-', $text);
        return strtolower(trim($text, '-'));
    }

    /**
     * Get file extension
     */
    public static function getExtension($filename) {
        return strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    }

    /**
     * Check if email is valid
     */
    public static function isValidEmail($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }

    /**
     * Redirect to URL
     */
    public static function redirect($url) {
        header("Location: $url");
        exit();
    }

    /**
     * Get current URL
     */
    public static function getCurrentURL() {
        return (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
    }

    /**
     * Get base URL
     */
    public static function getBaseURL() {
        return (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]/moiteek_academy";
    }
}
?>