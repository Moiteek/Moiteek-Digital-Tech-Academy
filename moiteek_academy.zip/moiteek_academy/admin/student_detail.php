<?php
require_once '../bootstrap.php';

if(!Auth::isAdminLoggedIn()) {
    Response::redirect('../admin/login.php', 'Please login', 'error');
}

$student_id = Validator::sanitizeInput($_GET['id'] ?? '');
if(!$student_id || !is_numeric($student_id)) {
    Response::redirect('students.php', 'Invalid student', 'error');
}

$student = Database::getUserById($student_id, 'students');
if(!$student) {
    Response::redirect('students.php', 'Student not found', 'error');
}

// Get enrollments
$stmt = $pdo->prepare("
    SELECT e.*, c.title, c.slug, c.price
    FROM enrollments e
    JOIN courses c ON e.course_id = c.id
    WHERE e.student_id = ?
    ORDER BY e.enrollment_date DESC
");
$stmt->execute([$student_id]);
$enrollments = $stmt->fetchAll();

$flash = Response::getFlashMessage();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Details - <?= APP_NAME ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <a href="students.php" class="text-blue-600 hover:text-blue-700">
                    <i class="fas fa-arrow-left"></i>
                </a>
                <h1 class="text-lg font-bold">Student Details</h1>
            </div>
            <a href="../auth/logout.php" class="p-2 text-gray-600 hover:bg-red-50 rounded-lg">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </nav>

    <div class="max-w-4xl mx-auto p-8 space-y-8">
        <!-- Student Info -->
        <div class="bg-white rounded-lg shadow p-6">
            <div class="flex items-center gap-6 mb-6">
                <div class="w-20 h-20 bg-blue-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-user text-3xl text-blue-600"></i>
                </div>
                <div class="flex-1">
                    <h2 class="text-2xl font-bold text-gray-800"><?= htmlspecialchars($student['fullname']) ?></h2>
                    <p class="text-gray-600">@<?= htmlspecialchars($student['username']) ?></p>
                    <span class="inline-block mt-2 px-3 py-1 rounded-full text-xs font-semibold bg-<?= $student['status'] === 'approved' ? 'green' : ($student['status'] === 'pending' ? 'yellow' : 'red') ?>-100 text-<?= $student['status'] === 'approved' ? 'green' : ($student['status'] === 'pending' ? 'yellow' : 'red') ?>-800">
                        <?= ucfirst($student['status']) ?>
                    </span>
                </div>
            </div>

            <div class="grid grid-cols-2 gap-6">
                <div>
                    <p class="text-sm text-gray-600">Email</p>
                    <p class="text-lg font-semibold text-gray-800"><?= htmlspecialchars($student['email']) ?></p>
                </div>
                <div>
                    <p class="text-sm text-gray-600">Phone</p>
                    <p class="text-lg font-semibold text-gray-800"><?= htmlspecialchars($student['phone']) ?></p>
                </div>
                <div>
                    <p class="text-sm text-gray-600">Enrolled Date</p>
                    <p class="text-lg font-semibold text-gray-800"><?= Helper::formatDate($student['enrollment_date']) ?></p>
                </div>
                <div>
                    <p class="text-sm text-gray-600">Last Login</p>
                    <p class="text-lg font-semibold text-gray-800"><?= $student['last_login'] ? Helper::formatDate($student['last_login']) : 'Never' ?></p>
                </div>
            </div>
        </div>

        <!-- Courses Enrolled -->
        <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
                <i class="fas fa-book text-blue-600"></i>Enrolled Courses
            </h3>
            <div class="space-y-4">
                <?php if(empty($enrollments)): ?>
                    <p class="text-gray-600 text-center py-8">No enrollments</p>
                <?php else: ?>
                    <?php foreach($enrollments as $enrollment): ?>
                        <div class="p-4 border border-gray-200 rounded-lg">
                            <div class="flex items-center justify-between">
                                <div>
                                    <h4 class="font-semibold text-gray-800"><?= htmlspecialchars($enrollment['title']) ?></h4>
                                    <p class="text-sm text-gray-600">Enrolled: <?= Helper::formatDate($enrollment['enrollment_date']) ?></p>
                                </div>
                                <div class="text-right">
                                    <p class="text-sm text-gray-600">Price</p>
                                    <p class="font-bold text-gray-800"><?= Helper::formatCurrency($enrollment['price']) ?></p>
                                    <span class="inline-block mt-2 px-2 py-1 rounded text-xs font-semibold bg-<?= $enrollment['payment_status'] === 'confirmed' ? 'green' : ($enrollment['payment_status'] === 'pending' ? 'yellow' : 'red') ?>-100 text-<?= $enrollment['payment_status'] === 'confirmed' ? 'green' : ($enrollment['payment_status'] === 'pending' ? 'yellow' : 'red') ?>-800">
                                        <?= ucfirst($enrollment['payment_status']) ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>