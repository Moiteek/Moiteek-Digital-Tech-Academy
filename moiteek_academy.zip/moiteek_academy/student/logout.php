<?php
require_once __DIR__ . '/../includes/bootstrap.php';
// Destroy session and redirect to home
session_unset();
session_destroy();
header('Location: ../index.php');
exit;
