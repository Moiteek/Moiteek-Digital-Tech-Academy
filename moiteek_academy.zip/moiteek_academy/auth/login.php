
<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/Database.php';

// Redirect if already logged in
if (Auth::isStudentLoggedIn()) {
    Response::redirect('../student/dashboard.php');
}

// Handle AJAX login (must be checked before regular POST so we can exit early)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax'])) {
    $email    = Validator::sanitizeInput($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $response = ['status' => 'error', 'message' => 'Email and password are required'];

    if (!empty($email) && !empty($password)) {
        $result = Auth::loginStudent($email, $password);
        $response = $result['success']
            ? ['status' => 'success', 'message' => 'Welcome back!']
            : ['status' => 'error',   'message' => $result['message']];
    }

    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}

// Handle standard form POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = Validator::sanitizeInput($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error = 'Email and password are required';
    } else {
        $result = Auth::loginStudent($email, $password);
        if ($result['success']) {
            Response::redirect('../student/dashboard.php', 'Welcome back!', 'success');
        } else {
            $error = $result['message'];
        }
    }
}

$flash = Response::getFlashMessage();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Login - <?= APP_NAME ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gradient-to-br from-indigo-600 to-purple-800 min-h-screen flex items-center justify-center p-4">
    <div class="w-full max-w-md">
        <!-- Logo/Header -->
        <div class="text-center mb-8">
            <div class="bg-white rounded-lg p-4 mb-4 inline-block shadow-lg">
                <i class="fas fa-book-open text-3xl text-indigo-600"></i>
            </div>
            <h1 class="text-3xl font-bold text-white"><?= APP_NAME ?></h1>
            <p class="text-indigo-100 mt-2">Student Portal</p>
        </div>

        <!-- Login Card -->
        <div class="bg-white rounded-xl shadow-2xl overflow-hidden">
            <div class="bg-gradient-to-r from-indigo-600 to-purple-600 p-6">
                <h2 class="text-2xl font-bold text-white">Student Login</h2>
                <p class="text-indigo-100">Access your learning dashboard</p>
            </div>

            <!-- Flash Message -->
            <?php if ($flash): ?>
                <div class="mx-6 mt-6 p-4 rounded-lg bg-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-50 border border-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-200">
                    <p class="text-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-700 flex items-center gap-2">
                        <i class="fas fa-<?= $flash['type'] === 'error' ? 'exclamation-circle' : 'check-circle' ?>"></i>
                        <?= htmlspecialchars($flash['message']) ?>
                    </p>
                </div>
            <?php endif; ?>

            <!-- Validation Error -->
            <?php if (isset($error)): ?>
                <div class="mx-6 mt-6 p-4 rounded-lg bg-red-50 border border-red-200">
                    <p class="text-red-700 flex items-center gap-2">
                        <i class="fas fa-exclamation-circle"></i>
                        <?= htmlspecialchars($error) ?>
                    </p>
                </div>
            <?php endif; ?>

            <!-- Form -->
            <form method="POST" class="p-6 space-y-6">
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                        <i class="fas fa-envelope mr-2 text-indigo-600"></i>Email or Username
                    </label>
                    <input
                        type="text"
                        name="email"
                        value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '' ?>"
                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition"
                        placeholder="student@example.com"
                        required
                    >
                </div>

                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                        <i class="fas fa-lock mr-2 text-indigo-600"></i>Password
                    </label>
                    <input
                        type="password"
                        name="password"
                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition"
                        placeholder="••••••••"
                        required
                    >
                </div>

                <button
                    type="submit"
                    class="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-bold py-3 rounded-lg transition shadow-lg hover:shadow-xl"
                >
                    <i class="fas fa-sign-in-alt mr-2"></i>Login to Your Account
                </button>
            </form>

            <!-- Footer -->
            <div class="bg-gray-50 px-6 py-4 border-t border-gray-200">
                <div class="flex items-center text-sm text-gray-600 gap-2">
                    <i class="fas fa-info-circle text-indigo-600"></i>
                    <span>Don't have an account? <a href="../courses.php" class="text-indigo-600 font-semibold hover:text-indigo-700">Enroll now</a></span>
                </div>
            </div>
        </div>

        <!-- Links -->
        <div class="text-center mt-6 text-indigo-100">
            <p><a href="../" class="underline hover:text-white"><i class="fas fa-home mr-1"></i>Return to Home</a></p>
        </div>
    </div>
</body>
</html>
