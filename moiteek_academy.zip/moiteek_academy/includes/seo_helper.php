<?php
// includes/seo_helper.php
function generateMetaTags($title, $description, $image = null) {
    $siteUrl = 'https://moiteek.com';
    $meta = "<title>" . htmlspecialchars($title) . "</title>\n";
    $meta .= "<meta name='description' content='" . htmlspecialchars($description) . "'>\n";
    $meta .= "<meta property='og:title' content='" . htmlspecialchars($title) . "'>\n";
    $meta .= "<meta property='og:description' content='" . htmlspecialchars($description) . "'>\n";
    $meta .= "<meta property='og:type' content='website'>\n";
    $meta .= "<meta property='og:url' content='" . $siteUrl . $_SERVER['REQUEST_URI'] . "'>\n";
    if ($image) {
        $meta .= "<meta property='og:image' content='" . htmlspecialchars($image) . "'>\n";
    }
    $meta .= "<meta name='twitter:card' content='summary_large_image'>\n";
    $meta .= "<meta name='twitter:title' content='" . htmlspecialchars($title) . "'>\n";
    $meta .= "<meta name='twitter:description' content='" . htmlspecialchars($description) . "'>\n";
    if ($image) {
        $meta .= "<meta name='twitter:image' content='" . htmlspecialchars($image) . "'>\n";
    }
    return $meta;
}
