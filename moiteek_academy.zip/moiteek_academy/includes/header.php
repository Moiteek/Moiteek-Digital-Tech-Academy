<?php
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}
$role = $_SESSION['role'] ?? null;
$isAdmin = isset($_SESSION['admin_id']);
$isStudent = isset($_SESSION['student_id']);
?>
<nav class="sticky top-0 z-50 bg-blue-900 shadow-md">
  <div class="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
    <a href="index.php" class="flex items-center gap-2">
      <i class="fas fa-graduation-cap text-3xl text-gold-400"></i>
      <span class="font-bold text-xl text-gold-400">Moiteek Academy</span>
    </a>
    <div class="flex items-center gap-3">
      <?php if ($role === 'admin'): ?>
        <a href="admin/dashboard.php" class="text-gold-400 hover:text-white font-semibold">
          <i class="fas fa-tachometer-alt mr-1"></i>Dashboard
        </a>
        <a href="admin/logout.php" class="text-gold-400 hover:text-white font-semibold">
          <i class="fas fa-sign-out-alt mr-1"></i>Logout
        </a>
      <?php elseif ($role === 'student'): ?>
        <a href="student/dashboard.php" class="text-gold-400 hover:text-white font-semibold">
          <i class="fas fa-tachometer-alt mr-1"></i>Dashboard
        </a>
        <a href="student/logout.php" class="text-gold-400 hover:text-white font-semibold">
          <i class="fas fa-sign-out-alt mr-1"></i>Logout
        </a>
      <?php else: ?>
        <a href="auth/login.php" class="text-gold-400 hover:text-white font-semibold">
          <i class="fas fa-sign-in-alt mr-1"></i>Login
        </a>
        <a href="auth/register.php" class="text-gold-400 hover:text-white font-semibold">
          <i class="fas fa-user-plus mr-1"></i>Register
        </a>
      <?php endif; ?>
      <a href="courses.php" class="text-gold-400 hover:text-white font-semibold">
        <i class="fas fa-book mr-1"></i>Courses
      </a>
      <a href="index.php" class="text-gold-400 hover:text-white font-semibold">
        <i class="fas fa-home mr-1"></i>Home
      </a>
    </div>
  </div>
</nav>
<style>
  .container, .max-w-7xl {
    max-width: 1120px;
    margin-left: auto;
    margin-right: auto;
  }
  .bg-blue-900 { background-color: #0a2540 !important; }
  .text-gold-400 { color: #FFD700 !important; }
  .hover\:text-white:hover { color: #fff !important; }
</style>
    <script>
    function showToast(type, message) {
      Swal.fire({
        toast: true,
        position: 'top-end',
        icon: type,
        title: message,
        showConfirmButton: false,
        timer: 3500,
        timerProgressBar: true
      });
    }
    // Session-based PHP alerts (refactored)
    document.addEventListener('DOMContentLoaded', function() {
      <?php if (isset($_SESSION['alert'])): ?>
        showToast('<?php echo $_SESSION['alert']['type']; ?>', '<?php echo $_SESSION['alert']['message']; ?>');
        <?php unset($_SESSION['alert']); ?>
      <?php endif; ?>
    });
  </script>
</head>
<body class="bg-gray-50 min-h-screen">
<!-- ...existing nav/header... -->
