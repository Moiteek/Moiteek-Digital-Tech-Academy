-- Moiteek Academy Master Database Setup
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

-- --------------------------------------------------------
-- 1. USERS & ADMINS
-- --------------------------------------------------------
CREATE TABLE `admins` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `fullname` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) UNIQUE NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `role` ENUM('super_admin','admin') DEFAULT 'admin',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE `students` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `fullname` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) UNIQUE NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `status` ENUM('active','pending','suspended') DEFAULT 'pending',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE `courses` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) UNIQUE NOT NULL,
  `description` TEXT,
  `price` DECIMAL(10,2) NOT NULL,
  `image_url` VARCHAR(255),
  `is_published` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE `course_modules` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `course_id` INT NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `module_order` INT DEFAULT 0,
  FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE `lessons` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `video_url` VARCHAR(255),
  `course_id` INT NOT NULL,
  `lesson_order` INT DEFAULT 0,
  FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE `resources` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `link` VARCHAR(255) NOT NULL,
  `type` VARCHAR(50) NOT NULL,
  `course_id` INT NOT NULL,
  FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE `progress` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `student_id` INT NOT NULL,
  `lesson_id` INT NOT NULL,
  `status` ENUM('not_started','in_progress','completed') DEFAULT 'not_started',
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`lesson_id`) REFERENCES `lessons`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- --------------------------------------------------------
-- 3. PAYMENTS & ENROLLMENTS
-- --------------------------------------------------------
CREATE TABLE `enrollments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `student_id` INT NOT NULL,
  `course_id` INT NOT NULL,
  `status` ENUM('pending','approved','completed') DEFAULT 'pending',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE `payments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `student_id` INT NOT NULL,
  `course_id` INT NOT NULL,
  `amount` DECIMAL(10,2) NOT NULL,
  `reference` VARCHAR(100) UNIQUE,
  `paystack_reference` VARCHAR(100) UNIQUE,
  `payment_status` ENUM('pending','completed','failed') DEFAULT 'pending',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- --------------------------------------------------------
-- 4. TRACKING & SECURITY
-- --------------------------------------------------------
CREATE TABLE `lesson_progress` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `enrollment_id` INT NOT NULL,
  `lesson_id` INT NOT NULL,
  `watched_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`enrollment_id`) REFERENCES `enrollments`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE `login_activity` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `email` VARCHAR(100),
  `ip_address` VARCHAR(45),
  `login_status` ENUM('success','failed') DEFAULT 'success',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- --------------------------------------------------------
-- 5. INITIAL DATA
-- --------------------------------------------------------
-- Default Admin (Password: admin12345)
INSERT INTO `admins` (`fullname`, `email`, `password`, `role`) 
VALUES ('Main Admin', 'admin@moiteek.com', '$2y$10$YIjlrBFEV4T5iK9Z.jK/dOT9JxY5JcI3K3K3K3K3K3K3K3K3K3K3K', 'super_admin');

-- Sample Course

-- Web Development
INSERT INTO `courses` (`title`, `slug`, `description`, `price`, `image_url`, `is_published`) VALUES
('Frontend Mastery', 'frontend-mastery', 'Become a frontend expert with HTML, CSS, JavaScript, and modern frameworks.', 40000.00, 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?auto=format&fit=crop&w=600&q=80', 1),
('PHP Backend Pro', 'php-backend-pro', 'Master PHP and backend development for scalable web applications.', 45000.00, 'https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=600&q=80', 1);

-- Graphics Design
INSERT INTO `courses` (`title`, `slug`, `description`, `price`, `image_url`, `is_published`) VALUES
('Photoshop Essentials', 'photoshop-essentials', 'Learn the essentials of Adobe Photoshop for professional design.', 35000.00, 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=600&q=80', 1),
('UI/UX Design', 'ui-ux-design', 'Design stunning user interfaces and experiences with industry best practices.', 42000.00, 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=600&q=80', 1);

-- Digital Skills
INSERT INTO `courses` (`title`, `slug`, `description`, `price`, `image_url`, `is_published`) VALUES
('SEO Strategy', 'seo-strategy', 'Boost website visibility and ranking with proven SEO strategies.', 30000.00, 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=600&q=80', 1),
('Social Media Marketing', 'social-media-marketing', 'Grow your brand and audience with effective social media marketing.', 32000.00, 'https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?auto=format&fit=crop&w=600&q=80', 1);

-- Tech Basics
INSERT INTO `courses` (`title`, `slug`, `description`, `price`, `image_url`, `is_published`) VALUES
('Computer Science 101', 'computer-science-101', 'A beginner-friendly introduction to computer science fundamentals.', 25000.00, 'https://images.unsplash.com/photo-1465101046530-73398c7f28ca?auto=format&fit=crop&w=600&q=80', 1);

COMMIT;