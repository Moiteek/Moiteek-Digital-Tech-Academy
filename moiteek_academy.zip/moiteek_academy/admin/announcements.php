
<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/admin_auth.php';
// Handle new announcement
$success = '';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['message'])) {
    $msg = trim($_POST['message']);
    if ($msg) {
        $stmt = $pdo->prepare('INSERT INTO announcements (message) VALUES (?)');
        $stmt->execute([$msg]);
        $success = 'Announcement posted!';
    } else {
        $error = 'Message cannot be empty.';
    }
}
// Handle delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $pdo->prepare('DELETE FROM announcements WHERE id = ?');
    $stmt->execute([$id]);
    header('Location: announcements.php');
    exit;
}
// Fetch all announcements
$announcements = $pdo->query('SELECT * FROM announcements ORDER BY id DESC')->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Announcements</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
<?php include __DIR__ . '/../includes/header.php'; ?>
<div class="container mx-auto px-4 py-10 max-w-2xl">
    <h1 class="text-3xl font-bold text-blue-800 mb-8">Global Announcements</h1>
    <?php if ($success): ?><div class="mb-4 p-3 bg-green-100 text-green-800 rounded"> <?= htmlspecialchars($success) ?> </div><?php endif; ?>
    <?php if ($error): ?><div class="mb-4 p-3 bg-red-100 text-red-800 rounded"> <?= htmlspecialchars($error) ?> </div><?php endif; ?>
    <form method="post" class="mb-8 bg-white p-6 rounded shadow">
        <label class="block mb-2 font-semibold">New Announcement:</label>
        <textarea name="message" rows="3" class="w-full px-3 py-2 border rounded mb-2" required></textarea>
        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Post Announcement</button>
    </form>
    <h2 class="text-xl font-bold mb-4 text-blue-700">Past Announcements</h2>
    <table class="w-full bg-white rounded shadow mb-8">
        <thead>
            <tr class="bg-gray-200">
                <th class="py-2 px-3 text-left">Message</th>
                <th class="py-2 px-3 text-left">Date</th>
                <th class="py-2 px-3">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($announcements as $a): ?>
                <tr>
                    <td class="py-2 px-3 align-top w-2/3"> <?= nl2br(htmlspecialchars($a['message'])) ?> </td>
                    <td class="py-2 px-3 align-top text-sm text-gray-600"> <?= date('M d, Y H:i', strtotime($a['created_at'])) ?> </td>
                    <td class="py-2 px-3 align-top text-center">
                        <a href="?delete=<?= $a['id'] ?>" class="text-red-600 hover:underline" onclick="return confirm('Delete this announcement?')">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <a href="dashboard.php" class="text-blue-600 hover:underline">&larr; Back to Dashboard</a>
</div>
</body>
</html>
