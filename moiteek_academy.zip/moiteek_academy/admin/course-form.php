<?php
require_once '../bootstrap.php';

if(!Auth::isAdminLoggedIn()) {
    Response::redirect('../admin/login.php', 'Please login', 'error');
}

$course = null;
$mode = 'add';

// Get course if editing
if(isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $stmt = $pdo->prepare("SELECT * FROM courses WHERE id = ?");
    $stmt->execute([$id]);
    $course = $stmt->fetch();
    if(!$course) {
        Response::redirect('courses.php', 'Course not found', 'error');
    }
    $mode = 'edit';
}

// Handle form submission
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = Validator::sanitizeInput($_POST['title'] ?? '');
    $description = Validator::sanitizeInput($_POST['description'] ?? '');
    $detailed_description = Validator::sanitizeInput($_POST['detailed_description'] ?? '');
    $price = floatval($_POST['price'] ?? 0);
    $instructor_name = Validator::sanitizeInput($_POST['instructor_name'] ?? '');
    $level = Validator::sanitizeInput($_POST['level'] ?? 'beginner');
    $category = Validator::sanitizeInput($_POST['category'] ?? '');
    $duration = Validator::sanitizeInput($_POST['duration'] ?? '');
    
    if(empty($title)) {
        Response::redirect('course-form.php' . ($course ? '?id=' . $course['id'] : ''), 'Course title is required', 'error');
    }
    
    if($mode === 'add') {
        $slug = strtolower(str_replace([' ', '&'], ['-', 'and'], $title));
        $stmt = $pdo->prepare("
            INSERT INTO courses (title, slug, description, detailed_description, price, instructor_name, level, category, duration)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$title, $slug, $description, $detailed_description, $price, $instructor_name, $level, $category, $duration]);
        Response::redirect('courses.php', 'Course created successfully!', 'success');
    } else {
        $stmt = $pdo->prepare("
            UPDATE courses 
            SET title = ?, description = ?, detailed_description = ?, price = ?, 
                instructor_name = ?, level = ?, category = ?, duration = ?
            WHERE id = ?
        ");
        $stmt->execute([$title, $description, $detailed_description, $price, $instructor_name, $level, $category, $duration, $course['id']]);
        Response::redirect('course-form.php?id=' . $course['id'], 'Course updated successfully!', 'success');
    }
}

$flash = Response::getFlashMessage();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= ucfirst($mode) ?> Course - <?= APP_NAME ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <i class="fas fa-graduation-cap text-2xl text-blue-600"></i>
                <span class="font-bold text-lg text-gray-800"><?= APP_NAME ?></span>
            </div>
            <a href="courses.php" class="text-gray-600 hover:text-blue-600">
                <i class="fas fa-arrow-left mr-1"></i>Back to Courses
            </a>
        </div>
    </nav>

    <div class="max-w-4xl mx-auto p-8">
        <!-- Flash Message -->
        <?php if($flash): ?>
            <div class="mb-6 p-4 rounded-lg bg-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-50 border border-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-200 flex items-center gap-3">
                <i class="fas fa-<?= $flash['type'] === 'error' ? 'exclamation-circle' : 'check-circle' ?> text-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-600"></i>
                <p class="text-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-700"><?= htmlspecialchars($flash['message']) ?></p>
            </div>
        <?php endif; ?>

        <!-- Form -->
        <div class="bg-white rounded-lg shadow overflow-hidden">
            <div class="bg-gradient-to-r from-blue-500 to-purple-600 p-6 text-white">
                <h1 class="text-3xl font-bold flex items-center gap-2">
                    <i class="fas fa-<?= $mode === 'edit' ? 'edit' : 'plus' ?>"></i>
                    <?= ucfirst($mode) ?> Course
                </h1>
            </div>

            <div class="p-8 space-y-6">
                <form method="POST">
                    <!-- Course Title -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Course Title *</label>
                        <input type="text" name="title" value="<?= $course ? htmlspecialchars($course['title']) : '' ?>" required 
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" 
                            placeholder="Enter course title">
                    </div>

                    <!-- Short Description -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Short Description *</label>
                        <textarea name="description" required rows="3" 
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="Brief course description (appears in listings)"><?= $course ? htmlspecialchars($course['description']) : '' ?></textarea>
                    </div>

                    <!-- Detailed Description -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Detailed Description</label>
                        <textarea name="detailed_description" rows="4" 
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="Full course description (for course detail page)"><?= $course ? htmlspecialchars($course['detailed_description']) : '' ?></textarea>
                    </div>

                    <!-- Grid Row -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <!-- Price -->
                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-2">Price ($)</label>
                            <input type="number" name="price" value="<?= $course ? $course['price'] : '0' ?>" step="0.01" 
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>

                        <!-- Instructor -->
                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-2">Instructor Name</label>
                            <input type="text" name="instructor_name" value="<?= $course ? htmlspecialchars($course['instructor_name']) : '' ?>" 
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                                placeholder="Instructor name">
                        </div>

                        <!-- Level -->
                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-2">Level</label>
                            <select name="level" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                                <option value="beginner" <?= $course && $course['level'] === 'beginner' ? 'selected' : '' ?>>Beginner</option>
                                <option value="intermediate" <?= $course && $course['level'] === 'intermediate' ? 'selected' : '' ?>>Intermediate</option>
                                <option value="advanced" <?= $course && $course['level'] === 'advanced' ? 'selected' : '' ?>>Advanced</option>
                            </select>
                        </div>

                        <!-- Category -->
                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-2">Category</label>
                            <input type="text" name="category" value="<?= $course ? htmlspecialchars($course['category']) : '' ?>" 
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                                placeholder="e.g., Web Development">
                        </div>

                        <!-- Duration -->
                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-2">Duration</label>
                            <input type="text" name="duration" value="<?= $course ? htmlspecialchars($course['duration']) : '' ?>" 
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                                placeholder="e.g., 6 weeks">
                        </div>
                    </div>

                    <!-- Actions -->
                    <div class="flex gap-4 pt-6 border-t">
                        <button type="submit" class="flex-1 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 font-semibold transition">
                            <i class="fas fa-save mr-2"></i><?= $mode === 'edit' ? 'Update' : 'Create' ?> Course
                        </button>
                        <a href="courses.php" class="flex-1 bg-gray-300 text-gray-800 px-6 py-3 rounded-lg hover:bg-gray-400 font-semibold transition text-center">
                            <i class="fas fa-times mr-2"></i>Cancel
                        </a>
                    </div>
                </form>
            </div>
        </div>

        <!-- Manage Lessons (if editing) -->
        <?php if($mode === 'edit'): ?>
            <div class="mt-8 bg-white rounded-lg shadow overflow-hidden">
                <div class="bg-gray-50 p-6 border-b">
                    <h2 class="text-2xl font-bold text-gray-800 flex items-center gap-2">
                        <i class="fas fa-graduation-cap text-purple-600"></i>Manage Lessons
                    </h2>
                </div>

                <div class="p-6">
                    <!-- Add Lesson Button -->
                    <div class="mb-6">
                        <a href="lesson-form.php?course_id=<?= $course['id'] ?>" class="inline-block bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 font-semibold transition">
                            <i class="fas fa-plus mr-2"></i>Add New Lesson
                        </a>
                    </div>

                    <!-- Lessons List -->
                    <?php
                    $modules = $pdo->prepare("SELECT * FROM course_modules WHERE course_id = ? ORDER BY sequence_order ASC");
                    $modules->execute([$course['id']]);
                    $lessons = $modules->fetchAll();
                    ?>

                    <?php if(empty($lessons)): ?>
                        <div class="text-center py-8 text-gray-500">
                            <i class="fas fa-video text-4xl text-gray-300 mb-2"></i>
                            <p>No lessons yet. Add one to get started!</p>
                        </div>
                    <?php else: ?>
                        <div class="space-y-3">
                            <?php foreach($lessons as $lesson): ?>
                                <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition">
                                    <div class="flex-1">
                                        <h4 class="font-semibold text-gray-800"><?= htmlspecialchars($lesson['title']) ?></h4>
                                        <p class="text-xs text-gray-600 mt-1">Duration: <?= $lesson['duration'] ?? 'N/A' ?> mins</p>
                                    </div>
                                    <div class="flex gap-2">
                                        <a href="lesson-form.php?id=<?= $lesson['id'] ?>" class="p-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <form method="POST" style="display:inline;">
                                            <input type="hidden" name="action" value="delete_module">
                                            <input type="hidden" name="module_id" value="<?= $lesson['id'] ?>">
                                            <button type="submit" onclick="return confirm('Delete this lesson?')" class="p-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200" title="Delete">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Manage Resources -->
            <div class="mt-8 bg-white rounded-lg shadow overflow-hidden">
                <div class="bg-gray-50 p-6 border-b">
                    <h2 class="text-2xl font-bold text-gray-800 flex items-center gap-2">
                        <i class="fas fa-file-download text-green-600"></i>Course Resources
                    </h2>
                </div>

                <div class="p-6">
                    <!-- Add Resource Button -->
                    <div class="mb-6">
                        <a href="resource-form.php?course_id=<?= $course['id'] ?>" class="inline-block bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 font-semibold transition">
                            <i class="fas fa-plus mr-2"></i>Add New Resource
                        </a>
                    </div>

                    <!-- Resources List -->
                    <?php
                    $resources = $pdo->prepare("SELECT * FROM course_resources WHERE course_id = ? ORDER BY sequence_order ASC");
                    $resources->execute([$course['id']]);
                    $res_list = $resources->fetchAll();
                    ?>

                    <?php if(empty($res_list)): ?>
                        <div class="text-center py-8 text-gray-500">
                            <i class="fas fa-file-download text-4xl text-gray-300 mb-2"></i>
                            <p>No resources yet. Add downloadable materials for students!</p>
                        </div>
                    <?php else: ?>
                        <div class="space-y-3">
                            <?php foreach($res_list as $res): ?>
                                <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition">
                                    <div class="flex-1">
                                        <h4 class="font-semibold text-gray-800 flex items-center gap-2">
                                            <i class="fas fa-file text-blue-600"></i><?= htmlspecialchars($res['title']) ?>
                                        </h4>
                                        <p class="text-xs text-gray-600 mt-1">Type: <?= ucfirst($res['resource_type']) ?></p>
                                    </div>
                                    <div class="flex gap-2">
                                        <a href="resource-form.php?id=<?= $res['id'] ?>" class="p-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <form method="POST" style="display:inline;">
                                            <input type="hidden" name="action" value="delete_resource">
                                            <input type="hidden" name="resource_id" value="<?= $res['id'] ?>">
                                            <button type="submit" onclick="return confirm('Delete this resource?')" class="p-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200" title="Delete">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
