/**
 * Moiteek Academy - Frontend JavaScript Utilities
 * Handles interactivity, animations, and user interactions
 */

// =====================================================
// Page Initialization
// =====================================================

document.addEventListener('DOMContentLoaded', () => {
    initializeAnimations();
    initializeTooltips();
    initializeFormValidation();
    initializeSearchFilters();
    initializeProgressBars();
});

// =====================================================
// Animations
// =====================================================

function initializeAnimations() {
    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });
    });

    // Fade in on scroll
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -100px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-fade-in');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    document.querySelectorAll('.card-hover').forEach(card => {
        observer.observe(card);
    });
}

// =====================================================
// Tooltips
// =====================================================

function initializeTooltips() {
    const tooltips = document.querySelectorAll('[data-tooltip]');
    tooltips.forEach(element => {
        element.addEventListener('mouseenter', function() {
            const tooltip = this.getAttribute('data-tooltip');
            const tooltipElement = document.createElement('div');
            tooltipElement.className = 'absolute bg-gray-900 text-white text-xs py-1 px-3 rounded pointer-events-none z-50';
            tooltipElement.textContent = tooltip;
            document.body.appendChild(tooltipElement);

            const rect = this.getBoundingClientRect();
            tooltipElement.style.left = (rect.left + rect.width / 2 - tooltipElement.offsetWidth / 2) + 'px';
            tooltipElement.style.top = (rect.top - tooltipElement.offsetHeight - 10) + 'px';

            this.addEventListener('mouseleave', () => {
                tooltipElement.remove();
            }, { once: true });
        });
    });
}

// =====================================================
// Form Validation
// =====================================================

function initializeFormValidation() {
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const inputs = this.querySelectorAll('input[required], textarea[required], select[required]');
            let isValid = true;

            inputs.forEach(input => {
                if (!input.value.trim()) {
                    isValid = false;
                    input.classList.add('border-red-500');
                    input.classList.remove('border-gray-300');
                } else {
                    input.classList.remove('border-red-500');
                    input.classList.add('border-gray-300');
                }
            });

            if (!isValid) {
                e.preventDefault();
                showNotification('Please fill in all required fields', 'error');
            }
        });
    });
}

// =====================================================
// Search Filters
// =====================================================

function initializeSearchFilters() {
    const searchInput = document.getElementById('searchInput');
    if (!searchInput) return;

    searchInput.addEventListener('input', debounce(function() {
        filterCards();
    }, 300));

    const filterButtons = document.querySelectorAll('[data-filter]');
    filterButtons.forEach(button => {
        button.addEventListener('click', filterCards);
    });
}

function filterCards() {
    const searchTerm = document.getElementById('searchInput')?.value.toLowerCase() || '';
    const cards = document.querySelectorAll('.course-card, .card-item');

    cards.forEach(card => {
        const title = card.getAttribute('data-title') || '';
        const matches = title.includes(searchTerm);
        card.style.display = matches ? 'block' : 'none';
        if (matches) {
            card.classList.add('animate-fade-in');
        }
    });
}

// =====================================================
// Progress Bars
// =====================================================

function initializeProgressBars() {
    const progressBars = document.querySelectorAll('[data-progress]');
    progressBars.forEach(bar => {
        const progress = bar.getAttribute('data-progress');
        bar.style.width = progress + '%';
        bar.style.transition = 'width 0.8s ease-out';
    });
}

function updateProgressBar(selector, percentage) {
    const bar = document.querySelector(selector);
    if (bar) {
        bar.style.width = percentage + '%';
    }
}

// =====================================================
// Notifications & Alerts
// =====================================================

function showNotification(message, type = 'info', duration = 5000) {
    const notification = document.createElement('div');
    const bgColor = type === 'success' ? 'bg-green-500' : 
                    type === 'error' ? 'bg-red-500' : 'bg-blue-500';
    
    notification.className = `fixed top-4 right-4 ${bgColor} text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fade-in`;
    notification.innerHTML = `
        <div class="flex items-center gap-2">
            <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
            <span>${message}</span>
        </div>
    `;
    
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.classList.add('animate-fade-out');
        setTimeout(() => notification.remove(), 300);
    }, duration);
}

function showConfirmation(message, onConfirm, onCancel) {
    const modal = document.createElement('div');
    modal.className = 'fixed inset-0 bg-black/50 flex items-center justify-center z-50';
    modal.innerHTML = `
        <div class="bg-white rounded-xl p-6 max-w-md">
            <p class="text-lg font-semibold text-gray-900 mb-6">${message}</p>
            <div class="flex gap-3 justify-end">
                <button class="px-6 py-2 rounded-lg bg-gray-200 text-gray-800 hover:bg-gray-300" onclick="this.closest('.fixed').remove()">Cancel</button>
                <button class="px-6 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700" onclick="this.closest('.fixed').remove()">Confirm</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    modal.querySelector('button:last-child').addEventListener('click', onConfirm);
    modal.querySelector('button:first-of-type').addEventListener('click', onCancel);
}

// =====================================================
// Utility Functions
// =====================================================

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function throttle(func, limit) {
    let inThrottle;
    return function(...args) {
        if (!inThrottle) {
            func.apply(this, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// Copy to clipboard
function copyToClipboard(text, message = 'Copied!') {
    navigator.clipboard.writeText(text).then(() => {
        showNotification(message, 'success');
    });
}

// Format date
function formatDate(date) {
    return new Date(date).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

// =====================================================
// Mobile Menu Toggle
// =====================================================

function toggleMobileMenu() {
    const menu = document.getElementById('mobileMenu');
    if (menu) {
        menu.classList.toggle('hidden');
    }
}

// =====================================================
// Dark Mode (Optional)
// =====================================================

function initializeDarkMode() {
    const toggle = document.getElementById('darkModeToggle');
    if (!toggle) return;

    const isDarkMode = localStorage.getItem('darkMode') === 'true';
    if (isDarkMode) {
        document.documentElement.classList.add('dark');
    }

    toggle.addEventListener('click', () => {
        document.documentElement.classList.toggle('dark');
        localStorage.setItem('darkMode', document.documentElement.classList.contains('dark'));
    });
}

// =====================================================
// Export for use in modules
// =====================================================

if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        showNotification,
        showConfirmation,
        filterCards,
        updateProgressBar,
        copyToClipboard,
        formatDate,
        toggleMobileMenu,
        debounce,
        throttle
    };
}
