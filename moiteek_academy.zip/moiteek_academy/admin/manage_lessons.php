
<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/admin_auth.php';

// Fetch all courses
$courses = $pdo->query('SELECT id, title FROM courses ORDER BY title')->fetchAll();
$selected_course = isset($_GET['course_id']) ? (int)$_GET['course_id'] : 0;

// Handle module creation
$module_message = '';
if (isset($_POST['create_module']) && $selected_course) {
    $module_title = trim($_POST['module_title'] ?? '');
    if ($module_title) {
        $stmt = $pdo->prepare('INSERT INTO modules (course_id, title, position) VALUES (?, ?, (SELECT IFNULL(MAX(position),0)+1 FROM modules WHERE course_id = ?))');
        $stmt->execute([$selected_course, $module_title, $selected_course]);
        $module_message = 'Module added!';
    }
}

// Handle lesson creation
$lesson_message = '';
if (isset($_POST['create_lesson']) && $selected_course) {
    $lesson_title = trim($_POST['lesson_title'] ?? '');
    $video_url = trim($_POST['video_url'] ?? '');
    $module_id = (int)($_POST['module_id'] ?? 0);
    if ($lesson_title && $video_url && $module_id) {
        $stmt = $pdo->prepare('INSERT INTO lessons (module_id, title, video_url, position) VALUES (?, ?, ?, (SELECT IFNULL(MAX(position),0)+1 FROM lessons WHERE module_id = ?))');
        $stmt->execute([$module_id, $lesson_title, $video_url, $module_id]);
        $lesson_message = 'Lesson added!';
    }
}

// Fetch modules for selected course
$modules = [];
if ($selected_course) {
    $stmt = $pdo->prepare('SELECT id, title FROM modules WHERE course_id = ? ORDER BY position');
    $stmt->execute([$selected_course]);
    $modules = $stmt->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Lessons</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
<div class="container mx-auto px-4 py-10 max-w-2xl">
    <h1 class="text-3xl font-bold text-blue-800 mb-8">Manage Lessons</h1>
    <form method="get" class="mb-8">
        <label class="block mb-2 font-semibold">Select Course:</label>
        <select name="course_id" onchange="this.form.submit()" class="w-full px-3 py-2 border rounded">
            <option value="">-- Choose a course --</option>
            <?php foreach ($courses as $c): ?>
                <option value="<?= $c['id'] ?>" <?php if ($selected_course == $c['id']) echo 'selected'; ?>><?= htmlspecialchars($c['title']) ?></option>
            <?php endforeach; ?>
        </select>
    </form>
    <?php if ($selected_course): ?>
        <div class="mb-10 p-6 bg-white rounded shadow">
            <h2 class="text-xl font-bold mb-4 text-blue-700">Add Module</h2>
            <?php if ($module_message): ?><div class="mb-2 text-green-700 font-semibold"><?= $module_message ?></div><?php endif; ?>
            <form method="post">
                <input type="hidden" name="create_module" value="1">
                <input type="text" name="module_title" placeholder="Module Title" class="w-full px-3 py-2 border rounded mb-2" required>
                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Add Module</button>
            </form>
        </div>
        <div class="mb-10 p-6 bg-white rounded shadow">
            <h2 class="text-xl font-bold mb-4 text-blue-700">Add Lesson</h2>
            <?php if ($lesson_message): ?><div class="mb-2 text-green-700 font-semibold"><?= $lesson_message ?></div><?php endif; ?>
            <form method="post">
                <input type="hidden" name="create_lesson" value="1">
                <label class="block mb-2">Module:</label>
                <select name="module_id" class="w-full px-3 py-2 border rounded mb-2" required>
                    <option value="">-- Select Module --</option>
                    <?php foreach ($modules as $m): ?>
                        <option value="<?= $m['id'] ?>"><?= htmlspecialchars($m['title']) ?></option>
                    <?php endforeach; ?>
                </select>
                <input type="text" name="lesson_title" placeholder="Lesson Title" class="w-full px-3 py-2 border rounded mb-2" required>
                <input type="url" name="video_url" placeholder="YouTube/Vimeo Video URL" class="w-full px-3 py-2 border rounded mb-2" required>
                <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded">Add Lesson</button>
            </form>
        </div>
    <?php endif; ?>

    <?php if ($selected_course && !empty($modules)): ?>
        <div class="mb-10 p-6 bg-white rounded shadow">
            <h2 class="text-xl font-bold mb-4 text-blue-700">Add Quiz to Lesson</h2>
            <form method="post">
                <input type="hidden" name="create_quiz" value="1">
                <label class="block mb-2">Lesson:</label>
                <select name="quiz_lesson_id" class="w-full px-3 py-2 border rounded mb-2" required>
                    <option value="">-- Select Lesson --</option>
                    <?php foreach ($modules as $m): ?>
                        <?php
                        $stmt = $pdo->prepare('SELECT id, title FROM lessons WHERE module_id = ? ORDER BY position');
                        $stmt->execute([$m['id']]);
                        $lessons = $stmt->fetchAll();
                        foreach ($lessons as $lesson): ?>
                            <option value="<?= $lesson['id'] ?>"><?= htmlspecialchars($m['title']) ?> - <?= htmlspecialchars($lesson['title']) ?></option>
                        <?php endforeach; ?>
                    <?php endforeach; ?>
                </select>
                <input type="text" name="question" placeholder="Question" class="w-full px-3 py-2 border rounded mb-2" required>
                <input type="text" name="option_a" placeholder="Option A" class="w-full px-3 py-2 border rounded mb-2" required>
                <input type="text" name="option_b" placeholder="Option B" class="w-full px-3 py-2 border rounded mb-2" required>
                <input type="text" name="option_c" placeholder="Option C" class="w-full px-3 py-2 border rounded mb-2" required>
                <input type="text" name="option_d" placeholder="Option D" class="w-full px-3 py-2 border rounded mb-2" required>
                <label class="block mb-2">Correct Option:</label>
                <select name="correct_option" class="w-full px-3 py-2 border rounded mb-2" required>
                    <option value="A">A</option>
                    <option value="B">B</option>
                    <option value="C">C</option>
                    <option value="D">D</option>
                </select>
                <button type="submit" class="bg-purple-600 text-white px-4 py-2 rounded">Add Quiz Question</button>
            </form>
        </div>
    <?php endif; ?>
    <a href="dashboard.php" class="text-blue-600 hover:underline">&larr; Back to Dashboard</a>
</div>
</body>
</html>
// Handle quiz creation
if (isset($_POST['create_quiz']) && $selected_course) {
    $lesson_id = (int)($_POST['quiz_lesson_id'] ?? 0);
    $question = trim($_POST['question'] ?? '');
    $option_a = trim($_POST['option_a'] ?? '');
    $option_b = trim($_POST['option_b'] ?? '');
    $option_c = trim($_POST['option_c'] ?? '');
    $option_d = trim($_POST['option_d'] ?? '');
    $correct_option = $_POST['correct_option'] ?? '';
    if ($lesson_id && $question && $option_a && $option_b && $option_c && $option_d && in_array($correct_option, ['A','B','C','D'])) {
        $stmt = $pdo->prepare('INSERT INTO quizzes (lesson_id, question, option_a, option_b, option_c, option_d, correct_option) VALUES (?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([$lesson_id, $question, $option_a, $option_b, $option_c, $option_d, $correct_option]);
        echo '<div class="mb-2 text-green-700 font-semibold">Quiz question added!</div>';
    }
}
