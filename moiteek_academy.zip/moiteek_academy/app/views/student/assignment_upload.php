<?php
// app/views/student/assignment_upload.php
?>
<div class="container mx-auto p-4">
  <h2 class="text-xl font-bold mb-2">Upload Assignment</h2>
  <form method="POST" action="/student/assignment_upload.php" enctype="multipart/form-data">
    <input type="hidden" name="lesson_id" value="<?= $lesson_id ?>">
    <input type="file" name="assignment_file" accept=".pdf,.doc,.docx,.jpg,.png" required class="border px-2 py-1">
    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Upload</button>
  </form>
</div>
