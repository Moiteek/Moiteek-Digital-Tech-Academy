<?php require_once 'bootstrap.php';
require_once 'includes/seo_helper.php';
echo generateMetaTags('Moiteek Academy Courses', 'Browse all courses at Moiteek Academy.', '/assets/logo.png');
$courses = Database::getCourses();
$flash = Response::getFlashMessage();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Courses - <?= APP_NAME ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .card-hover {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .card-hover:hover {
            transform: translateY(-8px);
            box-shadow: 0 20px 40px rgba(0,0,0,0.15);
        }
        .line-clamp-2 {
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
    </style>
</head>

<body class="bg-gray-50" style="padding-top:72px;">
    <?php include __DIR__ . '/includes/header.php'; ?>

    <!-- Flash Message -->
    <?php if($flash): ?>
        <div class="max-w-7xl mx-auto mt-4 px-4">
            <div class="p-4 rounded-lg bg-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-50 border border-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-200 flex items-center gap-3">
                <i class="fas fa-<?= $flash['type'] === 'error' ? 'exclamation-circle' : 'check-circle' ?> text-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-600"></i>
                <p class="text-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-700"><?= htmlspecialchars($flash['message']) ?></p>
            </div>
        </div>
    <?php endif; ?>

    <!-- Header -->
    <div class="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-16">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <h1 class="text-4xl md:text-5xl font-bold mb-4">All Courses</h1>
            <p class="text-lg text-gray-100">Choose from our collection of world-class courses</p>
        </div>
    </div>

    <!-- Main Content -->
    <div class="max-w-7xl mx-auto px-4 py-12">
        <!-- Search & Filter -->
        <div class="bg-white rounded-xl shadow-md p-6 mb-12">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Search Courses</label>
                    <input 
                        type="text" 
                        id="searchInput" 
                        placeholder="Search by title..." 
                        class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                </div>
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Level</label>
                    <select id="levelFilter" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="">All Levels</option>
                        <option value="beginner">Beginner</option>
                        <option value="intermediate">Intermediate</option>
                        <option value="advanced">Advanced</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Category</label>
                    <select id="categoryFilter" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="">All Categories</option>
                        <option value="Web Development">Web Development</option>
                        <option value="Graphics Design">Graphics Design</option>
                        <option value="Digital Skills">Digital Skills</option>
                        <option value="Tech Basics">Tech Basics</option>
                    </select>
                </div>
            </div>
        </div>

        <!-- Courses Grid -->
        <div class="row">
            <?php foreach($courses as $course) { 
                $level = $course['level'] ?? 'beginner'; $category = $course['category'] ?? 'N/A'; $title = $course['title'] ?? 'Untitled'; ?>
                <div class="col-md-4 mb-4">
                    <div class="card h-100 shadow-sm course-card border border-gray-100 card-hover" data-level="<?= $level ?>" data-category="<?= $category ?>" data-title="<?= strtolower($title) ?>">
                        <?php
                        $img = $course['image_url'] ?? $course['thumbnail'] ?? '';
                        $placeholder = 'https://images.unsplash.com/photo-1501504905252-473c47e087f8?auto=format&fit=crop&w=600&q=80';
                        $imgPath = (!empty($img) && file_exists(__DIR__ . '/' . $img)) ? $img : $placeholder;
                        ?>
                        <img src="<?= htmlspecialchars($imgPath) ?>"
                             class="card-img-top h-48 w-100 object-cover" alt="Course Image"
                             onerror="this.onerror=null;this.src='<?= $placeholder ?>';">
                        <div class="card-body p-6">
                            <div class="flex items-center justify-between mb-3">
                                <span class="text-xs font-semibold text-blue-600 bg-blue-50 px-3 py-1 rounded-full">
                                    <?= htmlspecialchars($category) ?>
                                </span>
                                <div class="text-yellow-400 text-sm">
                                    <i class="fas fa-star"></i>
                                    <span class="text-gray-600 text-xs">(4.8)</span>
                                </div>
                            </div>
                            <h3 class="card-title text-xl font-bold text-gray-900 mb-2 line-clamp-2">
                                <?= htmlspecialchars($title) ?>
                            </h3>
                            <p class="card-text text-gray-600 text-sm mb-4 line-clamp-2">
                                <?= htmlspecialchars($course['description'] ?? 'N/A') ?>
                            </p>
                            <div class="flex items-center gap-2 mb-4 pb-4 border-b border-gray-200">
                                <div class="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                                    <i class="fas fa-user text-blue-600 text-xs"></i>
                                </div>
                                <span class="text-sm text-gray-700">
                                    <?= htmlspecialchars($course['instructor_name'] ?? 'N/A') ?>
                                </span>
                            </div>
                            <div class="flex items-center justify-between text-sm text-gray-600 mb-4">
                                <span><i class="fas fa-clock mr-1 text-blue-600"></i><?= htmlspecialchars($course['duration'] ?? 'N/A') ?></span>
                                <span><i class="fas fa-play-circle mr-1 text-blue-600"></i><?= isset($course['total_modules']) ? $course['total_modules'] : 0 ?> modules</span>
                            </div>
                            <span class="text-3xl font-bold text-blue-600">
                                <?= Helper::formatCurrency($course['price']) ?>
                            </span>
                        </div>
                        <div class="px-6 pb-6">
                            <a href="auth/register.php?course_id=<?= $course['id'] ?>" class="w-full block text-center bg-gradient-to-r from-blue-600 to-amber-400 hover:shadow-lg text-white py-3 rounded-lg font-bold transition">
                                <i class="fas fa-arrow-right mr-2"></i>Register
                            </a>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>

        <!-- No Results -->
        <div id="noResults" class="hidden text-center py-12">
            <i class="fas fa-search text-5xl text-gray-400 mb-4"></i>
            <p class="text-xl text-gray-600">No courses found. Try adjusting your filters.</p>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-gray-900 text-gray-400 py-8 mt-12">
        <div class="max-w-7xl mx-auto px-4 text-center text-sm">
            <p>&copy; 2026 <?= APP_NAME ?>. All rights reserved.</p>
        </div>
    </footer>

    <script>
        // Filter functionality
        const searchInput = document.getElementById('searchInput');
        const levelFilter = document.getElementById('levelFilter');
        const categoryFilter = document.getElementById('categoryFilter');
        const courseCards = document.querySelectorAll('.course-card');
        const noResults = document.getElementById('noResults');
        const coursesGrid = document.getElementById('coursesGrid');

        function filterCourses() {
            const searchTerm = searchInput.value.toLowerCase();
            const level = levelFilter.value;
            const category = categoryFilter.value;
            let visibleCount = 0;

            courseCards.forEach(card => {
                const title = card.dataset.title;
                const cardLevel = card.dataset.level;
                const cardCategory = card.dataset.category;

                const matchesSearch = title.includes(searchTerm);
                const matchesLevel = !level || cardLevel === level;
                const matchesCategory = !category || cardCategory === category;

                if (matchesSearch && matchesLevel && matchesCategory) {
                    card.classList.remove('hidden');
                    visibleCount++;
                } else {
                    card.classList.add('hidden');
                }
            });

            if (visibleCount === 0) {
                noResults.classList.remove('hidden');
                coursesGrid.classList.add('hidden');
            } else {
                noResults.classList.add('hidden');
                coursesGrid.classList.remove('hidden');
            }
        }

        searchInput.addEventListener('input', filterCourses);
        levelFilter.addEventListener('change', filterCourses);
        categoryFilter.addEventListener('change', filterCourses);
    </script>
</body>
</html>
