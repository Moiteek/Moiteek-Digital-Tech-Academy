<?php
require_once __DIR__ . '/../includes/bootstrap.php';

// Only allow POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../index.php');
    exit;
}

$course_id = (int)($_POST['course_id'] ?? 0);
if (!$course_id) {
    die('Invalid course selection.');
}

// Fetch course details
$stmt = $pdo->prepare('SELECT id, title, price FROM courses WHERE id = ? LIMIT 1');
$stmt->execute([$course_id]);
$course = $stmt->fetch();
if (!$course) {
    die('Course not found.');
}

// Check student session
if (!isset($_SESSION['student_id'])) {
    header('Location: ../auth/login.php');
    exit;
}
$student_id = $_SESSION['student_id'];
$student_email = '';
// Fetch student email
$stmt = $pdo->prepare('SELECT email FROM students WHERE id = ? LIMIT 1');
$stmt->execute([$student_id]);
$row = $stmt->fetch();
if ($row) {
    $student_email = $row['email'];
} else {
    die('Student not found.');
}

// Paystack API setup
$paystack_secret_key = 'sk_test_xxxxxxxxxxxxxxxxxxxxxxxxx'; // Replace with your test key
$callback_url = 'http://localhost/moiteek_academy/payments/callback.php';
$amount_kobo = $course['price'] * 100; // Paystack expects amount in kobo

// Prepare API request
$fields = [
    'email' => $student_email,
    'amount' => $amount_kobo,
    'metadata' => [
        'student_id' => $student_id,
        'course_id' => $course_id
    ],
    'callback_url' => $callback_url
];

$ch = curl_init('https://api.paystack.co/transaction/initialize');
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Bearer ' . $paystack_secret_key,
    'Content-Type: application/json',
]);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
$err = curl_error($ch);
curl_close($ch);

$debug_mode = false;
if ($err || !$response) {
    $debug_mode = true;
} else {
    $result = json_decode($response, true);
    if (!isset($result['status']) || !$result['status']) {
        $debug_mode = true;
    }
}

if ($debug_mode) {
    // Debug mode: allow manual redirect for local testing
    echo '<!DOCTYPE html><html><head><title>Debug Mode - Paystack</title></head><body style="font-family:sans-serif;text-align:center;padding:40px;">';
    echo '<h2>Debug Mode: Paystack API not reachable</h2>';
    echo '<p>You are running on localhost or the Paystack API is not available.</p>';
    echo '<form method="get" action="callback.php">';
    echo '<input type="hidden" name="reference" value="debug-' . uniqid() . '">';
    echo '<input type="hidden" name="student_id" value="' . htmlspecialchars($student_id) . '">';
    echo '<input type="hidden" name="course_id" value="' . htmlspecialchars($course_id) . '">';
    echo '<button type="submit" style="padding:12px 32px;background:#007bff;color:#fff;border:none;border-radius:4px;font-size:18px;">Simulate Payment Success</button>';
    echo '</form>';
    echo '<p style="margin-top:30px;color:#888;">(This is for local testing only. In production, this page will not appear.)</p>';
    echo '</body></html>';
    exit;
}

// If not debug, redirect to Paystack payment page
$auth_url = $result['data']['authorization_url'] ?? '';
if ($auth_url) {
    header('Location: ' . $auth_url);
    exit;
} else {
    die('Unable to initialize payment.');
}
