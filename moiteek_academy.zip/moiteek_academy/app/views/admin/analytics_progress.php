<?php
// app/views/admin/analytics_progress.php
// Admin analytics for student progress per course
?>
<div class="container mx-auto p-4">
  <h2 class="text-xl font-bold mb-4">Student Progress Analytics</h2>
  <table class="min-w-full bg-white border">
    <thead>
      <tr>
        <th>Student</th><th>Lessons Watched</th><th>Total Lessons</th><th>Completion %</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($analytics as $a): ?>
      <tr>
        <td><?= htmlspecialchars($a['fullname']) ?></td>
        <td><?= $a['watched'] ?></td>
        <td><?= $a['total'] ?></td>
        <td><?= $a['percent'] ?>%</td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
