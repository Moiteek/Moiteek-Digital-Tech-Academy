<?php
// app/views/admin/lesson_form.php
// Admin UI for lesson creation/editing, video type, ordering, resources
?>
<div class="container mx-auto p-4">
  <h2 class="text-xl font-bold mb-2">Create/Edit Lesson</h2>
  <form method="POST" action="/admin/lesson_save.php" enctype="multipart/form-data">
    <input type="hidden" name="course_id" value="<?= $course_id ?>">
    <input type="hidden" name="module_id" value="<?= $module_id ?>">
    <div class="mb-2">
      <label>Title</label>
      <input type="text" name="title" class="border px-2 py-1 w-full" required>
    </div>
    <div class="mb-2">
      <label>Description</label>
      <textarea name="description" class="border px-2 py-1 w-full"></textarea>
    </div>
    <div class="mb-2">
      <label>Video Type</label>
      <select name="video_type" class="border px-2 py-1 w-full" required>
        <option value="youtube">YouTube</option>
        <option value="vimeo">Vimeo</option>
        <option value="upload">Direct Upload</option>
      </select>
    </div>
    <div class="mb-2">
      <label>Video URL/ID</label>
      <input type="text" name="video_url" class="border px-2 py-1 w-full">
    </div>
    <div class="mb-2">
      <label>Video File (if upload)</label>
      <input type="file" name="video_file" accept="video/mp4">
    </div>
    <div class="mb-2">
      <label>Resource Links (one per line)</label>
      <textarea name="resource_links" class="border px-2 py-1 w-full"></textarea>
    </div>
    <div class="mb-2">
      <label>Lesson Order</label>
      <input type="number" name="lesson_order" class="border px-2 py-1 w-full" min="0">
    </div>
    <div class="mb-2">
      <label>Publish?</label>
      <input type="checkbox" name="is_published" value="1" checked>
    </div>
    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Save Lesson</button>
  </form>
</div>
