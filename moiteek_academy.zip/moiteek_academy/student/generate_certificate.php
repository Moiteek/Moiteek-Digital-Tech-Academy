<?php
require_once __DIR__ . '/../includes/bootstrap.php';
if (!isset($_SESSION['student_id'])) {
    header('Location: ../auth/login.php');
    exit;
}
$student_id = $_SESSION['student_id'];
$course_id = isset($_GET['course_id']) ? (int)$_GET['course_id'] : 0;

// Security: Only allow if course is completed
$stmt = $pdo->prepare('SELECT e.completed_at, e.certificate_id, s.name as student_name, c.title as course_title FROM enrollments e INNER JOIN students s ON e.student_id = s.id INNER JOIN courses c ON e.course_id = c.id WHERE e.student_id = ? AND e.course_id = ? AND e.status = "completed"');
$stmt->execute([$student_id, $course_id]);
$row = $stmt->fetch();
if (!$row) {
    header('Location: dashboard.php');
    exit;
}
$student_name = $row['student_name'];
$course_title = $row['course_title'];
$completed_at = $row['completed_at'] ? date('F j, Y', strtotime($row['completed_at'])) : date('F j, Y');
$certificate_id = $row['certificate_id'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Certificate of Completion</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        .certificate {
            max-width: 700px;
            margin: 40px auto;
            background: #fff;
            border: 8px solid #2563eb;
            border-radius: 16px;
            box-shadow: 0 4px 24px #0002;
            padding: 48px 32px;
            text-align: center;
        }
        .seal {
            display: inline-block;
            margin-top: 32px;
            font-size: 1.2rem;
            color: #2563eb;
            font-weight: bold;
            border: 2px solid #2563eb;
            border-radius: 50%;
            padding: 16px 32px;
            background: #f0f6ff;
        }
        @media print {
            body { background: #fff !important; }
            .print-btn { display: none; }
        }
    </style>
</head>
<body class="bg-blue-50">
    <div class="certificate">
        <h1 class="text-3xl font-bold text-blue-800 mb-4">Certificate of Completion</h1>
        <p class="text-lg mb-6">This is to certify that</p>
        <div class="text-2xl font-bold text-gray-900 mb-2"><?= htmlspecialchars($student_name) ?></div>
        <p class="mb-6">has successfully completed the course</p>
        <div class="text-xl font-semibold text-blue-700 mb-2">"<?= htmlspecialchars($course_title) ?>"</div>
        <p class="mb-6">on <?= htmlspecialchars($completed_at) ?></p>
        <div class="seal">Verified by<br>Moiteek Academy</div>
        <div class="mt-8 text-sm text-gray-600 font-mono">Certificate ID: <span class="font-bold text-blue-700"><?= htmlspecialchars($certificate_id) ?></span></div>
        <button onclick="window.print()" class="print-btn mt-8 bg-blue-700 text-white px-6 py-3 rounded hover:bg-blue-800 font-semibold">Print / Save as PDF</button>
    </div>
</body>
</html>
