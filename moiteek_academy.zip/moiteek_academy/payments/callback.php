<?php
require_once __DIR__ . '/../includes/bootstrap.php';

// Get reference, student_id, course_id from GET or POST
$reference = $_GET['reference'] ?? $_POST['reference'] ?? '';
$student_id = $_GET['student_id'] ?? $_SESSION['student_id'] ?? null;
$course_id = $_GET['course_id'] ?? null;

if (!$reference || !$student_id || !$course_id) {
    die('Invalid payment callback.');
}

// Simulate verification for debug mode (local test)
$is_debug = (strpos($reference, 'debug-') === 0);
$payment_verified = false;

if ($is_debug) {
    $payment_verified = true;
} else {
    // Real Paystack verification
    $paystack_secret_key = 'sk_test_xxxxxxxxxxxxxxxxxxxxxxxxx'; // Replace with your test key
    $verify_url = 'https://api.paystack.co/transaction/verify/' . urlencode($reference);
    $ch = curl_init($verify_url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $paystack_secret_key
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    $err = curl_error($ch);
    curl_close($ch);
    if ($err || !$response) {
        $payment_verified = false;
    } else {
        $result = json_decode($response, true);
        if (isset($result['data']['status']) && $result['data']['status'] === 'success') {
            $payment_verified = true;
        }
    }
}

if ($payment_verified) {
    // Enroll student if not already enrolled
    $stmt = $pdo->prepare('SELECT id FROM enrollments WHERE student_id = ? AND course_id = ? LIMIT 1');
    $stmt->execute([$student_id, $course_id]);
    if (!$stmt->fetch()) {
        $stmt = $pdo->prepare('INSERT INTO enrollments (student_id, course_id, enrolled_at) VALUES (?, ?, NOW())');
        $stmt->execute([$student_id, $course_id]);
    }
    $_SESSION['success_message'] = 'Congratulations! You now have access to the course.';
    header('Location: ../student/dashboard.php');
    exit;
} else {
    $_SESSION['error_message'] = 'Payment verification failed. Please contact support.';
    header('Location: ../student/dashboard.php');
    exit;
}
