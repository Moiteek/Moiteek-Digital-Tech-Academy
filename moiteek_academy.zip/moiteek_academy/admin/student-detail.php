<?php
require_once '../bootstrap.php';

if(!Auth::isAdminLoggedIn()) {
    Response::redirect('../admin/login.php', 'Please login', 'error');
}

$student_id = (int)($_GET['id'] ?? 0);
if(!$student_id) {
    Response::redirect('students.php', 'Student not found', 'error');
}

$stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
$stmt->execute([$student_id]);
$student = $stmt->fetch();

if(!$student) {
    Response::redirect('students.php', 'Student not found', 'error');
}

// Handle actions
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if($action === 'approve') {
        $pdo->prepare("UPDATE students SET status = 'approved' WHERE id = ?")->execute([$student_id]);
        Response::redirect("student-detail.php?id=$student_id", 'Student approved successfully!', 'success');
    } elseif($action === 'suspend') {
        $pdo->prepare("UPDATE students SET status = 'suspended', is_active = 0 WHERE id = ?")->execute([$student_id]);
        Response::redirect("student-detail.php?id=$student_id", 'Student suspended successfully!', 'success');
    } elseif($action === 'activate') {
        $pdo->prepare("UPDATE students SET is_active = 1, status = 'approved' WHERE id = ?")->execute([$student_id]);
        Response::redirect("student-detail.php?id=$student_id", 'Student activated successfully!', 'success');
    } elseif($action === 'generate_credentials') {
        // Generate random username and password
        $username = strtolower(str_replace(' ', '_', $student['first_name'] . '_' . $student['last_name'])) . '_' . rand(100, 999);
        $password = bin2hex(random_bytes(6));
        
        // Store in session for display
        $_SESSION['generated_username'] = $username;
        $_SESSION['generated_password'] = $password;
        
        Response::redirect("student-detail.php?id=$student_id&show_credentials=1", 'Credentials generated successfully!', 'success');
    }
}

// Get enrollments
$stmt = $pdo->prepare("
    SELECT e.*, c.title as course_title, c.id as course_id
    FROM enrollments e
    JOIN courses c ON e.course_id = c.id
    WHERE e.student_id = ?
    ORDER BY e.enrollment_date DESC
");
$stmt->execute([$student_id]);
$enrollments = $stmt->fetchAll();

// Get payments
$stmt = $pdo->prepare("
    SELECT p.*, c.title as course_title
    FROM payments p
    LEFT JOIN courses c ON p.course_id = c.id
    WHERE p.student_id = ?
    ORDER BY p.created_at DESC
");
$stmt->execute([$student_id]);
$payments = $stmt->fetchAll();

// Get progress
$stmt = $pdo->prepare("
    SELECT p.*, c.title as course_title
    FROM module_progress p
    JOIN course_modules m ON p.module_id = m.id
    JOIN courses c ON m.course_id = c.id
    WHERE p.student_id = ?
    ORDER BY p.completed_at DESC
");
$stmt->execute([$student_id]);
$progress = $stmt->fetchAll();

$flash = Response::getFlashMessage();
$show_credentials = isset($_GET['show_credentials']) && $_GET['show_credentials'] === '1';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Details - <?= APP_NAME ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <i class="fas fa-graduation-cap text-2xl text-blue-600"></i>
                <span class="font-bold text-lg text-gray-800"><?= APP_NAME ?></span>
            </div>
            <a href="students.php" class="text-gray-600 hover:text-blue-600">
                <i class="fas fa-arrow-left mr-1"></i>Back to Students
            </a>
        </div>
    </nav>

    <div class="max-w-6xl mx-auto p-8">
        <!-- Flash Message -->
        <?php if($flash): ?>
            <div class="mb-6 p-4 rounded-lg bg-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-50 border border-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-200 flex items-center gap-3">
                <i class="fas fa-<?= $flash['type'] === 'error' ? 'exclamation-circle' : 'check-circle' ?> text-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-600"></i>
                <p class="text-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-700"><?= htmlspecialchars($flash['message']) ?></p>
            </div>
        <?php endif; ?>

        <!-- Generated Credentials Modal -->
        <?php if($show_credentials && isset($_SESSION['generated_username'])): ?>
            <div class="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
                <div class="bg-white rounded-lg shadow-xl max-w-md w-full p-8">
                    <div class="text-center mb-6">
                        <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                            <i class="fas fa-check text-green-600 text-2xl"></i>
                        </div>
                        <h2 class="text-2xl font-bold text-gray-800">Login Credentials Generated</h2>
                    </div>

                    <div class="space-y-4 mb-6">
                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-2">Username</label>
                            <div class="flex items-center">
                                <input type="text" value="<?= htmlspecialchars($_SESSION['generated_username']) ?>" readonly 
                                    class="flex-1 px-4 py-2 bg-gray-100 border border-gray-300 rounded-lg font-mono text-sm">
                                <button onclick="copyToClipboard('<?= htmlspecialchars($_SESSION['generated_username']) ?>')" class="ml-2 p-2 bg-blue-600 text-white rounded hover:bg-blue-700">
                                    <i class="fas fa-copy"></i>
                                </button>
                            </div>
                        </div>

                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-2">Password</label>
                            <div class="flex items-center">
                                <input type="text" value="<?= htmlspecialchars($_SESSION['generated_password']) ?>" readonly 
                                    class="flex-1 px-4 py-2 bg-gray-100 border border-gray-300 rounded-lg font-mono text-sm">
                                <button onclick="copyToClipboard('<?= htmlspecialchars($_SESSION['generated_password']) ?>')" class="ml-2 p-2 bg-blue-600 text-white rounded hover:bg-blue-700">
                                    <i class="fas fa-copy"></i>
                                </button>
                            </div>
                        </div>
                    </div>

                    <div class="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-6 text-sm text-amber-800">
                        <strong>ⓘ Important:</strong> Share these credentials with the student securely. They should change the password on first login.
                    </div>

                    <button onclick="window.location.href='student-detail.php?id=<?= $student_id ?>'" class="w-full bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 font-semibold">
                        Done
                    </button>
                </div>
            </div>
        <?php endif; ?>

        <!-- Student Header -->
        <div class="bg-white rounded-lg shadow overflow-hidden mb-8">
            <div class="bg-gradient-to-r from-blue-500 to-purple-600 p-6 text-white">
                <div class="flex items-start justify-between">
                    <div class="flex items-center gap-6">
                        <div class="w-20 h-20 bg-white rounded-full flex items-center justify-center">
                            <i class="fas fa-user text-3xl text-blue-600"></i>
                        </div>
                        <div>
                            <h1 class="text-3xl font-bold"><?= htmlspecialchars($student['first_name'] . ' ' . $student['last_name']) ?></h1>
                            <p class="text-blue-100">Email: <?= htmlspecialchars($student['email']) ?></p>
                            <p class="text-blue-100">ID: #<?= $student['id'] ?></p>
                        </div>
                    </div>
                    <div>
                        <span class="inline-block px-4 py-2 rounded-full text-sm font-semibold 
                            <?php
                            if($student['status'] === 'pending') echo 'bg-yellow-200 text-yellow-800';
                            elseif($student['status'] === 'approved') echo $student['is_active'] ? 'bg-green-200 text-green-800' : 'bg-red-200 text-red-800';
                            elseif($student['status'] === 'suspended') echo 'bg-red-200 text-red-800';
                            else echo 'bg-gray-200 text-gray-800';
                            ?>
                        ">
                            <?= ucfirst($student['status']) ?> <?= !$student['is_active'] && $student['status'] === 'approved' ? '(Inactive)' : '' ?>
                        </span>
                    </div>
                </div>
            </div>

            <div class="p-6 grid grid-cols-1 md:grid-cols-4 gap-4">
                <div class="bg-blue-50 p-4 rounded-lg">
                    <p class="text-sm text-gray-600">Joined</p>
                    <p class="text-lg font-bold text-gray-800"><?= date('M d, Y', strtotime($student['created_at'])) ?></p>
                </div>
                <div class="bg-green-50 p-4 rounded-lg">
                    <p class="text-sm text-gray-600">Courses Enrolled</p>
                    <p class="text-lg font-bold text-gray-800"><?= count($enrollments) ?></p>
                </div>
                <div class="bg-purple-50 p-4 rounded-lg">
                    <p class="text-sm text-gray-600">Total Paid</p>
                    <p class="text-lg font-bold text-gray-800">$<?= number_format(array_sum(array_map(fn($p) => $p['amount'] ?? 0, $payments)), 2) ?></p>
                </div>
                <div class="bg-orange-50 p-4 rounded-lg">
                    <p class="text-sm text-gray-600">Last Login</p>
                    <p class="text-lg font-bold text-gray-800"><?= $student['last_login'] ? date('M d, Y', strtotime($student['last_login'])) : 'Never' ?></p>
                </div>
            </div>
        </div>

        <!-- Action Buttons -->
        <div class="flex gap-3 mb-8 flex-wrap">
            <?php if($student['status'] === 'pending'): ?>
                <form method="POST" style="display:inline;">
                    <input type="hidden" name="action" value="approve">
                    <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 font-semibold transition">
                        <i class="fas fa-check mr-2"></i>Approve
                    </button>
                </form>
            <?php endif; ?>

            <?php if($student['status'] === 'approved' && $student['is_active']): ?>
                <form method="POST" style="display:inline;">
                    <input type="hidden" name="action" value="suspend">
                    <button type="submit" onclick="return confirm('Suspend this student?')" class="bg-yellow-600 text-white px-6 py-2 rounded-lg hover:bg-yellow-700 font-semibold transition">
                        <i class="fas fa-pause-circle mr-2"></i>Suspend
                    </button>
                </form>
            <?php endif; ?>

            <?php if($student['status'] === 'suspended' || !$student['is_active']): ?>
                <form method="POST" style="display:inline;">
                    <input type="hidden" name="action" value="activate">
                    <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 font-semibold transition">
                        <i class="fas fa-play-circle mr-2"></i>Activate
                    </button>
                </form>
            <?php endif; ?>

            <form method="POST" style="display:inline;">
                <input type="hidden" name="action" value="generate_credentials">
                <button type="submit" class="bg-purple-600 text-white px-6 py-2 rounded-lg hover:bg-purple-700 font-semibold transition">
                    <i class="fas fa-key mr-2"></i>Generate Login Credentials
                </button>
            </form>
        </div>

        <!-- Two Column Layout -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <!-- Enrollments -->
            <div class="bg-white rounded-lg shadow overflow-hidden">
                <div class="bg-gray-50 p-6 border-b flex items-center gap-2 font-bold text-lg text-gray-800">
                    <i class="fas fa-book text-blue-600"></i>Enrollments (<?= count($enrollments) ?>)
                </div>
                <div class="p-6">
                    <?php if(empty($enrollments)): ?>
                        <div class="text-center py-8 text-gray-500">
                            <i class="fas fa-inbox text-4xl text-gray-300 mb-2"></i>
                            <p>No course enrollments yet</p>
                        </div>
                    <?php else: ?>
                        <div class="space-y-3">
                            <?php foreach($enrollments as $enrollment): ?>
                                <div class="p-4 border border-gray-200 rounded-lg hover:border-blue-300 transition">
                                    <div class="flex items-start justify-between">
                                        <div>
                                            <h4 class="font-semibold text-gray-800"><?= htmlspecialchars($enrollment['course_title']) ?></h4>
                                            <p class="text-sm text-gray-600">Status: <span class="font-semibold <?= $enrollment['status'] === 'active' ? 'text-green-600' : 'text-gray-600' ?>">
                                                <?= ucfirst($enrollment['status']) ?>
                                            </span></p>
                                        </div>
                                        <span class="px-3 py-1 bg-<?= $enrollment['payment_status'] === 'confirmed' ? 'green' : 'yellow' ?>-100 text-<?= $enrollment['payment_status'] === 'confirmed' ? 'green' : 'yellow' ?>-800 rounded text-xs font-semibold">
                                            <?= ucfirst($enrollment['payment_status'] ?? 'pending') ?>
                                        </span>
                                    </div>
                                    <p class="text-xs text-gray-600 mt-2">Enrolled: <?= date('M d, Y', strtotime($enrollment['enrollment_date'])) ?></p>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Payments -->
            <div class="bg-white rounded-lg shadow overflow-hidden">
                <div class="bg-gray-50 p-6 border-b flex items-center gap-2 font-bold text-lg text-gray-800">
                    <i class="fas fa-credit-card text-green-600"></i>Payments (<?= count($payments) ?>)
                </div>
                <div class="p-6">
                    <?php if(empty($payments)): ?>
                        <div class="text-center py-8 text-gray-500">
                            <i class="fas fa-receipt text-4xl text-gray-300 mb-2"></i>
                            <p>No payments recorded</p>
                        </div>
                    <?php else: ?>
                        <div class="space-y-3">
                            <?php foreach($payments as $payment): ?>
                                <div class="p-4 border border-gray-200 rounded-lg hover:border-green-300 transition">
                                    <div class="flex items-start justify-between">
                                        <div>
                                            <h4 class="font-semibold text-gray-800"><?= htmlspecialchars($payment['course_title'] ?? 'General Payment') ?></h4>
                                            <p class="text-sm text-gray-600"><strong>Amount:</strong> $<?= number_format($payment['amount'], 2) ?></p>
                                        </div>
                                        <span class="px-3 py-1 bg-<?= $payment['payment_status'] === 'confirmed' ? 'green' : ($payment['payment_status'] === 'pending' ? 'yellow' : 'red') ?>-100 text-<?= $payment['payment_status'] === 'confirmed' ? 'green' : ($payment['payment_status'] === 'pending' ? 'yellow' : 'red') ?>-800 rounded text-xs font-semibold">
                                            <?= ucfirst($payment['payment_status']) ?>
                                        </span>
                                    </div>
                                    <p class="text-xs text-gray-600 mt-2">Method: <?= ucfirst($payment['payment_method'] ?? 'Unknown') ?> • <?= date('M d, Y', strtotime($payment['created_at'])) ?></p>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Progress -->
        <div class="mt-8 bg-white rounded-lg shadow overflow-hidden">
            <div class="bg-gray-50 p-6 border-b flex items-center gap-2 font-bold text-lg text-gray-800">
                <i class="fas fa-chart-line text-purple-600"></i>Course Progress (<?= count($progress) ?> modules completed)
            </div>
            <div class="p-6">
                <?php if(empty($progress)): ?>
                    <div class="text-center py-8 text-gray-500">
                        <i class="fas fa-graduation-cap text-4xl text-gray-300 mb-2"></i>
                        <p>No course progress yet</p>
                    </div>
                <?php else: ?>
                    <div class="space-y-3">
                        <?php foreach($progress as $p): ?>
                            <div class="p-4 border border-gray-200 rounded-lg hover:border-purple-300 transition">
                                <div class="flex items-center justify-between">
                                    <div class="flex-1">
                                        <h4 class="font-semibold text-gray-800"><?= htmlspecialchars($p['course_title']) ?></h4>
                                        <p class="text-sm text-gray-600">Completed: <?= date('M d, Y', strtotime($p['completed_at'])) ?></p>
                                    </div>
                                    <div class="flex-shrink-0">
                                        <span class="inline-block px-3 py-1 bg-green-100 text-green-800 rounded text-sm font-semibold">
                                            <i class="fas fa-check-circle mr-1"></i>Completed
                                        </span>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        function copyToClipboard(text) {
            navigator.clipboard.writeText(text).then(() => {
                alert('Copied to clipboard!');
            });
        }
    </script>
</body>
</html>
