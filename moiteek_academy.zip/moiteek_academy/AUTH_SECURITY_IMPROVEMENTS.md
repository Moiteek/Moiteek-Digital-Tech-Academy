# Authentication Security Improvements

## Sessions
- Use `session_regenerate_id(true)` on login
- Store only user ID, role, and CSRF token in session
- Set secure, HTTP-only cookies
- Destroy session on logout

## Password Hashing
- Use `password_hash()` (bcrypt) for all passwords
- Use `password_verify()` for login
- Enforce strong password policy (min 8 chars, mixed case, number, symbol)

## CSRF Protection
- Use CSRF tokens in all forms (core/CSRF.php)
- Validate token on POST/PUT/DELETE requests

## Prepared Statements
- All DB queries use PDO prepared statements

## XSS & Input Validation
- Sanitize all user input (Validator.php)
- Escape output in views (htmlspecialchars)

## Example (Login)
```php
// On login success
session_regenerate_id(true);
$_SESSION['user_id'] = $user['id'];
$_SESSION['role'] = $user['role'];
$_SESSION['csrf_token'] = CSRF::generate();
```

> These steps ensure robust authentication security for your LMS.
