<?php
// app/views/public/certificate_verify.php
?>
<div class="container mx-auto p-4">
  <h2 class="text-xl font-bold mb-2">Certificate Verification</h2>
  <form method="GET" action="/public/certificate_verify.php">
    <input type="text" name="code" placeholder="Enter verification code" class="border px-2 py-1" required>
    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Verify</button>
  </form>
  <?php if (isset($certificate)): ?>
    <div class="mt-4 p-4 bg-green-100 rounded">
      <p><strong>Student:</strong> <?= htmlspecialchars($certificate['student_name']) ?></p>
      <p><strong>Course:</strong> <?= htmlspecialchars($certificate['course_title']) ?></p>
      <p><strong>Date:</strong> <?= $certificate['issue_date'] ?></p>
      <p><strong>Verification Code:</strong> <?= $certificate['certificate_code'] ?></p>
      <p><strong>Status:</strong> <?= $certificate['revoked'] ? 'Revoked' : 'Valid' ?></p>
    </div>
  <?php elseif (isset($error)): ?>
    <div class="mt-4 p-4 bg-red-100 rounded">
      <p><?= htmlspecialchars($error) ?></p>
    </div>
  <?php endif; ?>
</div>
