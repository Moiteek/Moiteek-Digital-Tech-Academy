<?php
require_once '../bootstrap.php';

if(!Auth::isAdminLoggedIn()) {
    Response::redirect('../admin/login.php', 'Please login', 'error');
}

// Get comprehensive statistics
$stats = [];

// Total students by status
$result = $pdo->query("
    SELECT status, COUNT(*) as count 
    FROM students 
    GROUP BY status
");
$stats['students_by_status'] = $result->fetchAll(PDO::FETCH_KEY_PAIR);

// Total enrollments by course
$result = $pdo->query("
    SELECT c.title, COUNT(e.id) as enrollment_count
    FROM enrollments e
    JOIN courses c ON e.course_id = c.id
    GROUP BY e.course_id
    ORDER BY enrollment_count DESC
    LIMIT 10
");
$stats['top_courses'] = $result->fetchAll();

// Enrollment status breakdown
$result = $pdo->query("
    SELECT status, COUNT(*) as count
    FROM enrollments
    GROUP BY status
");
$stats['enrollment_status'] = $result->fetchAll(PDO::FETCH_KEY_PAIR);

// Payment statistics
$result = $pdo->query("
    SELECT payment_status, COUNT(*) as count
    FROM payments
    GROUP BY payment_status
");
$stats['payment_status'] = $result->fetchAll(PDO::FETCH_KEY_PAIR);

// Revenue statistics
$result = $pdo->query("
    SELECT 
        SUM(CASE WHEN payment_status = 'confirmed' THEN amount ELSE 0 END) as confirmed,
        SUM(CASE WHEN payment_status = 'pending' THEN amount ELSE 0 END) as pending,
        SUM(CASE WHEN payment_status = 'failed' THEN amount ELSE 0 END) as failed
    FROM payments
");
$revenue = $result->fetch();

// Course completion statistics
$result = $pdo->query("
    SELECT 
        c.id, c.title,
        COUNT(DISTINCT e.student_id) as total_students,
        COUNT(DISTINCT CASE WHEN e.status = 'completed' THEN e.student_id END) as completed_students
    FROM enrollments e
    JOIN courses c ON e.course_id = c.id
    GROUP BY c.id
    ORDER BY c.id DESC
    LIMIT 10
");
$stats['course_completion'] = $result->fetchAll();

// Top students by module completions
$result = $pdo->query("
    SELECT 
        s.id, CONCAT(s.first_name, ' ', s.last_name) as name,
        COUNT(mp.id) as modules_completed
    FROM students s
    LEFT JOIN module_progress mp ON s.id = mp.student_id AND mp.is_completed = 1
    GROUP BY s.id
    ORDER BY modules_completed DESC
    LIMIT 10
");
$stats['top_students'] = $result->fetchAll();

// Recent enrollments
$result = $pdo->prepare("
    SELECT 
        e.*, 
        CONCAT(s.first_name, ' ', s.last_name) as student_name,
        c.title as course_title
    FROM enrollments e
    JOIN students s ON e.student_id = s.id
    JOIN courses c ON e.course_id = c.id
    ORDER BY e.enrollment_date DESC
    LIMIT 15
");
$result->execute();
$recent_enrollments = $result->fetchAll();

// Get summary stats
$summary = $pdo->query("
    SELECT 
        (SELECT COUNT(*) FROM students) as total_students,
        (SELECT COUNT(*) FROM students WHERE status = 'pending') as pending_students,
        (SELECT COUNT(*) FROM courses) as total_courses,
        (SELECT COUNT(*) FROM enrollments) as total_enrollments,
        (SELECT COUNT(DISTINCT student_id) FROM enrollments) as unique_students_enrolled,
        (SELECT COUNT(*) FROM payments WHERE payment_status = 'confirmed') as confirmed_payments
")->fetch();

$flash = Response::getFlashMessage();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analytics - <?= APP_NAME ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="bg-gray-100">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <i class="fas fa-graduation-cap text-2xl text-blue-600"></i>
                <span class="font-bold text-lg text-gray-800"><?= APP_NAME ?></span>
            </div>
            <div class="flex items-center gap-4">
                <span class="text-gray-600">Admin Dashboard</span>
                <a href="dashboard.php" class="text-gray-600 hover:text-blue-600">
                    <i class="fas fa-home mr-1"></i>Home
                </a>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto p-8">
        <!-- Flash Message -->
        <?php if($flash): ?>
            <div class="mb-6 p-4 rounded-lg bg-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-50 border border-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-200 flex items-center gap-3">
                <i class="fas fa-<?= $flash['type'] === 'error' ? 'exclamation-circle' : 'check-circle' ?> text-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-600"></i>
                <p class="text-<?= $flash['type'] === 'error' ? 'red' : 'green' ?>-700"><?= htmlspecialchars($flash['message']) ?></p>
            </div>
        <?php endif; ?>

        <!-- Page Header -->
        <div class="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-lg shadow p-8 text-white mb-8">
            <h1 class="text-4xl font-bold flex items-center gap-3">
                <i class="fas fa-chart-line"></i>Analytics & Insights
            </h1>
            <p class="text-indigo-100 mt-2">Comprehensive platform statistics and performance metrics</p>
        </div>

        <!-- Summary Cards -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div class="bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg shadow text-white p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-blue-100 text-sm">Total Students</p>
                        <p class="text-4xl font-bold mt-2"><?= $summary['total_students'] ?></p>
                        <p class="text-blue-200 text-xs mt-2">
                            <i class="fas fa-exclamation-circle"></i>
                            <?= $summary['pending_students'] ?> Pending
                        </p>
                    </div>
                    <i class="fas fa-users text-4xl opacity-30"></i>
                </div>
            </div>

            <div class="bg-gradient-to-br from-green-500 to-green-600 rounded-lg shadow text-white p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-green-100 text-sm">Total Courses</p>
                        <p class="text-4xl font-bold mt-2"><?= $summary['total_courses'] ?></p>
                        <p class="text-green-200 text-xs mt-2">
                            <i class="fas fa-graduation-cap"></i>
                            <?= $summary['unique_students_enrolled'] ?> Enrolled
                        </p>
                    </div>
                    <i class="fas fa-book text-4xl opacity-30"></i>
                </div>
            </div>

            <div class="bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg shadow text-white p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-purple-100 text-sm">Total Enrollments</p>
                        <p class="text-4xl font-bold mt-2"><?= $summary['total_enrollments'] ?></p>
                        <p class="text-purple-200 text-xs mt-2">
                            <i class="fas fa-check-circle"></i>
                            <?= $summary['confirmed_payments'] ?> Confirmed
                        </p>
                    </div>
                    <i class="fas fa-list text-4xl opacity-30"></i>
                </div>
            </div>

            <div class="bg-gradient-to-br from-orange-500 to-orange-600 rounded-lg shadow text-white p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-orange-100 text-sm">Total Revenue</p>
                        <p class="text-4xl font-bold mt-2">$<?= number_format($revenue['confirmed'] ?? 0, 2) ?></p>
                        <p class="text-orange-200 text-xs mt-2">
                            Confirmed Payments
                        </p>
                    </div>
                    <i class="fas fa-money-bill text-4xl opacity-30"></i>
                </div>
            </div>
        </div>

        <!-- Charts Row -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <!-- Student Status Chart -->
            <div class="bg-white rounded-lg shadow p-6">
                <h2 class="text-xl font-bold text-gray-800 mb-6 flex items-center gap-2">
                    <i class="fas fa-chart-pie text-blue-600"></i>Student Status Distribution
                </h2>
                <canvas id="studentStatusChart"></canvas>
            </div>

            <!-- Enrollment Status Chart -->
            <div class="bg-white rounded-lg shadow p-6">
                <h2 class="text-xl font-bold text-gray-800 mb-6 flex items-center gap-2">
                    <i class="fas fa-chart-pie text-green-600"></i>Enrollment Status
                </h2>
                <canvas id="enrollmentStatusChart"></canvas>
            </div>
        </div>

        <!-- Revenue Charts -->
        <div class="bg-white rounded-lg shadow p-6 mb-8">
            <h2 class="text-xl font-bold text-gray-800 mb-6 flex items-center gap-2">
                <i class="fas fa-credit-card text-purple-600"></i>Payment Status Breakdown
            </h2>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <div class="border-l-4 border-green-600 pl-4">
                    <p class="text-gray-600 text-sm">Confirmed Payments</p>
                    <p class="text-2xl font-bold text-green-600 mt-1">$<?= number_format($revenue['confirmed'] ?? 0, 2) ?></p>
                </div>
                <div class="border-l-4 border-yellow-600 pl-4">
                    <p class="text-gray-600 text-sm">Pending Payments</p>
                    <p class="text-2xl font-bold text-yellow-600 mt-1">$<?= number_format($revenue['pending'] ?? 0, 2) ?></p>
                </div>
                <div class="border-l-4 border-red-600 pl-4">
                    <p class="text-gray-600 text-sm">Failed Payments</p>
                    <p class="text-2xl font-bold text-red-600 mt-1">$<?= number_format($revenue['failed'] ?? 0, 2) ?></p>
                </div>
            </div>
            <canvas id="paymentStatusChart"></canvas>
        </div>

        <!-- Top Courses and Students -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <!-- Top Courses -->
            <div class="bg-white rounded-lg shadow overflow-hidden">
                <div class="bg-gray-50 p-6 border-b">
                    <h2 class="text-xl font-bold text-gray-800 flex items-center gap-2">
                        <i class="fas fa-chart-bar text-blue-600"></i>Top 10 Courses
                    </h2>
                </div>
                <div class="p-6">
                    <div class="space-y-3">
                        <?php foreach($stats['top_courses'] as $course): ?>
                            <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition">
                                <h4 class="font-semibold text-gray-800 flex-1"><?= htmlspecialchars($course['title']) ?></h4>
                                <span class="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-bold">
                                    <?= $course['enrollment_count'] ?> Students
                                </span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- Top Students -->
            <div class="bg-white rounded-lg shadow overflow-hidden">
                <div class="bg-gray-50 p-6 border-b">
                    <h2 class="text-xl font-bold text-gray-800 flex items-center gap-2">
                        <i class="fas fa-star text-yellow-600"></i>Top Students (by Progress)
                    </h2>
                </div>
                <div class="p-6">
                    <div class="space-y-3">
                        <?php foreach($stats['top_students'] as $index => $student): ?>
                            <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition">
                                <div class="flex items-center gap-3 flex-1">
                                    <span class="w-6 h-6 flex items-center justify-center bg-blue-600 text-white rounded-full text-xs font-bold">
                                        <?= $index + 1 ?>
                                    </span>
                                    <h4 class="font-semibold text-gray-800"><?= htmlspecialchars($student['name']) ?></h4>
                                </div>
                                <span class="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-bold">
                                    <?= $student['modules_completed'] ?> Modules
                                </span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Course Completion Stats -->
        <div class="bg-white rounded-lg shadow overflow-hidden mb-8">
            <div class="bg-gray-50 p-6 border-b">
                <h2 class="text-xl font-bold text-gray-800 flex items-center gap-2">
                    <i class="fas fa-graduation-cap text-purple-600"></i>Course Completion Statistics
                </h2>
            </div>
            <div class="p-6">
                <div class="overflow-x-auto">
                    <table class="min-w-full">
                        <thead>
                            <tr class="border-b">
                                <th class="px-4 py-3 text-left text-sm font-semibold text-gray-700">Course</th>
                                <th class="px-4 py-3 text-left text-sm font-semibold text-gray-700">Total Students</th>
                                <th class="px-4 py-3 text-left text-sm font-semibold text-gray-700">Completed</th>
                                <th class="px-4 py-3 text-left text-sm font-semibold text-gray-700">Completion Rate</th>
                                <th class="px-4 py-3 text-left text-sm font-semibold text-gray-700">Progress</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($stats['course_completion'] as $course): 
                                $rate = $course['total_students'] > 0 ? ($course['completed_students'] / $course['total_students']) * 100 : 0;
                            ?>
                                <tr class="border-b hover:bg-gray-50 transition">
                                    <td class="px-4 py-3 text-sm text-gray-800 font-semibold"><?= htmlspecialchars($course['title']) ?></td>
                                    <td class="px-4 py-3 text-sm text-gray-700"><?= $course['total_students'] ?></td>
                                    <td class="px-4 py-3 text-sm text-gray-700"><?= $course['completed_students'] ?></td>
                                    <td class="px-4 py-3 text-sm text-gray-700 font-semibold text-blue-600"><?= number_format($rate, 1) ?>%</td>
                                    <td class="px-4 py-3">
                                        <div class="w-24 h-2 bg-gray-200 rounded-full overflow-hidden">
                                            <div class="h-full bg-gradient-to-r from-blue-500 to-purple-600" style="width: <?= $rate ?>%"></div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Recent Enrollments -->
        <div class="bg-white rounded-lg shadow overflow-hidden">
            <div class="bg-gray-50 p-6 border-b">
                <h2 class="text-xl font-bold text-gray-800 flex items-center gap-2">
                    <i class="fas fa-list text-green-600"></i>Recent Enrollments
                </h2>
            </div>
            <div class="p-6">
                <div class="overflow-x-auto">
                    <table class="min-w-full">
                        <thead>
                            <tr class="border-b">
                                <th class="px-4 py-3 text-left text-sm font-semibold text-gray-700">Student</th>
                                <th class="px-4 py-3 text-left text-sm font-semibold text-gray-700">Course</th>
                                <th class="px-4 py-3 text-left text-sm font-semibold text-gray-700">Status</th>
                                <th class="px-4 py-3 text-left text-sm font-semibold text-gray-700">Payment</th>
                                <th class="px-4 py-3 text-left text-sm font-semibold text-gray-700">Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($recent_enrollments as $enrollment): ?>
                                <tr class="border-b hover:bg-gray-50 transition">
                                    <td class="px-4 py-3 text-sm text-gray-800 font-semibold"><?= htmlspecialchars($enrollment['student_name']) ?></td>
                                    <td class="px-4 py-3 text-sm text-gray-700"><?= htmlspecialchars($enrollment['course_title']) ?></td>
                                    <td class="px-4 py-3 text-sm">
                                        <span class="inline-block px-2 py-1 rounded text-xs font-semibold bg-<?= $enrollment['status'] === 'active' ? 'green' : 'gray' ?>-100 text-<?= $enrollment['status'] === 'active' ? 'green' : 'gray' ?>-800">
                                            <?= ucfirst($enrollment['status']) ?>
                                        </span>
                                    </td>
                                    <td class="px-4 py-3 text-sm">
                                        <span class="inline-block px-2 py-1 rounded text-xs font-semibold bg-<?= $enrollment['payment_status'] === 'confirmed' ? 'green' : 'yellow' ?>-100 text-<?= $enrollment['payment_status'] === 'confirmed' ? 'green' : 'yellow' ?>-800">
                                            <?= ucfirst($enrollment['payment_status'] ?? 'pending') ?>
                                        </span>
                                    </td>
                                    <td class="px-4 py-3 text-sm text-gray-600"><?= date('M d, Y', strtotime($enrollment['enrollment_date'])) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Student Status Chart
        const studentStatusCtx = document.getElementById('studentStatusChart').getContext('2d');
        new Chart(studentStatusCtx, {
            type: 'doughnut',
            data: {
                labels: <?= json_encode(array_keys($stats['students_by_status'])) ?>,
                datasets: [{
                    data: <?= json_encode(array_values($stats['students_by_status'])) ?>,
                    backgroundColor: ['#3B82F6', '#10B981', '#F59E0B', '#EF4444'],
                    borderColor: '#fff',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { position: 'bottom' }
                }
            }
        });

        // Enrollment Status Chart
        const enrollmentStatusCtx = document.getElementById('enrollmentStatusChart').getContext('2d');
        new Chart(enrollmentStatusCtx, {
            type: 'doughnut',
            data: {
                labels: <?= json_encode(array_keys($stats['enrollment_status'])) ?>,
                datasets: [{
                    data: <?= json_encode(array_values($stats['enrollment_status'])) ?>,
                    backgroundColor: ['#10B981', '#F59E0B', '#EF4444'],
                    borderColor: '#fff',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { position: 'bottom' }
                }
            }
        });

        // Payment Status Chart
        const paymentStatusCtx = document.getElementById('paymentStatusChart').getContext('2d');
        new Chart(paymentStatusCtx, {
            type: 'bar',
            data: {
                labels: <?= json_encode(array_keys($stats['payment_status'])) ?>,
                datasets: [{
                    label: 'Payment Count',
                    data: <?= json_encode(array_values($stats['payment_status'])) ?>,
                    backgroundColor: ['#10B981', '#F59E0B', '#EF4444'],
                    borderColor: ['#059669', '#D97706', '#DC2626'],
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });
    </script>
</body>
</html>
