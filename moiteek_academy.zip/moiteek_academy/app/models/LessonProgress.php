<?php
// app/models/LessonProgress.php
class LessonProgress extends Model {
    public static function markWatched($enrollmentId, $lessonId) {
        $sql = "INSERT INTO lesson_progress (enrollment_id, lesson_id, watched_at) VALUES (?, ?, NOW()) ON DUPLICATE KEY UPDATE watched_at = NOW()";
        return self::insert($sql, [$enrollmentId, $lessonId]);
    }
    public static function getProgress($enrollmentId) {
        $sql = "SELECT COUNT(*) as watched FROM lesson_progress WHERE enrollment_id = ?";
        $watched = self::fetchOne($sql, [$enrollmentId]);
        $sql2 = "SELECT COUNT(*) as total FROM lessons WHERE course_id = (SELECT course_id FROM enrollments WHERE id = ?)";
        $total = self::fetchOne($sql2, [$enrollmentId]);
        $percent = $total['total'] > 0 ? round($watched['watched'] / $total['total'] * 100) : 0;
        return ['watched' => $watched['watched'], 'total' => $total['total'], 'percent' => $percent];
    }
    public static function getStudentAnalytics($courseId) {
        $sql = "SELECT s.id, s.fullname, COUNT(lp.lesson_id) as watched, COUNT(l.id) as total, ROUND(COUNT(lp.lesson_id)/COUNT(l.id)*100) as percent FROM students s JOIN enrollments e ON s.id = e.student_id AND e.course_id = ? LEFT JOIN lesson_progress lp ON lp.enrollment_id = e.id LEFT JOIN lessons l ON l.course_id = ? GROUP BY s.id";
        return self::fetchAll($sql, [$courseId, $courseId]);
    }
}
