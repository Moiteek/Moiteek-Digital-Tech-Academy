<?php
// app/views/student/lesson_view.php
// Responsive video player, resource links, completion button
?>
<div class="container mx-auto p-4">
  <h2 class="text-xl font-bold mb-2">Lesson: <?= htmlspecialchars($lesson['title']) ?></h2>
  <div class="mb-4">
    <?php if ($lesson['video_type'] === 'youtube'): ?>
      <iframe class="w-full aspect-video" src="https://www.youtube.com/embed/<?= htmlspecialchars($lesson['video_url']) ?>" allowfullscreen></iframe>
    <?php elseif ($lesson['video_type'] === 'vimeo'): ?>
      <iframe class="w-full aspect-video" src="https://player.vimeo.com/video/<?= htmlspecialchars($lesson['video_url']) ?>" allowfullscreen></iframe>
    <?php elseif ($lesson['video_type'] === 'upload'): ?>
      <video class="w-full aspect-video" controls>
        <source src="/uploads/videos/<?= htmlspecialchars($lesson['video_file']) ?>" type="video/mp4">
        Your browser does not support the video tag.
      </video>
    <?php endif; ?>
  </div>
  <div class="mb-4">
    <h3 class="font-semibold">Resources:</h3>
    <ul>
      <?php foreach (explode("\n", $lesson['resource_links']) as $link): ?>
        <li><a href="<?= htmlspecialchars($link) ?>" class="text-blue-600 underline" target="_blank">Resource</a></li>
      <?php endforeach; ?>
    </ul>
  </div>
  <form method="POST" action="/student/mark_completed.php">
    <input type="hidden" name="lesson_id" value="<?= $lesson['id'] ?>">
    <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded">Mark Completed</button>
  </form>
</div>
