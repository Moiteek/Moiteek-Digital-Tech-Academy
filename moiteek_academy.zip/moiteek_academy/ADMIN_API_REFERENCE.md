# Admin Dashboard API & Endpoints Reference

## 🗺️ Complete Navigation Map

### Dashboard Entry Points

#### 1. **Dashboard Home**
**URL**: `/admin/dashboard.php`
**Access**: Admin users via `Auth::isAdminLoggedIn()`
**Display**:
- Summary statistics (students, courses, enrollments, revenue)
- Gradient revenue cards (total, confirmed, pending, completion %)
- Top 10 courses by enrollment
- System status widget
- Recent 15 enrollments
- Quick action links

**GET Parameters**: None
**POST Parameters**: None

---

#### 2. **Students List**
**URL**: `/admin/students.php`
**Methods**: GET (view/filter), POST (actions)

**GET Parameters**:
```
search  - Search by name/email
status  - Filter by status (pending|approved|suspended|rejected)
```

**Example:**
```
/admin/students.php?status=pending
/admin/students.php?search=john
/admin/students.php?status=approved&search=doe
```

**Features**:
- List all students with filters
- Search by name or email
- Filter by status
- Stats cards showing breakdown
- Action buttons: View, Approve, Suspend, Reject, Delete, Activate

**POST Actions**: approve | suspend | reject | delete | activate

**POST Parameters**:
```
action          - Action to perform
student_id      - Target student ID
```

---

#### 3. **Student Detail**
**URL**: `/admin/student-detail.php?id=<student_id>`
**Methods**: GET (view), POST (actions)

**GET Parameters**:
```
id                - Student ID (required)
show_credentials  - Show generated credentials modal (optional)
```

**POST Actions**: approve | suspend | activate | generate_credentials

**Display**:
- Student header with status badge
- Quick stats: Joined, Courses Enrolled, Total Paid, Last Login
- Action buttons: Approve, Suspend, Activate, Generate Credentials
- Enrollments tab (courses, payment status)
- Payments tab (payment history, amounts, dates)
- Course Progress tab (completed modules)

**Credentials Generation**:
- Format: `firstname_lastname_XXX` (first name + last name + 3 random digits)
- Password: 12 random hex characters
- Copy-to-clipboard functionality
- Modal display with sharing instructions

---

#### 4. **Courses List**
**URL**: `/admin/courses.php`
**Methods**: GET (view), POST (actions)

**Features**:
- Grid view of all courses
- Professional cards with gradient headers
- Course stats: modules, enrollments, price
- Status badge (Published/Draft)
- Filter/search functionality

**POST Actions**: delete | publish | unpublish

**POST Parameters**:
```
action      - Action to perform
course_id   - Target course ID
```

**Grid Display**:
- Course title and description
- Instructor name
- Price
- Module count
- Enrollment count
- Action buttons: View Details, Edit, Publish/Unpublish, Delete

---

#### 5. **Course Form (Add/Edit)**
**URL**: `/admin/course-form.php`
**Methods**: GET (display), POST (save)

**GET Parameters**:
```
id  - Course ID for edit mode (optional, omit for add mode)
```

**POST Parameters** (all optional):
```
title                   - Course title (required)
description             - Short description (required)
detailed_description    - Full description
price                   - Course price (decimal)
instructor_name         - Instructor name
level                   - Level (beginner|intermediate|advanced)
category                - Course category
duration                - Duration (e.g., "6 weeks")
```

**Mode Detection**:
- **Add Mode**: No GET['id'] → Creates INSERT, auto-generates slug
- **Edit Mode**: GET['id'] present → Shows current data, allows UPDATE

**Embedded Lessons Section** (Edit Mode Only):
- Button: "Add New Lesson" → Links to `/admin/lesson-form.php?course_id=<id>`
- List existing lessons with edit/delete buttons
- Shows title, duration, sequence order

**Embedded Resources Section** (Edit Mode Only):
- Button: "Add New Resource" → Links to `/admin/resource-form.php?course_id=<id>`
- List existing resources with edit/delete buttons
- Shows type and preview

---

#### 6. **Lesson Form (Add/Edit)**
**URL**: `/admin/lesson-form.php`
**Methods**: GET (display), POST (save)

**GET Parameters**:
```
course_id   - Course ID (required for both add/edit)
id          - Lesson ID for edit mode (optional)
```

**POST Parameters**:
```
course_id               - Course ID (required)
title                   - Lesson title (required)
description             - Short description
content                 - Detailed content (supports markdown)
video_url               - YouTube video (supports multiple formats)
duration                - Duration in minutes
sequence_order          - Display order
```

**YouTube URL Formats Supported**:
```
https://www.youtube.com/watch?v=VIDEO_ID
https://youtu.be/VIDEO_ID
VIDEO_ID (just the ID)
```

**Video Preview**: Live embedded YouTube player shows selected video

**Database Operations**:
- **Add**: INSERT into course_modules, INCREMENT total_modules
- **Edit**: UPDATE course_modules
- **Navigation**: Back button returns to course-form.php

---

#### 7. **Resource Form (Add/Edit)**
**URL**: `/admin/resource-form.php`
**Methods**: GET (display), POST (save)

**GET Parameters**:
```
course_id   - Course ID (required for both add/edit)
id          - Resource ID for edit mode (optional)
```

**POST Parameters**:
```
course_id       - Course ID (required)
title           - Resource title (required)
description     - Resource description
resource_type   - Type of resource (see below)
file_url        - URL to resource (required)
is_external     - External resource flag (1|0)
```

**Resource Types**:
```
pdf         - PDF documents
book        - E-books and books
code        - Code repositories (GitHub, etc.)
template    - Code templates and starters
document    - Office documents (Word, Excel, etc.)
other       - Other types
```

**Supported Services**:
- Google Drive links
- GitHub repositories
- CodePen projects
- AWS S3 links
- Firebase Storage
- OneDrive
- Dropbox
- Direct download URLs

**Resource Preview**: Shows card as students will see it with icon and open button

---

#### 8. **Payments Management**
**URL**: `/admin/payments.php`
**Methods**: GET (view/filter), POST (actions)

**GET Parameters**:
```
status  - Filter by status (pending|confirmed|failed)
search  - Search by student name, email, or course title
```

**Examples**:
```
/admin/payments.php?status=pending
/admin/payments.php?search=john
/admin/payments.php?status=confirmed&search=web
```

**POST Actions**: confirm | reject

**POST Parameters**:
```
payment_id  - Target payment ID
action      - confirm | reject
```

**Display**:
- Statistics cards: Total, Confirmed, Pending, Failed payments
- Filter form (status dropdown)
- Search form (name/email/course)
- Payments table with:
  - Payment ID
  - Student name & email
  - Course name
  - Payment method
  - Amount
  - Status (badge)
  - Date
  - Actions (View, Confirm, Reject)

**Confirm Payment**:
- Updates payment_status = 'confirmed'
- Records confirmed_by = admin_id
- Confirms enrollment

**Reject Payment**:
- Updates payment_status = 'failed'
- Records rejection reason
- May send rejection email to student

---

#### 9. **Analytics Dashboard**
**URL**: `/admin/analytics.php`
**Methods**: GET only (view)

**Features**:

**Summary Statistics Cards**:
- Total Students (with pending count)
- Total Courses (with enrollment count)
- Total Enrollments (with confirmed count)
- Revenue (confirmed payments only)

**Charts Implemented**:

1. **Student Status Distribution** (Doughnut)
   - Data: COUNT(*) GROUP BY status
   - Colors: Blue, Green, Orange, Red
   - Labels: pending, approved, rejected, suspended

2. **Enrollment Status** (Doughnut)
   - Data: Count by enrollment status
   - Status: active, completed, dropped

3. **Payment Status Breakdown** (Bar)
   - Shows count of payments by status
   - Revenue totals per status

**Data Tables**:

1. **Top 10 Courses**
   - Course name
   - Student count
   - Sortable, clickable

2. **Top Students** (by module completions)
   - Rank 1-10
   - Student name
   - Modules completed count

3. **Course Completion Statistics**
   - Course name
   - Total students
   - Students completed
   - Completion % (with progress bar)
   - Interactive progress visualization

4. **Recent Enrollments** (Last 15)
   - Student name & email
   - Course
   - Enrollment status
   - Payment status
   - Date

**No Parameters**: Uses direct database queries for all data

---

## 🔄 Database Query Reference

### Query Patterns Used

**1. Student Count by Status**
```sql
SELECT status, COUNT(*) as count 
FROM students 
GROUP BY status
```

**2. Course Enrollments**
```sql
SELECT c.title, COUNT(e.id) as enrollment_count
FROM enrollments e
JOIN courses c ON e.course_id = c.id
GROUP BY e.course_id
ORDER BY enrollment_count DESC
LIMIT 10
```

**3. Revenue Summary**
```sql
SELECT 
    SUM(CASE WHEN payment_status = 'confirmed' THEN amount ELSE 0 END) as confirmed,
    SUM(CASE WHEN payment_status = 'pending' THEN amount ELSE 0 END) as pending,
    SUM(CASE WHEN payment_status = 'failed' THEN amount ELSE 0 END) as failed
FROM payments
```

**4. Course Completion**
```sql
SELECT 
    c.id, c.title,
    COUNT(DISTINCT e.student_id) as total_students,
    COUNT(DISTINCT CASE WHEN e.status = 'completed' THEN e.student_id END) as completed_students
FROM enrollments e
JOIN courses c ON e.course_id = c.id
GROUP BY c.id
```

**5. Top Students**
```sql
SELECT 
    s.id, CONCAT(s.first_name, ' ', s.last_name) as name,
    COUNT(mp.id) as modules_completed
FROM students s
LEFT JOIN module_progress mp ON s.id = mp.student_id AND mp.is_completed = 1
GROUP BY s.id
ORDER BY modules_completed DESC
LIMIT 10
```

---

## 🔐 Authentication & Authorization

**Required for ALL Admin Pages**:
```php
if(!Auth::isAdminLoggedIn()) {
    Response::redirect('../admin/login.php', 'Please login', 'error');
}
```

**Admin-Only Actions**:
- Approve students
- Suspend/reactivate students
- Delete students/courses
- Generate credentials
- Confirm/reject payments
- Publish/unpublish courses
- Create, edit, delete lessons and resources

---

## 📝 Response Codes & Messages

### Success Messages (Green)
```
"Student approved successfully!"
"Course created successfully!"
"Payment confirmed successfully!"
"Lesson added successfully!"
"Resource updated successfully!"
```

### Error Messages (Red)
```
"Student not found!"
"Course title is required!"
"Invalid payment ID!"
"Lesson creation failed!"
```

### Warning Messages (Yellow)
```
"Payment approved but error sending credentials"
"Some operations pending review"
```

---

## 🎯 Flow Diagrams

### Student Management Flow
```
Dashboard
  ↓
Students List ← search/filter
  ↓
Student Detail
  ├→ Approve (pending → approved)
  ├→ Suspend (active → suspended)
  ├→ Activate (suspended → active)
  ├→ Delete (cascade all records)
  └→ Generate Credentials (username/password)
```

### Course Management Flow
```
Dashboard
  ↓
Courses List
  ├→ Add Course (→ course-form.php)
  │   ├→ Add Lesson (→ lesson-form.php)
  │   └→ Add Resource (→ resource-form.php)
  │
  ├→ Edit Course (→ course-form.php?id=X)
  │   ├→ Edit Lesson (→ lesson-form.php?id=Y)
  │   └→ Edit Resource (→ resource-form.php?id=Z)
  │
  ├→ Publish/Unpublish (toggle is_published)
  └→ Delete (cascade enrollments, modules, resources)
```

### Payment Processing Flow
```
Dashboard
  ↓
Payments List
  ├→ Filter/Search
  │
  ├→ Pending Payments
  │   ├→ Review Details (modal)
  │   ├→ Approve (status → 'confirmed')
  │   └→ Reject (status → 'failed')
  │
  └→ Approved/Rejected (view only)
```

### Analytics Flow
```
Dashboard
  ↓
Analytics
  ├→ Summary Statistics (4 gradient cards)
  │
  ├→ Charts
  │   ├→ Student Status (doughnut)
  │   ├→ Enrollment Status (doughnut)
  │   └→ Payment Status (bar)
  │
  ├→ Tables
  │   ├→ Top 10 Courses
  │   ├→ Top 10 Students
  │   ├→ Course Completion Stats
  │   └→ Recent 15 Enrollments
  │
  └→ All data auto-updates from database
```

---

## 🛠️ Maintenance Endpoints

### Database Maintenance
- Automatic CASCADE deletes maintain referential integrity
- No orphaned records possible
- Foreign keys enforced

### Performance Optimization
- Indexed queries on frequently searched fields
- GROUP BY aggregations for statistics
- LEFT JOINs prevent data loss
- LIMIT clauses prevent excessive data transfer

### Logging
- All admin actions logged (if logging system exists)
- Flash messages show operation success/failure
- Error pages prevent information disclosure

---

## 📊 API Summary Table

| Page | URL | Methods | Key Features |
|------|-----|---------|--------------|
| Dashboard | `/admin/dashboard.php` | GET | Stats, charts, recent activity |
| Students | `/admin/students.php` | GET, POST | List, search, filter, CRUD |
| Student Detail | `/admin/student-detail.php?id=X` | GET, POST | Profile, enrollments, payments, credential generation |
| Courses | `/admin/courses.php` | GET, POST | Grid, CRUD, publish/unpublish |
| Course Form | `/admin/course-form.php?id=X` | GET, POST | Add/edit with lessons & resources |
| Lesson Form | `/admin/lesson-form.php?course_id=X&id=Y` | GET, POST | Add/edit lessons with YouTube |
| Resource Form | `/admin/resource-form.php?course_id=X&id=Y` | GET, POST | Add/edit resources (multiple types) |
| Payments | `/admin/payments.php` | GET, POST | List, filter, approve/reject |
| Analytics | `/admin/analytics.php` | GET | Charts, statistics, insights |

---

## 💡 API Usage Examples

### Add a New Course
```
1. GET /admin/course-form.php (see blank form)
2. POST /admin/course-form.php with:
   - title = "Web Development 101"
   - description = "Learn web basics"
   - price = 99.99
   - instructor_name = "John Doe"
   - level = "beginner"
3. Redirect to /admin/courses.php on success
```

### Approve a Student
```
1. GET /admin/student-detail.php?id=42 (see student profile)
2. Click "Approve" button
3. POST /admin/student-detail.php with:
   - action = "approve"
4. Status changes from "pending" → "approved"
5. Flash message: "Student approved successfully!"
```

### Process a Payment
```
1. GET /admin/payments.php?status=pending (see pending)
2. Click "Review" on payment
3. Modal shows payment details
4. Click "Approve" or "Reject"
5. POST /admin/payments.php with:
   - action = "confirm" or "reject"
   - payment_id = 123
6. Status updates, notification sent
```

### View Analytics
```
1. GET /admin/analytics.php
2. Auto-fetches all SQL data
3. Charts render with Chart.js
4. Tables display with sorting/filtering
5. All data is read-only (view-only endpoint)
```

---

## 🔑 Key Constants

| Constant | Value | Usage |
|----------|-------|-------|
| RESOURCE_TYPES | pdf, book, code, template, document, other | Resource type select |
| COURSE_LEVELS | beginner, intermediate, advanced | Course level select |
| STUDENT_STATUS | pending, approved, rejected, suspended | Student status filter |
| PAYMENT_STATUS | pending, confirmed, failed | Payment status filter |

---

**Last Updated**: 2024
**API Version**: 1.0
**Status**: Production Ready
