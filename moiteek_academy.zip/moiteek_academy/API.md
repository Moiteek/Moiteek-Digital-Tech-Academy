# API Reference - Moiteek Academy

Complete reference for internal PHP classes, database functions, and system APIs.

---

## 📋 **Table of Contents**

1. [Auth Class](#auth-class)
2. [Validator Class](#validator-class)
3. [Database Class](#database-class)
4. [Response Class](#response-class)
5. [FileManager Class](#filemanager-class)
6. [Database Schema](#database-schema)

---

## 🔐 **Auth Class** (`includes/Auth.php`)

Core authentication and password management.

### **Password Methods**

#### `hashPassword($password)`
Creates bcrypt hash of password.

**Parameters:**
- `string` **$password** - Plain text password

**Returns:** 
- `string` - Bcrypt hash (60 characters)

**Example:**
```php
$hash = Auth::hashPassword('SecurePassword123!');
// Returns: $2y$10$abc...
```

---

#### `verifyPassword($plainPassword, $hash)`
Verifies plain password against bcrypt hash.

**Parameters:**
- `string` **$plainPassword** - Plain text password to verify
- `string` **$hash** - Bcrypt hash to compare against

**Returns:** 
- `bool` - true if password matches, false otherwise

**Example:**
```php
if (Auth::verifyPassword($input, $storedHash)) {
    echo "Password correct!";
}
```

---

### **Student Authentication**

#### `loginStudent($emailOrUsername, $password)`
Authenticates and logs in a student.

**Parameters:**
- `string` **$emailOrUsername** - Student email or username
- `string` **$password** - Plain text password

**Returns:** 
- `bool` - true if login successful, false otherwise

**Side Effects:**
- Sets session variables on success
- Redirects to admin login page on failure

**Example:**
```php
if (Auth::loginStudent('student@example.com', 'pass')) {
    // Student logged in, session set
}
```

---

#### `isStudentLoggedIn()`
Checks if current session is an authenticated student.

**Returns:** 
- `bool` - true if student is logged in

**Example:**
```php
if (!Auth::isStudentLoggedIn()) {
    Response::redirect('auth/login.php');
}
```

---

### **Admin Authentication**

#### `loginAdmin($email, $password)`
Authenticates and logs in an admin user.

**Parameters:**
- `string` **$email** - Admin email
- `string` **$password** - Plain text password

**Returns:** 
- `bool` - true if login successful

**Example:**
```php
if (Auth::loginAdmin('admin@moiteek.com', 'Admin@123')) {
    // Admin logged in
}
```

---

#### `isAdminLoggedIn()`
Checks if current session is an authenticated admin.

**Returns:** 
- `bool` - true if admin is logged in

**Example:**
```php
if (!Auth::isAdminLoggedIn()) {
    Response::redirect('auth/login.php?role=admin');
}
```

---

### **Session Management**

#### `logout()`
Destroys current session and clears all session data.

**Example:**
```php
Auth::logout();
// Session destroyed, user logged out
Response::redirect('index.php');
```

---

#### `getCurrentUserId()`
Gets ID of currently logged-in user.

**Returns:** 
- `int|null` - User ID if logged in, null otherwise

**Example:**
```php
$userId = Auth::getCurrentUserId();
if ($userId) {
    echo "User ID: " . $userId;
}
```

---

#### `getCurrentUserType()`
Gets role of currently logged-in user.

**Returns:** 
- `string|null` - 'admin', 'student', or null if not logged in

**Example:**
```php
if (Auth::getCurrentUserType() === 'admin') {
    // Show admin menu
}
```

---

## ✅ **Validator Class** (`includes/Validator.php`)

Input validation and error tracking.

### **Email Validation**

#### `validateEmail($email)`
Validates email format and structure.

**Parameters:**
- `string` **$email** - Email to validate

**Validation Rules:**
- Must be valid email format
- Must contain @ symbol
- Must have domain

**Example:**
```php
$validator = new Validator();
$validator->validateEmail('user@example.com');

if ($validator->getErrors()) {
    echo "Invalid email!";
}
```

---

### **Password Validation**

#### `validatePassword($password)`
Validates password strength.

**Parameters:**
- `string` **$password** - Password to validate

**Validation Rules:**
- Minimum 8 characters
- At least 1 uppercase letter
- At least 1 lowercase letter
- At least 1 number
- At least 1 special character (@$!%*?&)

**Example:**
```php
$validator->validatePassword('SecurePass123!');

if ($validator->getErrors()) {
    foreach ($validator->getErrors() as $error) {
        echo $error . "\n";
    }
}
```

---

### **Name Validation**

#### `validateFullName($name)`
Validates full name format.

**Parameters:**
- `string` **$name** - Full name to validate

**Validation Rules:**
- At least 3 characters
- Cannot be empty
- Should contain first and last name

**Example:**
```php
$validator->validateFullName('John Doe');
```

---

### **Phone Validation**

#### `validatePhone($phone)`
Validates phone number format.

**Parameters:**
- `string` **$phone** - Phone number to validate

**Validation Rules:**
- At least 10 digits
- Numeric format allowed with +, -, spaces

**Example:**
```php
$validator->validatePhone('+1-555-123-4567');
```

---

### **Username Validation**

#### `validateUsername($username)`
Validates username format.

**Parameters:**
- `string` **$username** - Username to validate

**Validation Rules:**
- At least 3 characters
- Alphanumeric and underscore only
- Cannot start with number

**Example:**
```php
$validator->validateUsername('john_doe123');
```

---

### **Amount Validation**

#### `validateAmount($amount)`
Validates numeric amount.

**Parameters:**
- `string` **$amount** - Amount to validate

**Validation Rules:**
- Must be numeric
- Must be positive
- Decimal format allowed

**Example:**
```php
$validator->validateAmount('99.99');
```

---

### **File Upload Validation**

#### `validateFileUpload($file)`
Validates uploaded file.

**Parameters:**
- `array` **$file** - $_FILES array element

**Validation Rules:**
- File size ≤ 5MB
- Type in: jpg, jpeg, png, pdf
- File must exist

**Throws:** `Exception` if validation fails

**Example:**
```php
try {
    $validator->validateFileUpload($_FILES['proof']);
} catch (Exception $e) {
    echo "File error: " . $e->getMessage();
}
```

---

### **Error Management**

#### `getErrors()`
Gets array of all validation errors.

**Returns:** 
- `array` - Array of error messages

**Example:**
```php
if ($errors = $validator->getErrors()) {
    foreach ($errors as $error) {
        echo "<div class='error'>" . htmlspecialchars($error) . "</div>";
    }
}
```

---

#### `clearErrors()`
Clears all stored validation errors.

**Example:**
```php
$validator->clearErrors();
// Now getErrors() returns empty array
```

---

### **Input Sanitization**

#### `sanitizeInput($input)`
Sanitizes string input for safe output.

**Parameters:**
- `string` **$input** - Input to sanitize

**Returns:** 
- `string` - Sanitized output-safe string

**Example:**
```php
$safe = Validator::sanitizeInput("<script>alert('xss')</script>");
echo $safe; // Shows: &lt;script&gt;alert('xss')&lt;/script&gt;
```

---

## 🗄️ **Database Class** (`includes/Database.php`)

Database queries and statistics.

### **Existence Checks**

#### `emailExists($email)`
Checks if email is already registered.

**Parameters:**
- `string` **$email** - Email to check

**Returns:** 
- `bool` - true if email exists

**Example:**
```php
if ($db->emailExists('user@example.com')) {
    echo "Email already registered";
}
```

---

#### `usernameExists($username)`
Checks if username is already taken.

**Parameters:**
- `string` **$username** - Username to check

**Returns:** 
- `bool` - true if username exists

**Example:**
```php
if ($db->usernameExists('john_doe')) {
    Response::error('Username already taken');
}
```

---

### **User Retrieval**

#### `getUserById($userId, $type='student')`
Gets user information by ID.

**Parameters:**
- `int` **$userId** - User ID
- `string` **$type** - 'student' or 'admin' (default: 'student')

**Returns:** 
- `array|null` - User data or null if not found

**Example:**
```php
$student = $db->getUserById(5);
echo $student['fullname']; // Returns: "John Doe"
```

---

### **Course Queries**

#### `getCourses($limit=10)`
Gets all published courses.

**Parameters:**
- `int` **$limit** - Number of courses to return (default: 10)

**Returns:** 
- `array` - Array of course arrays

**Example:**
```php
$courses = $db->getCourses(20);
foreach ($courses as $course) {
    echo $course['title'];
}
```

---

#### `getCourseById($courseId)`
Gets detailed course information.

**Parameters:**
- `int` **$courseId** - Course ID

**Returns:** 
- `array|null` - Course data or null if not found

**Example:**
```php
$course = $db->getCourseById(1);
echo $course['description'];
```

---

### **Enrollment Functions**

#### `getStudentEnrollments($studentId)`
Gets all courses enrolled by a student.

**Parameters:**
- `int` **$studentId** - Student ID

**Returns:** 
- `array` - Array of enrollment records

**Example:**
```php
$enrollments = $db->getStudentEnrollments(5);
foreach ($enrollments as $enrollment) {
    echo $enrollment['course_title']; // Course title
    echo $enrollment['progress_percentage']; // Progress %
}
```

---

#### `getCourseEnrollments($courseId)`
Gets all students enrolled in a course.

**Parameters:**
- `int` **$courseId** - Course ID

**Returns:** 
- `array` - Array of student enrollment records

**Example:**
```php
$students = $db->getCourseEnrollments(1);
echo "Total enrolled: " . count($students);
```

---

### **Pending Items**

#### `getPendingStudents()`
Gets students awaiting admin approval.

**Returns:** 
- `array` - Array of pending student records

**Example:**
```php
$pending = $db->getPendingStudents();
echo "Pending approval: " . count($pending);
```

---

#### `getPendingEnrollments()`
Gets enrollments with pending payment confirmation.

**Returns:** 
- `array` - Array of pending enrollment records

**Example:**
```php
$pending = $db->getPendingEnrollments();
foreach ($pending as $enrollment) {
    echo $enrollment['student_name'];
}
```

---

### **Status Updates**

#### `updateStudentStatus($studentId, $status, $note='')`
Updates student approval status.

**Parameters:**
- `int` **$studentId** - Student ID
- `string` **$status** - 'approved', 'rejected', 'suspended'
- `string` **$note** - Optional admin note

**Returns:** 
- `bool` - true if update successful

**Example:**
```php
if ($db->updateStudentStatus(5, 'approved')) {
    echo "Student approved!";
}
```

---

### **Statistics**

#### `getTotalStudents()`
Gets count of all students.

**Returns:** 
- `int` - Number of students

**Example:**
```php
$total = $db->getTotalStudents();
echo "Total students: " . $total;
```

---

#### `getTotalCourses()`
Gets count of all courses.

**Returns:** 
- `int` - Number of courses

**Example:**
```php
$courseCount = $db->getTotalCourses();
```

---

#### `getTotalEnrollments()`
Gets count of all enrollments.

**Returns:** 
- `int` - Number of total enrollments

**Example:**
```php
$enrollCount = $db->getTotalEnrollments();
```

---

#### `getRevenueSummary()`
Gets total revenue from confirmed payments.

**Returns:** 
- `array` - ['total_revenue' => amount, 'confirmed_payments' => count]

**Example:**
```php
$revenue = $db->getRevenueSummary();
echo "Revenue: $" . $revenue['total_revenue'];
echo "Confirmed payments: " . $revenue['confirmed_payments'];
```

---

## 📤 **Response Class** (`includes/Response.php`)

HTTP responses and messaging.

### **Flash Messages**

#### `success($message)`
Sets success message in session and optionally redirects.

**Parameters:**
- `string` **$message** - Success message to display

**Returns:** 
- `void` - Message stored in session

**Example:**
```php
Response::success('Payment confirmed!');
Response::redirect('admin/payments.php');
```

---

#### `error($message)`
Displays error message and exits.

**Parameters:**
- `string` **$message** - Error message string

**Returns:** 
- `void` - Exits after displaying error

**Example:**
```php
if (!$valid) {
    Response::error('Invalid email format');
}
```

---

### **Redirects**

#### `redirect($url)`
Redirects to specified URL.

**Parameters:**
- `string` **$url** - Target URL (relative or absolute)

**Returns:** 
- `void` - Exits after redirect

**Example:**
```php
Response::redirect('admin/dashboard.php');
Response::redirect('admin/students.php?tab=pending');
```

---

### **Display Messages**

#### `getFlashMessage()`
Retrieves and displays previously set flash message.

**Returns:** 
- `string|bool` - Message HTML or false if none set

**Example:**
```php
if ($message = Response::getFlashMessage()) {
    echo $message;
}
```

---

### **JSON Response**

#### `json($data, $statusCode=200)`
Returns JSON response (for APIs).

**Parameters:**
- `array` **$data** - Data to encode as JSON
- `int` **$statusCode** - HTTP status code (default: 200)

**Returns:** 
- `void` - Outputs JSON and exits

**Example:**
```php
Response::json([
    'status' => 'success',
    'user' => ['id' => 1, 'name' => 'John']
], 200);
```

---

## 📁 **FileManager Class** (`includes/FileManager.php`)

File upload and management.

### **File Upload**

#### `uploadFile($file)`
Uploads and validates file.

**Parameters:**
- `array` **$file** - $_FILES array element

**Returns:** 
- `string` - Uploaded filename

**Throws:** `Exception` if upload fails

**Upload Settings:**
- Max size: 5MB
- Allowed types: jpg, jpeg, png, pdf
- Save location: `uploads/payments/`

**Example:**
```php
try {
    $filename = $fileManager->uploadFile($_FILES['proof']);
    echo "Saved as: " . $filename;
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
```

---

### **File Deletion**

#### `deleteFile($filename)`
Deletes file from storage.

**Parameters:**
- `string` **$filename** - Filename to delete

**Returns:** 
- `bool` - true if deleted successfully

**Example:**
```php
if ($fileManager->deleteFile('payment_proof_123.pdf')) {
    echo "File deleted";
}
```

---

## 🗄️ **Database Schema Reference**

### **admins Table**
```sql
- id INT PRIMARY KEY
- fullname VARCHAR(100)
- email VARCHAR(100) UNIQUE
- password VARCHAR(255) -- bcrypt hash
- phone VARCHAR(20)
- role ENUM('super_admin', 'admin')
- status ENUM('active', 'inactive')
- last_login TIMESTAMP
- created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
```

---

### **students Table**
```sql
- id INT PRIMARY KEY
- fullname VARCHAR(100)
- email VARCHAR(100) UNIQUE
- username VARCHAR(50) UNIQUE
- password VARCHAR(255) -- bcrypt hash
- phone VARCHAR(20)
- profile_picture VARCHAR(255)
- status ENUM('pending', 'approved', 'rejected', 'suspended')
- is_active TINYINT DEFAULT 1
- created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
- updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE
```

---

### **courses Table**
```sql
- id INT PRIMARY KEY
- title VARCHAR(200) UNIQUE
- slug VARCHAR(200) UNIQUE
- description LONGTEXT
- price DECIMAL(10,2)
- thumbnail VARCHAR(255)
- level ENUM('beginner', 'intermediate', 'advanced')
- category VARCHAR(50)
- total_modules INT DEFAULT 0
- total_lessons INT DEFAULT 0
- is_published TINYINT DEFAULT 1
- created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
```

---

### **enrollments Table**
```sql
- id INT PRIMARY KEY
- student_id INT (FK - students.id)
- course_id INT (FK - courses.id)
- payment_status ENUM('pending', 'confirmed', 'failed')
- payment_proof VARCHAR(255)
- enrollment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
- created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
```

---

### **payments Table**
```sql
- id INT PRIMARY KEY
- enrollment_id INT (FK - enrollments.id)
- amount DECIMAL(10,2)
- payment_status ENUM('pending', 'confirmed', 'failed')
- confirmed_by INT (FK - admins.id)
- payment_date TIMESTAMP
- created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
```

---

### **progress Table**
```sql
- id INT PRIMARY KEY
- student_id INT (FK - students.id)
- course_id INT (FK - courses.id)
- progress_percentage INT DEFAULT 0
- time_spent INT DEFAULT 0
- completed_modules INT DEFAULT 0
- last_accessed TIMESTAMP
- created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
```

---

## 🔧 **Helper Function Examples**

### **Getting Started with Classes**

```php
<?php
// All pages include bootstrap.php which auto-loads classes

require 'bootstrap.php';

// Now use classes directly
$auth = new Auth();
$validator = new Validator();
$database = new Database();
$fileManager = new FileManager();

// Set PDO on Database class
$database->setPDO($pdo);
```

---

### **Common Workflow Examples**

**Register a Student:**
```php
$validator = new Validator();
$validator->validateEmail($_POST['email']);
$validator->validatePassword($_POST['password']);
$validator->validateFullName($_POST['fullname']);

if ($validator->getErrors()) {
    foreach ($validator->getErrors() as $error) echo $error;
} else {
    $password_hash = Auth::hashPassword($_POST['password']);
    // Insert into database...
}
```

---

**Approve a Student:**
```php
$db = new Database();
$db->setPDO($pdo);

if ($db->updateStudentStatus($_POST['student_id'], 'approved')) {
    Response::success('Student approved successfully');
    Response::redirect('admin/students.php');
}
```

---

**Handle File Upload:**
```php
$fileManager = new FileManager();

try {
    $filename = $fileManager->uploadFile($_FILES['payment_proof']);
    // Insert enrollment with filename...
    Response::success('Payment proof uploaded');
} catch (Exception $e) {
    Response::error($e->getMessage());
}
```

---

**Complete API Documentation** ✅

This reference covers all main classes and functions used throughout Moiteek Academy.
