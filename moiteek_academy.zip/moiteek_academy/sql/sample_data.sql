-- ==========================================
-- SAMPLE DATA FOR LEARNING PORTAL TESTING
-- ==========================================
-- This file contains sample courses, modules, resources, and progress data
-- for testing the Student Learning Portal functionality.
-- Copy and paste relevant sections into your database as needed.

-- ==========================================
-- SAMPLE COURSE (Use existing course or add new)
-- ==========================================

-- Sample course for learning portal testing
INSERT INTO courses (title, description, instructor_name, price, duration_weeks, total_modules, is_published) 
VALUES 
('Web Development Fundamentals', 'Learn HTML, CSS, and JavaScript basics for building modern websites', 'John Developer', 4999, 6, 8, 1)
ON DUPLICATE KEY UPDATE title=VALUES(title);

-- Get the course ID (typically will be the last inserted ID)
-- For demonstration, assuming course_id = 1. Adjust as needed.

-- ==========================================
-- SAMPLE COURSE MODULES (Lessons)
-- ==========================================

INSERT INTO course_modules (course_id, title, description, content, video_url, sequence_order, duration, is_published) VALUES
-- Module 1: Introduction
(1, 'Welcome to Web Development', 
'An introduction to web development and what you will learn',
'In this lesson, you will learn:\n- What web development is\n- Frontend vs Backend development\n- The three pillars of web development: HTML, CSS, JavaScript\n- Tools and setup needed\n\nBy the end of this lesson, you will have a solid understanding of the web development landscape.',
'dQw4w9WgXcQ',
1,
15,
1),

-- Module 2: HTML Basics
(1, 'HTML Fundamentals',
'Learn the structure and basics of HTML markup',
'Learn the fundamental HTML concepts:\n- HTML document structure\n- Common HTML tags (p, div, h1-h6, a, img, etc.)\n- Semantic HTML\n- Forms and input elements\n- Accessibility basics\n\nHTML is the foundation of all web pages. Understanding it well is crucial.',
'9bZkp7q19f0',
2,
45,
1),

-- Module 3: CSS Styling
(1, 'CSS Styling Essentials',
'Master CSS for styling and layout',
'Master CSS fundamentals:\n- CSS syntax and selectors\n- Box model (margin, padding, border)\n- Flexbox for layouts\n- CSS Grid for complex layouts\n- Responsive design with media queries\n- Common CSS patterns\n\nCSS brings styling to life. Learn to create beautiful interfaces.',
'OV8jVBzQvkI',
3,
60,
1),

-- Module 4: JavaScript Basics
(1, 'JavaScript Essentials',
'Introduction to JavaScript programming',
'Get started with JavaScript:\n- JavaScript syntax and variables\n- Data types (strings, numbers, arrays, objects)\n- Control flow (if/else, loops)\n- Functions and scope\n- DOM manipulation basics\n- Event handling\n\nJavaScript brings interactivity to web pages.',
'jS4aFq5-91M',
4,
75,
1),

-- Module 5: DOM Manipulation
(1, 'Working with the DOM',
'Learn to manipulate the Document Object Model with JavaScript',
'Master DOM interactions:\n- Selecting elements (getElementById, querySelector, etc.)\n- Modifying element properties and styles\n- Creating and removing elements\n- Event listeners and handling\n- Building interactive features\n- Debugging JavaScript\n\nDOM manipulation is essential for dynamic web applications.',
'r1r1d0c87fb8',
5,
50,
1),

-- Module 6: Responsive Web Design
(1, 'Building Responsive Websites',
'Create websites that work on all devices',
'Learn responsive design principles:\n- Mobile-first approach\n- Flexible layouts and grids\n- Media queries for different screen sizes\n- Responsive images\n- Touch-friendly interfaces\n- Testing on different devices\n\nModern web development requires responsive design skills.',
'zF6FSJCWOmI',
6,
40,
1),

-- Module 7: Working with APIs
(1, 'Introduction to APIs',
'Fetch data from external services using APIs',
'Work with APIs:\n- What are APIs and why they matter\n- HTTP methods (GET, POST, etc.)\n- Fetch API in JavaScript\n- Handling JSON data\n- Error handling\n- Building dynamic content from API data\n\nAPIs are crucial for modern interactive web applications.',
'DrK0KHXnLPs',
7,
55,
1),

-- Module 8: Project: Build Your First Website
(1, 'Capstone Project',
'Build a complete responsive website using all learned skills',
'In this capstone project, you will:\n- Design a website for a fictional business\n- Implement responsive design\n- Add JavaScript interactivity\n- Fetch data from an API\n- Deploy your website online\n\nThis project ties together everything you learned in this course.',
'pQnVG8_PqHM',
8,
120,
1);

-- ==========================================
-- SAMPLE COURSE RESOURCES (Downloads)
-- ==========================================

INSERT INTO course_resources (course_id, module_id, title, description, resource_type, file_path, file_url, is_external, sequence_order, is_published) VALUES
-- Module 1 Resources
(1, 1, 'Course Overview PDF',
'Complete overview of all topics covered in this course',
'pdf',
'course_1/module_1/course_overview.pdf',
NULL,
0,
1,
1),

(1, 1, 'Setup Guide',
'Step-by-step guide to set up your development environment',
'document',
'course_1/module_1/setup_guide.txt',
NULL,
0,
2,
1),

-- Module 2 HTML Resources
(1, 2, 'HTML5 Cheat Sheet',
'Quick reference for HTML5 tags and attributes',
'pdf',
'course_1/module_2/html5_cheatsheet.pdf',
NULL,
0,
1,
1),

(1, 2, 'HTML Code Examples',
'Working code examples from the lesson',
'code',
'course_1/module_2/examples.zip',
NULL,
0,
2,
1),

(1, 2, 'MDN HTML Documentation',
'Official HTML documentation from Mozilla Developer Network',
'document',
NULL,
'https://developer.mozilla.org/en-US/docs/Web/HTML',
1,
3,
1),

-- Module 3 CSS Resources
(1, 3, 'CSS Reference Guide',
'Comprehensive CSS properties and values reference',
'pdf',
'course_1/module_3/css_guide.pdf',
NULL,
0,
1,
1),

(1, 3, 'CSS Code Snippets',
'Common CSS patterns and snippets',
'code',
'course_1/module_3/css_snippets.zip',
NULL,
0,
2,
1),

(1, 3, 'Flexbox Tutorial',
'Interactive Flexbox learning resource',
'document',
NULL,
'https://flexboxfroggy.com',
1,
3,
1),

(1, 3, 'CSS Grid Game',
'Interactive CSS Grid learning game',
'document',
NULL,
'https://cssgridgarden.com',
1,
4,
1),

-- Module 4 JavaScript Resources
(1, 4, 'JavaScript Fundamentals Ebook',
'Complete ebook covering JavaScript basics',
'book',
'course_1/module_4/javascript_fundamentals.pdf',
NULL,
0,
1,
1),

(1, 4, 'JavaScript Code Templates',
'Reusable JavaScript code templates',
'template',
'course_1/module_4/js_templates.zip',
NULL,
0,
2,
1),

(1, 4, 'JavaScript.info Guide',
'Comprehensive JavaScript learning resource',
'document',
NULL,
'https://javascript.info',
1,
3,
1),

-- Module 5 DOM Resources
(1, 5, 'DOM API Reference',
'Complete reference for DOM manipulation methods',
'pdf',
'course_1/module_5/dom_reference.pdf',
NULL,
0,
1,
1),

(1, 5, 'DOM Practice Examples',
'Hands-on DOM manipulation examples',
'code',
'course_1/module_5/dom_examples.zip',
NULL,
0,
2,
1),

-- Module 6 Responsive Design Resources
(1, 6, 'Mobile-First Checklist',
'Checklist for building mobile-first websites',
'pdf',
'course_1/module_6/mobile_first_checklist.pdf',
NULL,
0,
1,
1),

(1, 6, 'Responsive Design Template',
'Starter template for responsive websites',
'template',
'course_1/module_6/responsive_template.zip',
NULL,
0,
2,
1),

-- Module 7 API Resources
(1, 7, 'API Integration Guide',
'Step-by-step guide for API integration',
'pdf',
'course_1/module_7/api_integration.pdf',
NULL,
0,
1,
1),

(1, 7, 'Weather API Example',
'Complete working example using Weather API',
'code',
'course_1/module_7/weather_api_example.zip',
NULL,
0,
2,
1),

(1, 7, 'Public APIs List',
'Curated list of free public APIs',
'document',
NULL,
'https://github.com/public-apis/public-apis',
1,
3,
1),

-- Module 8 Project Resources
(1, 8, 'Project Requirements Document',
'Detailed requirements for the capstone project',
'document',
'course_1/module_8/project_requirements.txt',
NULL,
0,
1,
1),

(1, 8, 'Project Starter Files',
'Initial HTML, CSS, JS files to start the project',
'code',
'course_1/module_8/starter_files.zip',
NULL,
0,
2,
1),

(1, 8, 'Deployment Guide',
'How to deploy your website to production',
'pdf',
'course_1/module_8/deployment_guide.pdf',
NULL,
0,
3,
1);

-- ==========================================
-- SAMPLE PROGRESS DATA (For testing portal display)
-- ==========================================
-- Note: Assuming student_id = 1 for testing
-- These records show progress for one student

-- Mark some modules as completed
INSERT INTO module_progress (student_id, module_id, course_id, is_completed, watched_duration, completed_at) VALUES
(1, 1, 1, 1, 900, NOW() - INTERVAL 5 DAY),  -- Module 1: Completed 5 days ago
(1, 2, 1, 1, 2700, NOW() - INTERVAL 4 DAY), -- Module 2: Completed 4 days ago
(1, 3, 1, 1, 3600, NOW() - INTERVAL 3 DAY), -- Module 3: Completed 3 days ago
(1, 4, 1, 0, 1800, NOW() - INTERVAL 1 DAY), -- Module 4: In progress, watched 30 min
(1, 5, 1, 0, 0, NULL),                       -- Module 5: Not started
(1, 6, 1, 0, 0, NULL),                       -- Module 6: Not started
(1, 7, 1, 0, 0, NULL),                       -- Module 7: Not started
(1, 8, 1, 0, 0, NULL);                       -- Module 8: Not started

-- Update overall progress record
-- This should be calculated by the system, but here's how it looks:
-- Progress: 3 completed / 8 total = 37.5% → 38%
INSERT INTO progress (student_id, course_id, progress_percentage, completed_modules) 
VALUES (1, 1, 38, 3)
ON DUPLICATE KEY UPDATE progress_percentage = 38, completed_modules = 3;

-- ==========================================
-- NOTES FOR TESTING
-- ==========================================
-- 1. Make sure at least one student exists and is enrolled in course 1
-- 2. The sample progress data uses student_id = 1, adjust as needed
-- 3. Ensure directories exist:
--    - /uploads/resources/course_1/module_1/
--    - /uploads/resources/course_1/module_2/
--    - etc.
-- 4. The system will create module_progress records automatically when 
--    students mark modules complete, so the sample data is just for testing
-- 5. External links (YouTube, MDN, etc.) are already working
-- 6. Local file paths should have files uploaded to work properly

-- ==========================================
-- VERIFY INSTALLATION
-- ==========================================
-- Run these queries to verify everything is set up correctly:

-- Check course exists:
-- SELECT * FROM courses WHERE id = 1;

-- Check modules were created:
-- SELECT id, title, sequence_order, duration FROM course_modules WHERE course_id = 1 ORDER BY sequence_order;

-- Check resources exist:
-- SELECT id, title, resource_type, is_external FROM course_resources WHERE course_id = 1 ORDER BY sequence_order;

-- Check sample progress:
-- SELECT mp.*, c.title FROM module_progress mp 
-- JOIN course_modules c ON mp.module_id = c.id 
-- WHERE mp.student_id = 1;

-- Check overall progress:
-- SELECT * FROM progress WHERE student_id = 1 AND course_id = 1;
