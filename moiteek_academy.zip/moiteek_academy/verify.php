<?php
require_once __DIR__ . '/includes/bootstrap.php';
$search = trim($_GET['certificate_id'] ?? '');
$result = null;
$error = '';
if ($search) {
    $stmt = $pdo->prepare('SELECT e.certificate_id, e.completed_at, s.name as student_name, c.title as course_title FROM enrollments e INNER JOIN students s ON e.student_id = s.id INNER JOIN courses c ON e.course_id = c.id WHERE e.certificate_id = ? AND e.status = "completed"');
    $stmt->execute([$search]);
    $result = $stmt->fetch();
    if (!$result) {
        $error = 'Certificate Not Found.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Certificate Verification</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
<div class="container mx-auto px-4 py-10 max-w-lg">
    <h1 class="text-3xl font-bold text-blue-800 mb-8">Verify Certificate</h1>
    <form method="get" class="mb-8 bg-white p-6 rounded shadow">
        <label class="block mb-2 font-semibold">Enter Certificate ID:</label>
        <input type="text" name="certificate_id" value="<?= htmlspecialchars($search) ?>" class="w-full px-3 py-2 border rounded mb-2" required>
        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Verify</button>
    </form>
    <?php if ($search): ?>
        <?php if ($result): ?>
            <div class="p-6 bg-green-100 text-green-900 rounded shadow text-center mb-4">
                <div class="mb-2 text-2xl font-bold text-green-800">Verified</div>
                <div class="mb-2">Certificate ID: <span class="font-mono text-blue-700 font-bold"><?= htmlspecialchars($result['certificate_id']) ?></span></div>
                <div class="mb-2">Student: <span class="font-semibold"><?= htmlspecialchars($result['student_name']) ?></span></div>
                <div class="mb-2">Course: <span class="font-semibold"><?= htmlspecialchars($result['course_title']) ?></span></div>
                <div class="mb-2">Completed: <span><?= date('F j, Y', strtotime($result['completed_at'])) ?></span></div>
            </div>
        <?php else: ?>
            <div class="p-6 bg-red-100 text-red-800 rounded shadow text-center mb-4">
                <div class="mb-2 text-2xl font-bold">Not Found</div>
                <div><?= htmlspecialchars($error) ?></div>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>
</body>
</html>
