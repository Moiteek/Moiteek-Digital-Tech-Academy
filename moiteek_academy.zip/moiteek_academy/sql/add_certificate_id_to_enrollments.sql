ALTER TABLE enrollments ADD COLUMN certificate_id VARCHAR(20) UNIQUE;
