<?php
// app/views/student/progress_bar.php
// Show progress bar in student dashboard
?>
<div class="mb-4">
  <h3 class="font-semibold">Course Progress</h3>
  <div class="w-full bg-gray-200 rounded-full h-4">
    <div class="bg-blue-600 h-4 rounded-full" style="width: <?= $progress['percent'] ?>%"></div>
  </div>
  <p class="mt-2 text-sm">Lessons watched: <?= $progress['watched'] ?> / <?= $progress['total'] ?> (<?= $progress['percent'] ?>%)</p>
</div>
