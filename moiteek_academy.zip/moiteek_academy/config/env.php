<?php
return [
    'local' => [
        'DB_HOST' => 'localhost',
        'DB_NAME' => 'moiteek_academy',
        'DB_USER' => 'root',
        'DB_PASS' => '',
        'PAYSTACK_SECRET_KEY' => 'sk_test_xampp_secret_key', // Replace with your local test key
    ],
    'production' => [
        'DB_HOST' => 'localhost', // Change to your production DB host
        'DB_NAME' => 'your_production_db',
        'DB_USER' => 'your_production_user',
        'DB_PASS' => 'your_production_password',
        'PAYSTACK_SECRET_KEY' => 'sk_live_production_secret_key', // Replace with your live key
    ],
];
