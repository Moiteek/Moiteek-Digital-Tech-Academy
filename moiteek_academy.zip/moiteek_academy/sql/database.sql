
-- Sample data for at least 5 courses with placeholder images
INSERT INTO courses (title, slug, description, detailed_description, price, instructor_name, duration, level, category, total_modules, is_published, image_url)
VALUES
('Data Science Bootcamp', 'data-science-bootcamp', 'Comprehensive data science course', 'Learn Python, statistics, and machine learning from scratch.', 99.99, 'Alice Brown', '10 weeks', 'beginner', 'Data Science', 15, 1, 'https://images.unsplash.com/photo-1501504905252-473c47e087f8?auto=format&fit=crop&w=600&q=80'),
('Graphic Design Essentials', 'graphic-design-essentials', 'Master the basics of graphic design', 'Covers Photoshop, Illustrator, and design theory.', 59.99, 'Bob Green', '8 weeks', 'beginner', 'Design', 12, 1, 'https://images.unsplash.com/photo-1501504905252-473c47e087f8?auto=format&fit=crop&w=600&q=80'),
('Mobile App Development', 'mobile-app-dev', 'Build Android and iOS apps', 'Hands-on projects with Flutter and React Native.', 119.99, 'Carol White', '12 weeks', 'intermediate', 'Mobile Development', 18, 1, 'https://images.unsplash.com/photo-1501504905252-473c47e087f8?auto=format&fit=crop&w=600&q=80'),
('Digital Marketing Pro', 'digital-marketing-pro', 'Become a digital marketing expert', 'SEO, SEM, content, and social media marketing.', 79.99, 'David Black', '6 weeks', 'beginner', 'Marketing', 10, 1, 'https://images.unsplash.com/photo-1501504905252-473c47e087f8?auto=format&fit=crop&w=600&q=80'),
('Cybersecurity Fundamentals', 'cybersecurity-fundamentals', 'Intro to cybersecurity', 'Network security, cryptography, and ethical hacking basics.', 89.99, 'Eve Blue', '9 weeks', 'beginner', 'Security', 14, 1, 'https://images.unsplash.com/photo-1501504905252-473c47e087f8?auto=format&fit=crop&w=600&q=80');

CREATE DATABASE IF NOT EXISTS moiteek_academy;
USE moiteek_academy;

-- Admins Table with proper credentials
CREATE TABLE IF NOT EXISTS admins(
    id INT AUTO_INCREMENT PRIMARY KEY,
    fullname VARCHAR(150) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    role ENUM('super_admin', 'admin') DEFAULT 'admin',
    status ENUM('active', 'inactive') DEFAULT 'active',
    last_login TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_status (status)
);

-- Courses Table
CREATE TABLE IF NOT EXISTS courses(
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    slug VARCHAR(200) UNIQUE NOT NULL,
    description TEXT NOT NULL,
    detailed_description LONGTEXT,
    price DECIMAL(10, 2) DEFAULT 0.00,
    thumbnail VARCHAR(255),
    youtube_link TEXT,
    instructor_name VARCHAR(150),
    duration VARCHAR(50),
    level ENUM('beginner', 'intermediate', 'advanced') DEFAULT 'beginner',
    category VARCHAR(100),
    total_modules INT DEFAULT 0,
    is_published TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_category (category),
    INDEX idx_published (is_published)
);

-- Students Table with enhanced fields
CREATE TABLE IF NOT EXISTS students(
    id INT AUTO_INCREMENT PRIMARY KEY,
    fullname VARCHAR(200) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20) NOT NULL,
    username VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    profile_picture VARCHAR(255),
    bio TEXT,
    country VARCHAR(100),
    email_verified TINYINT(1) DEFAULT 0,
    status ENUM('pending', 'approved', 'rejected', 'suspended') DEFAULT 'pending',
    enrollment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL,
    is_active TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_username (username),
    INDEX idx_status (status),
    INDEX idx_email_verified (email_verified)
);

-- Enrollments Table (linking students to courses)
CREATE TABLE IF NOT EXISTS enrollments(
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    payment_status ENUM('pending', 'confirmed', 'failed') DEFAULT 'pending',
    payment_method VARCHAR(50),
    payment_proof VARCHAR(255),
    payment_date TIMESTAMP NULL,
    enrollment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completion_date TIMESTAMP NULL,
    status ENUM('active', 'completed', 'dropped') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    UNIQUE KEY unique_enrollment (student_id, course_id),
    INDEX idx_student_id (student_id),
    INDEX idx_course_id (course_id),
    INDEX idx_payment_status (payment_status)
);

-- Payments Table (manual payment uploads and verification)
CREATE TABLE IF NOT EXISTS payments(
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'USD',
    payment_method ENUM('bank_transfer', 'mobile_money', 'paystack', 'flutterwave', 'other') DEFAULT 'bank_transfer',
    reference_number VARCHAR(100) UNIQUE,
    proof_file_path VARCHAR(255),
    proof_file_type VARCHAR(50),
    payment_date_submitted TIMESTAMP NOT NULL,
    status ENUM('pending', 'approved', 'rejected', 'cancellation_requested') DEFAULT 'pending',
    approval_notes TEXT,
    rejection_reason TEXT,
    approved_by INT,
    approved_at TIMESTAMP NULL,
    transaction_id VARCHAR(255),
    external_api_response LONGTEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    FOREIGN KEY (approved_by) REFERENCES admins(id) ON SET NULL,
    INDEX idx_student_id (student_id),
    INDEX idx_course_id (course_id),
    INDEX idx_status (status),
    INDEX idx_reference (reference_number),
    INDEX idx_payment_date (created_at),
    INDEX idx_approved_by (approved_by)
);

-- Payment API Integrations Table (for Paystack, Flutterwave, etc.)
CREATE TABLE IF NOT EXISTS payment_integrations(
    id INT AUTO_INCREMENT PRIMARY KEY,
    provider_name ENUM('paystack', 'flutterwave', 'stripe', 'square') NOT NULL,
    is_active TINYINT(1) DEFAULT 0,
    api_key VARCHAR(255),
    api_secret VARCHAR(255),
    webhook_secret VARCHAR(255),
    test_mode TINYINT(1) DEFAULT 1,
    webhook_url VARCHAR(255),
    configuration LONGTEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_provider (provider_name)
);

-- Payment Transactions (automatically generated from API integrations)
CREATE TABLE IF NOT EXISTS payment_transactions(
    id INT AUTO_INCREMENT PRIMARY KEY,
    payment_id INT,
    transaction_reference VARCHAR(100) UNIQUE,
    provider VARCHAR(50),
    student_id INT NOT NULL,
    amount DECIMAL(10, 2),
    status ENUM('pending', 'success', 'failed', 'abandoned') DEFAULT 'pending',
    response_code VARCHAR(50),
    response_message TEXT,
    customer_code VARCHAR(100),
    authorization_url VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (payment_id) REFERENCES payments(id) ON SET NULL,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    INDEX idx_reference (transaction_reference),
    INDEX idx_provider (provider),
    INDEX idx_status (status)
);

-- Progress Tracking Table
CREATE TABLE IF NOT EXISTS progress(
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    progress_percentage INT DEFAULT 0,
    time_spent INT DEFAULT 0,
    completed_modules INT DEFAULT 0,
    last_accessed TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    UNIQUE KEY unique_progress (student_id, course_id),
    INDEX idx_student_id (student_id),
    INDEX idx_course_id (course_id)
);

-- Course Modules Table
CREATE TABLE IF NOT EXISTS course_modules(
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    content LONGTEXT,
    video_url TEXT,
    sequence_order INT,
    duration INT,
    is_published TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    INDEX idx_course_id (course_id),
    INDEX idx_sequence (sequence_order)
);

-- Course Resources Table (for downloads: books, PDFs, files, etc.)
CREATE TABLE IF NOT EXISTS course_resources(
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT NOT NULL,
    module_id INT,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    resource_type ENUM('pdf', 'document', 'book', 'code', 'template', 'other') DEFAULT 'document',
    file_path VARCHAR(255),
    file_url VARCHAR(500),
    is_external TINYINT(1) DEFAULT 0,
    sequence_order INT,
    is_published TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    FOREIGN KEY (module_id) REFERENCES course_modules(id) ON DELETE SET NULL,
    INDEX idx_course_id (course_id),
    INDEX idx_module_id (module_id),
    INDEX idx_sequence (sequence_order)
);

-- Module Progress Table (track completed lessons)
CREATE TABLE IF NOT EXISTS module_progress(
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    module_id INT NOT NULL,
    course_id INT NOT NULL,
    is_completed TINYINT(1) DEFAULT 0,
    watched_duration INT DEFAULT 0,
    completed_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (module_id) REFERENCES course_modules(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    UNIQUE KEY unique_module_progress (student_id, module_id),
    INDEX idx_student_id (student_id),
    INDEX idx_course_id (course_id),
    INDEX idx_completed (is_completed)
);


-- [REMOVED DUPLICATE PAYMENTS TABLE: Use the normalized payments table defined earlier.]

-- Certificates Table
CREATE TABLE IF NOT EXISTS certificates(
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    certificate_number VARCHAR(100) UNIQUE NOT NULL,
    issue_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    grade VARCHAR(10),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    INDEX idx_student_id (student_id),
    INDEX idx_course_id (course_id)
);

-- ==========================================
-- SECURITY TABLES (Production-Grade)
-- ==========================================

-- Email Verification Tokens
CREATE TABLE IF NOT EXISTS email_verification_tokens(
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    token VARCHAR(64) UNIQUE NOT NULL,
    email VARCHAR(100) NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    INDEX idx_token (token),
    INDEX idx_student_id (student_id),
    INDEX idx_expires_at (expires_at)
);

-- Password Reset Tokens
CREATE TABLE IF NOT EXISTS password_reset_tokens(
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    token VARCHAR(64) UNIQUE NOT NULL,
    email VARCHAR(100) NOT NULL,
    user_type ENUM('admin', 'student') NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_token (token),
    INDEX idx_user_id (user_id),
    INDEX idx_expires_at (expires_at)
);

-- CSRF Tokens (optional, for advanced tracking)
CREATE TABLE IF NOT EXISTS csrf_tokens(
    id INT AUTO_INCREMENT PRIMARY KEY,
    token VARCHAR(64) UNIQUE NOT NULL,
    session_id VARCHAR(255),
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_token (token),
    INDEX idx_session_id (session_id),
    INDEX idx_expires_at (expires_at)
);

-- Login Activity Log (for security auditing)
CREATE TABLE IF NOT EXISTS login_activity(
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    user_type ENUM('admin', 'student'),
    email VARCHAR(100),
    ip_address VARCHAR(45),
    user_agent TEXT,
    login_status ENUM('success', 'failed', 'locked') DEFAULT 'success',
    failure_reason VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_email (email),
    INDEX idx_created_at (created_at)
);

-- ==========================================
-- INSERT DEFAULT DATA
-- ==========================================

-- Insert Default Admin Account
INSERT INTO admins (fullname, email, password, phone, role, status) 
VALUES ('Administrator', 'admin@moiteek.com', '$2y$10$YIjlrBFEV4T5iK9Z.jK/dOT9JxY5JcI3K3K3K3K3K3K3K3K3K3K3K', '+1234567890', 'super_admin', 'active');

-- Insert Sample Courses
INSERT INTO courses (title, slug, description, detailed_description, price, instructor_name, duration, level, category, total_modules, is_published) 
VALUES 
('Web Development Fundamentals', 'web-dev-fundamentals', 'Learn HTML, CSS, and JavaScript basics', 'Complete guide to web development starting from basics', 49.99, 'John Smith', '8 weeks', 'beginner', 'Web Development', 12, 1),
('Advanced PHP & MySQL', 'advanced-php-mysql', 'Master backend development with PHP', 'Deep dive into PHP frameworks and database optimization', 79.99, 'Sarah Johnson', '12 weeks', 'advanced', 'Backend Development', 18, 1),
('UI/UX Design Masterclass', 'ui-ux-design', 'Professional design principles and tools', 'Learn Figma, Prototyping, and user research', 59.99, 'Mike Chen', '6 weeks', 'intermediate', 'Design', 10, 1);
