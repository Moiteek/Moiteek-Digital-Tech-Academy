
MOITEEK DIGITAL TECH ACADEMY SETUP

1. Import sql/database.sql into MySQL.
2. Edit config/db.php with DB credentials.
3. Place project in htdocs (XAMPP) or www.
4. Visit http://localhost/moiteek_academy
5. Default admin:
   INSERT INTO admins(email,password)
   VALUES('admin@mail.com', md5('admin123'));
